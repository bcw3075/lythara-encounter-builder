/* Player reactions during a monster's turn (0.20.0): which reactions the module knows, which gate each one fits, where along a move the gates fall,
   and what a reaction that raises AC does to an attack already rolled. Pure: no Foundry globals, so the unit tests run it in Node. */
import { distanceBetween } from "./move.mjs";
import { IT, pro } from "./pronoun.mjs";

/* The gates a monster's action passes through (Rhea's design, 2026-11-05; built 0.20.0): move: it leaves a square during a move action (asked before
   it leaves); stay: a move action that leaves no square (Stand, Drop Prone, a Climb), asked at the end of that action; manipulate and ranged: asked
   before the action resolves; attack: a Strike at a creature, before the roll; hit: that Strike hit, before damage. */
/** The reactions the module knows, by PF2e slug, each row checked against Archives of Nethys (2026-11-09):
    Reactive Strike (Player Core; Player Core 2 pg. 80; monsters' Rage of Elements pg. 233): a creature within your reach uses a manipulate or a move
      action, makes a ranged attack, or leaves a square during a move action; a melee Strike, no multiple attack penalty; a critical hit disrupts a
      manipulate action. The old slug attack-of-opportunity is the same reaction.
    Shield Block (Player Core): while your shield is raised you would take physical damage from an attack; the shield takes it first.
    Reactive Shield (Player Core pg. 140): an enemy hits you with a melee Strike, while wielding a shield; you Raise a Shield, and the bonus counts
      against that attack.
    Nimble Dodge (Player Core): a creature targets you with an attack and you can see it; +2 circumstance to AC against that attack. */
export const KNOWN = {
  "reactive-strike": { name: "Reactive Strike", gates: ["move", "stay", "manipulate", "ranged"], reach: true },
  "attack-of-opportunity": { name: "Reactive Strike", gates: ["move", "stay", "manipulate", "ranged"], reach: true },
  "shield-block": { name: "Shield Block", gates: ["hit"], target: true, needs: "raised", physical: true },
  "reactive-shield": { name: "Reactive Shield", gates: ["hit"], target: true, needs: "shield", melee: true },
  "nimble-dodge": { name: "Nimble Dodge", gates: ["attack"], target: true, ac: 2 },
  /* The party's own (0.27.0), each checked on Archives of Nethys 2026-11-11.
     Glimpse of Redemption (Player Core 2 pg. 93): an enemy damages your ally, and both are in your champion's aura; the enemy repents (the ally is
       unharmed) or refuses (the ally resists all of that damage by 2 + your level, then the enemy is enfeebled 2 until the end of its next turn).
     Interposing Earth (Rage of Elements pg. 95, a reaction spell): you are the target of a Strike or would attempt a Reflex save against a damaging
       area effect; standard cover against it, and if you are still damaged the barrier is destroyed and the damage is 2 less (8 from 4th rank). */
  "glimpse-of-redemption": { name: "Glimpse of Redemption", gates: ["harm"], ally: true, aura: "champions-aura" },
  "interposing-earth": { name: "Interposing Earth", gates: ["attack", "area"], target: true, ac: 2, cover: true, spell: true },
  /* Moment E, a monster casts a spell (0.36.0; the full reactions pass, release 2), each checked on Archives of Nethys 2026-11-16.
     Counterspell (Player Core pg. 186; the compendium also keeps the legacy sorcerer's "spontaneous" version): a creature casts a spell you have
       prepared (or in your repertoire, spontaneous) and you can see it; you lose that slot as if you had cast it, then counteract it.
     Recognize Spell (Player Core pg. 261, secret): a creature in your line of sight casts a spell you don't have prepared or in your repertoire;
       automatic success for a common spell up to rank 2/4/6/10 by your proficiency in its tradition's skill; untrained, no better than failure;
       a critical success gives +1 circumstance to your save or AC against it.
     Nullify (Impossible Magic pg. 155, spell 10): a foe within 120 feet casts a 9th-rank or lower spell; it is counteracted automatically and you
       lose 1d8 HP per rank of that spell.
     Shadow Siphon (Core Rulebook pg. 368, legacy only on Archives of Nethys): a spell deals damage, range 60 feet; counteract it with your rank
       treated as 2 higher; on a success the damage is halved.
     Mimic Spell (Rival Academies pg. 33, spell 8), Spell Riposte (Player Core 2 pg. 252, spell 7: you are the target; not an area) and Redirect
       Teleportation (Impossible Magic pg. 109, wizard 12: a creature teleports into a space within 60 feet) are the player's to make (Pause). */
  "counterspell-prepared": { name: "Counterspell", gates: ["cast"], sees: true, counter: "same", entries: "prepared" },
  "counterspell-spontaneous": { name: "Counterspell", gates: ["cast"], sees: true, counter: "same", entries: "spontaneous" },
  "recognize-spell": { name: "Recognize Spell", gates: ["cast"], sees: true, recognize: true },
  "nullify": { name: "Nullify", gates: ["cast"], spell: true, sees: true, range: 120, maxRank: 9, counter: "auto" },
  "shadow-siphon": { name: "Shadow Siphon", gates: ["cast"], spell: true, range: 60, damaging: true, counter: "siphon" },
  "mimic-spell": { name: "Mimic Spell", gates: ["cast"], spell: true, sees: true, range: 120, tradition: true, pause: true },
  "spell-riposte": { name: "Spell Riposte", gates: ["cast"], spell: true, target: true, pause: true },
  "redirect-teleportation": { name: "Redirect Teleportation", gates: ["cast"], sees: true, range: 60, teleport: true, pause: true }
};
/** Reactions the player makes with the usual tools after React, then presses Done (Reactive Strike's roll, and the "Pause" rows of the pass). */
export const makesItself = slug => !!(KNOWN[slug]?.reach || KNOWN[slug]?.pause);
/** The rows that are asked before an attack and raise AC against it (circumstance bonuses, so only the best counts). */
export const AC_ROWS = Object.keys(KNOWN).filter(k => KNOWN[k].ac);
const PHYSICAL = ["bludgeoning", "piercing", "slashing"];

/** The trigger line of a reaction's description (HTML), in plain words, or null. */
export function triggerOf(html = "") {
  const m = String(html).match(/<strong>\s*Trigger\s*<\/strong>\s*([\s\S]*?)(?:<\/p>|<hr|<strong>|$)/i);
  return m ? m[1].replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim() || null : null;
}
/** A creature's reactions from its items ({ slug, name, actionType, description }): the known ones with their row, the others with their trigger. */
export function reactionsOf(items = []) {
  const out = [], seen = new Set();
  for (const it of items) {
    if (it?.actionType !== "reaction") continue;
    const row = KNOWN[it.slug], key = row ? row.name : it.slug ?? it.name; if (seen.has(key)) continue;
    if (row && !!row.spell !== !!it.spell) continue;   /* a spell's row is only for the spell, a feat's only for the feat */
    seen.add(key);
    out.push(row ? { slug: it.slug, name: row.name, known: true, ...(it.spell ? { spell: it.spell } : {}) } : { slug: it.slug ?? null, name: it.name, known: false, trigger: triggerOf(it.description) });
  }
  return out;
}
/** Does a known reaction fit this gate? who: what the glue read of the reactor ({ inReach, isTarget, shieldRaised, hasShield }); what: the action
    ({ melee, damageTypes }). Unknown reactions never fit: they are shown to the GM, never asked (Rhea, 2026-11-09: prompted only when they have the right one). */
export function fits(slug, gate, who = {}, what = {}) {
  const row = KNOWN[slug]; if (!row || !row.gates.includes(gate)) return false;
  if (row.reach && !who.inReach) return false;
  if (row.target && !who.isTarget) return false;
  if (row.ally && (!who.isAlly || who.isTarget || !who.inAura)) return false;   /* an ally, never itself, and the aura rule holds (Rhea, PR-8) */
  if (row.spell && !who.canCast) return false;
  if (row.needs === "raised" && !who.shieldRaised) return false;
  if (row.needs === "shield" && (!who.hasShield || who.shieldRaised)) return false;   /* already raised: nothing to gain */
  if (row.melee && !what.melee) return false;
  if (row.physical && (what.damageTypes?.length ? !what.damageTypes.some(t => PHYSICAL.includes(t)) : false)) return false;   /* unknown types: offer it */
  /* a monster casting (0.36.0): who: { hasSame (a copy it can spend), knowsIt, dist (ft to the caster), tradition, spellRank }; what: the cast
     { rank, tradition, damaging, teleport } */
  if (row.counter === "same" && !who.hasSame) return false;
  if (row.recognize && who.knowsIt) return false;
  if (row.range && !(Number(who.dist) <= row.range)) return false;
  if (row.maxRank && !(Number(what.rank) <= row.maxRank)) return false;
  if (row.damaging && !what.damaging) return false;
  if (row.teleport && !what.teleport) return false;
  if (row.tradition && (!what.tradition || what.tradition !== who.tradition || !(Number(what.rank) <= Number(who.spellRank)))) return false;
  return true;
}
/** Where along a move the "move" gates fall. route: squares from where it stands to where it ends; mover: { size, elev }; reactors: [{ id, pos, span,
    elev, reach }]. A reactor is asked once per move action, before the mover leaves the first square of the route that is within its reach (the end
    square isn't left). Returns [{ k, ids }] by route index, in order. from: gates only from this index on (a move resumed after an earlier gate). */
export function routeGates(route = [], mover = {}, reactors = [], { from = 0, done = [] } = {}) {
  const out = new Map(), asked = new Set(done);
  for (let k = from; k < route.length - 1; k++) for (const r of reactors) {
    if (asked.has(r.id)) continue;
    const d = distanceBetween({ x: route[k][0], y: route[k][1], size: mover.size ?? 1, elev: mover.elev ?? 0 }, { x: r.pos[0], y: r.pos[1], size: r.span ?? 1, elev: r.elev ?? 0 }, { reach: r.reach });
    if (d <= r.reach) { asked.add(r.id); if (!out.has(k)) out.set(k, []); out.get(k).push(r.id); }
  }
  return [...out].sort((a, b) => a[0] - b[0]).map(([k, ids]) => ({ k, ids }));
}
/** The degree of an attack roll against a DC, as the rules count it: 10 over is a critical, under by 10 a critical failure, a natural 20 one better
    and a natural 1 one worse. 0 critical failure .. 3 critical success. */
export function degreeAgainst(total, natural, dc) {
  let d = total >= dc + 10 ? 3 : total >= dc ? 2 : total <= dc - 10 ? 0 : 1;
  if (natural === 20) d++; else if (natural === 1) d--;
  return Math.max(0, Math.min(3, d));
}
/** The circumstance cover bonus PF2e already put in an attack's DC, from the attack card's roll options (`target:cover-bonus:<n>`; 0.29.1, bug B-3).
    Visioner's cover is a modifier predicated on the attacker, so it reads as disabled on the target's AC outside the roll: without this a reaction's
    +2 was added on top of a cover bonus the DC already held, though circumstance bonuses don't stack. options: the card's `context.options`. */
export function coverInDc(options = []) {
  let best = 0;
  for (const o of Array.isArray(options) ? options : []) { const m = /^target:cover-bonus:(\d+)$/.exec(String(o)); if (m) best = Math.max(best, Number(m[1])); }
  return best;
}
/** What a reaction that raises AC adds to a DC: only what it beats of the circumstance bonus already counted (circumstance bonuses don't stack).
    bonus: the reaction's; had: the best circumstance bonus already in the DC. */
export const acAdds = (bonus, had) => Math.max(0, (Number(bonus) || 0) - Math.max(0, Number(had) || 0));
/** What the reactor is told, in a sentence. who: the mover as the reactor may see it ("The Sod Hound" or "A creature"); kind: the monster's action. */
export function gateWords(gate, who, { kind = "", reaction = "" } = {}) {
  const W = { move: `${who} is moving out of a square in your reach`, stay: `${who} ${kind || "uses a move action"} in your reach`, manipulate: `${who} uses a manipulate action in your reach${kind ? ` (${kind})` : ""}`,
    ranged: `${who} makes a ranged attack in your reach`, attack: `${who} attacks you`, hit: `${who}'s ${kind || "Strike"} hits you`,
    harm: `${who} is about to damage ${kind || "your ally"}, and both are in your champion's aura`, area: `${who}'s ${kind || "spell"} is about to catch you in its area`,
    cast: `${who} is casting ${kind || "a spell"}` };
  return `${W[gate] ?? who}. React with ${reaction}?`;
}
/** What a reaction asked on the card or the prompt resolved to, from the answers: "react" (and the reactor finished: "done"), "pass", "timeout",
    "continue" (the GM went on). A list is finished when no one is left to answer. */
export function finished(list = []) { return list.every(x => ["done", "pass", "timeout", "continue"].includes(x.answer)); }
/** The rows another answer settles (0.27.0): a creature has one reaction, so once one of its rows is being used its other rows that spend the reaction
    are skipped. rows: [{ id, token, free }]; answers: { id: answer }. Returns the ids to skip. */
export function spentRows(rows = [], answers = {}) {
  const using = new Set(rows.filter(x => !x.free && ["react", "done"].includes(answers[x.id])).map(x => x.token));
  return rows.filter(x => !x.free && using.has(x.token) && !answers[x.id]).map(x => x.id);
}
/** When a question's countdown ends (server-clock ms), or 0 for none: only rows a player answers in their own window count down; rows the GM answers
    on her card wait (Rhea, 2026-11-09, 0.20.1). secs 0 is no countdown. */
export function untilFor(rows = [], secs = 0, now = 0) { return secs > 0 && rows.some(x => x.to === "player") ? now + secs * 1000 : 0; }
/** Whether the card shows the countdown: time is left and a player row is still unanswered. */
export function countingDown(rows = [], answers = {}, until = 0, now = 0) { return until > now && rows.some(x => x.to === "player" && !answers[x.id]); }
/** The answers as plain words for the card and the history ("Valeros: Reactive Strike", "Test Hero passed"). names: token id → name. */
export function answerWords(list = [], names = {}) {
  return list.map(x => { const n = names[x.token] ?? x.name ?? "Someone";
    return x.answer === "done" ? `${n} used ${x.reaction}` : x.answer === "react" ? `${n} is using ${x.reaction}` : x.answer === "timeout" ? `${n} didn't answer in time (${x.reaction} passed)` : x.answer === "continue" ? `${n}'s ${x.reaction} was skipped` : `${n} passed on ${x.reaction}`; });
}

/* ---------- monsters reacting on players' turns (0.21.0) ----------
   Rhea, 2026-11-09: a monster with Angel and Auto ticked takes a Reactive Strike by itself, any other monster's is Do it / Skip on her card; every
   trigger the rule names counts ("basically it should be anything that the rules state"; a spell only through its own traits); and when the module
   isn't sure a trigger happened it always comes to her card, even for an Auto monster. Reactive Strike (Rage of Elements pg. 233; Player Core, checked
   on Archives of Nethys 2026-11-09): a creature within reach uses a manipulate action or a move action, makes a ranged attack, or leaves a square
   during a move action it is using. Each function says what the module saw and how sure it is: { gate, sure, kind, why }. */
/** The reactions the module runs for a monster: Reactive Strike under either slug. A monster's other reactions are listed for the GM, never run. */
export const MONSTER_REACTIONS = ["reactive-strike", "attack-of-opportunity"];
/* Foundry's movement actions that are move actions leaving squares (PF2e 8.7.0 names them Stride, Crawl, Climb, Swim, Fly, Burrow, Leap). Teleports
   (blink, displace) aren't move actions that leave squares. There is no "step": a one-square walk can be a Step, which triggers nothing. */
const MOVE_ACTIONS = ["walk", "crawl", "climb", "swim", "fly", "burrow", "jump"], TELEPORTS = ["blink", "displace"];
/** A token move as a trigger. action: Foundry's movement action; squares: how many squares it left; ownTurn: it is the mover's turn; stepped: the mover
    posted a Step card just before; strode: a Stride card just before; difficult: a square it entered is difficult terrain; landSpeed: its land Speed
    in feet (null when unknown); keyboard: moved by the movement keys; script: moved by a script or another module. Returns null (no trigger) or { gate: "move", sure, kind, why } (and `steps`: how many Steps it could have been).
    Rhea, 2026-11-15 (q-33): "a step is 5ft anf a stride is anything more then 5ft. Can't you use that as your guide?": one walked square on its own
    turn is a Step, unless a Step can't go there (difficult terrain, a Speed other than land, a land Speed under 10: Player Core pg. 418, checked on
    Archives of Nethys 2026-11-15) or a Stride card says otherwise. And "they couild go 2 or 3 steps in a row": one walk of 10 or 15 ft could be
    Steps or a Stride, so the player is asked (`steps`), never the module guessing. */
export function moveTrigger({ action = "walk", squares = 0, ownTurn = true, stepped = false, strode = false, difficult = false, landSpeed = null, keyboard = false, script = false } = {}) {
  if (!(squares > 0) || TELEPORTS.includes(action)) return null;
  if (squares === 1 && action === "walk" && stepped) return null;
  if (!MOVE_ACTIONS.includes(action)) return { gate: "move", sure: false, kind: "moved", why: `Its move was made as "${action}", which may not be a move action.` };
  if (!ownTurn) return { gate: "move", sure: false, kind: "moved", why: "It moved outside its own turn: being pushed or pulled doesn't trigger this." };
  const canStep = action === "walk" && !strode && !difficult && !(landSpeed != null && landSpeed < 10);
  /* the movement keys move one square a press, so a Stride by keys is a row of one-square moves: those stay the GM's to judge, as before q-33 */
  if (canStep && squares <= 3 && script) return { gate: "move", sure: false, kind: `moved ${squares * 5} feet`, why: "It was moved by a script or another module, which may not be its own move action." };   /* never the player's to answer for */
  if (canStep && squares === 1 && keyboard) return { gate: "move", sure: false, kind: "moved one square", why: "It moved one square with the movement keys: a Step doesn't trigger this, a Stride does." };
  if (canStep && squares === 1) return null;   /* a Step */
  if (canStep && squares <= 3) return { gate: "move", sure: false, kind: `moved ${squares * 5} feet`, steps: squares, why: `It moved ${squares * 5} feet: ${STEPS_WORDS[squares]} Steps don't trigger this, a Stride does.` };
  const kind = action !== "walk" || squares > 3 ? "left a square" : strode ? "strode" : difficult ? "strode into difficult terrain (a Step can't go there)" : landSpeed != null && landSpeed < 10 ? "strode (with a Speed under 10 feet it can't Step)" : "left a square";
  return { gate: "move", sure: true, kind };
}
export const STEPS_WORDS = { 2: "two", 3: "three" };
/* Action cards whose movement shows as a token move (the move tells; the card would only ask twice), and the two move actions that leave no square. */
const MOVERS = ["stride", "crawl", "leap", "fly", "swim", "climb", "burrow", "sneak", "tumble-through", "long-jump", "high-jump", "balance", "mount", "travel"];
const STAYS = { stand: "stood up", "drop-prone": "dropped prone" };
/* Consumables whose activation is an Interact (manipulate) by their own rules: drinking, applying, injecting. Others vary (a talisman is usually free). */
const HAND_CONSUMABLES = ["potion", "elixir", "oil", "mutagen", "drug"];
/** What a chat card says of its action, from its HTML (flavor and content) and roll options. PF2e's own action cards (Interact, Stand, Step) carry no
    flags: the title is in `<h4 class="action"><strong>`, the traits in `class="tag" data-slug`. A check rolled for an action names it in the option
    `action:<slug>`; an item's card names its traits and slug in `item:trait:<x>` and `item:slug:<x>` (with or without `origin:`). itemCard: an item
    shown in chat, not used. Returns { traits, title, slug, itemCard }. */
export function readCard(html = "", options = [], traits = []) {
  const h = String(html), out = new Set(traits.filter(Boolean));
  for (const x of options) { const m = /(?:^|:)item:trait:([a-z0-9-]+)$/.exec(x); if (m) out.add(m[1]); }
  for (const m of h.matchAll(/<[^>]*class="tag[^"]*"[^>]*>/g)) { const s = /data-slug="([a-z0-9-]+)"/.exec(m[0]); if (s) out.add(s[1]); }
  for (const m of h.matchAll(/<[^>]*data-slug="([a-z0-9-]+)"[^>]*class="tag[^"]*"[^>]*>/g)) out.add(m[1]);
  const title = /<h4 class="action">\s*<strong>([^<]+)<\/strong>/.exec(h)?.[1]?.trim() ?? null;
  const slug = options.map(x => /^action:([a-z0-9-]+)$/.exec(x)?.[1] ?? /(?:^|:)item:slug:([a-z0-9-]+)$/.exec(x)?.[1]).find(Boolean) ?? (title ? title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") : null);
  return { traits: [...out], title, slug, itemCard: /class="[^"]*\bitem-card\b/.test(h) };
}
/** A chat card as a trigger. card: { type (PF2e's context type or null), ranged, spell (it is a cast card), consumable (its category, or true when
    unknown), traits ([] of slugs from the card's tags, its origin and its context), slug (the action's, sluggified), name }. Returns null,
    { step: true } (a Step: the next one-square move is no trigger), or { gate, sure, kind, why }. */
export function cardTrigger(card = {}) {
  const traits = card.traits ?? [], name = card.name || "an action";
  if (card.type === "attack-roll") return card.ranged ? { gate: "ranged", sure: true, kind: "made a ranged attack" } : null;
  if (card.type && !["spell-cast", "skill-check", "perception-check"].includes(card.type)) return null;   /* damage, saves and the like follow an action already seen */
  if (card.spell) return traits.includes("manipulate") ? { gate: "manipulate", sure: true, kind: `cast ${name} (manipulate)` } : null;   /* only by its own traits (Rhea) */
  if (card.consumable) return HAND_CONSUMABLES.includes(card.consumable) || traits.includes("manipulate") ? { gate: "manipulate", sure: true, kind: `used ${name} (an Interact)` }
    : { gate: "manipulate", sure: false, kind: `used ${name}`, why: `It used ${name}: if activating it was a manipulate action, this triggers.` };
  if (card.slug === "step") return { step: true };
  if (card.slug === "stride") return { stride: true };   /* the move itself is the trigger; the card says it wasn't Steps (q-33) */
  if (card.slug === "release") return null;   /* Release has the manipulate trait and triggers nothing (Player Core pg. 417) */
  if (traits.includes("manipulate")) return { gate: "manipulate", sure: true, kind: `used ${name} (manipulate)` };
  if (traits.includes("move")) { if (card.slug in STAYS) return { gate: "stay", sure: true, kind: STAYS[card.slug] };
    return MOVERS.includes(card.slug) ? null : { gate: "stay", sure: true, kind: `used ${name} (a move action)` }; }
  return null;
}
/** An item changing hands with no card (PF2e posts none for drawing, stowing or picking up). before/after: { carry, hands }. Letting go (dropped, or
    fewer hands on something still held) is a Release and triggers nothing. Something coming into a hand on its own turn (drawn, picked up, a second
    hand on the grip) is an Interact, sure (Rhea, 2026-11-15, q-33: "Yes, all by rule"); anything else (put away, or outside its turn) is an
    Interact only if it was done as an action at all: never sure. */
export function equipTrigger(before = {}, after = {}, name = "an item", ownTurn = false) {
  const b = { carry: before.carry ?? "worn", hands: before.hands ?? 0 }, a = { carry: after.carry ?? b.carry, hands: after.hands ?? b.hands };
  if (a.carry === b.carry && a.hands === b.hands) return null;
  if (a.carry === "dropped" || (a.carry === "held" && b.carry === "held" && a.hands < b.hands)) return null;
  const did = a.carry === "held" && b.carry !== "held" ? "drew or picked up" : b.carry === "held" && a.carry !== "held" ? "put away" : a.carry === "held" ? "changed its grip on" : "moved";
  if (ownTurn && a.carry === "held" && (b.carry !== "held" || a.hands > b.hands)) return { gate: "manipulate", sure: true, kind: `${did} ${name} (an Interact)` };
  return { gate: "manipulate", sure: false, kind: `${did} ${name}`, why: `It ${did} ${name} with no action card: that is an Interact (manipulate) if it was done as an action.` };
}
/** Prone coming off with no Stand card: on its own turn that is a Stand, a move action (Rhea, 2026-11-15, q-33). Outside its turn it is no trigger
    (the condition was taken off, nothing was done). */
export function proneOffTrigger({ ownTurn = true, stood = false } = {}) {
  return ownTurn && !stood ? { gate: "stay", sure: true, kind: "stood up (Prone came off on its own turn)" } : null;
}
/** The squares a token passed, from the squares of its waypoints (the first is where it started): straight runs between them, one square a step. */
export function squaresAlong(points = []) {
  const out = []; for (const p of points) { if (!out.length) { out.push([p[0], p[1]]); continue; }
    let [x, y] = out.at(-1); while (x !== p[0] || y !== p[1]) { x += Math.sign(p[0] - x); y += Math.sign(p[1] - y); out.push([x, y]); } }
  return out;
}
/** Which melee Strike a monster reacts with: the best attack among those that reach. strikes: [{ id, name, ranged, reach, mod }]; dist in feet. */
export function reactionStrike(strikes = [], dist = 5) {
  return strikes.filter(s => !s.ranged && (s.reach ?? 5) >= dist).sort((a, b) => (b.mod ?? 0) - (a.mod ?? 0))[0] ?? null;
}
/** The line on the GM's card. o: { monster, target, strike, kind, sure, why } */
export function offerWords(o = {}) {
  const who = o.target ?? "a creature";
  return `${o.monster ?? "A monster"} can make a Reactive Strike${o.strike ? ` (${o.strike})` : ""} at ${who}: ${who} ${o.kind ?? "acted"} in its reach.${o.sure ? "" : ` Not certain. ${o.why ?? ""}`.trimEnd()}`;
}

/** The player's question when one walk of 10 or 15 ft left a monster's reach (Rhea, 2026-11-15, q-33: "Ask the player"). n: squares (2 or 3);
    monsters: their names as this player sees them. Returns { title, lines, steps, stride } (the two buttons). */
export function stepsQuestion(n = 2, monsters = []) {
  const counts = new Map(); for (const m of monsters) { const k = /^a creature$/i.test(m) ? "a creature" : m; counts.set(k, (counts.get(k) ?? 0) + 1); }
  const NUM = { 2: "two", 3: "three", 4: "four" }, parts = [...counts].map(([k, c]) => c === 1 ? k : k === "a creature" ? `${NUM[c] ?? c} creatures` : `${NUM[c] ?? c} ${k}s`);
  const ft = n * 5, list = parts.length ? (parts.length === 1 ? parts[0] : `${parts.slice(0, -1).join(", ")} and ${parts.at(-1)}`) : "a creature";
  const lead = list.charAt(0).toUpperCase() + list.slice(1);
  return { title: "Your move", lines: [`You moved ${ft} feet, out of the reach of ${list}.`, `${lead} can react to a Stride, but not to a Step.`, `Was that ${STEPS_WORDS[n] ?? n} Steps, or a Stride?`],
    steps: `${(STEPS_WORDS[n] ?? String(n)).replace(/^./, c => c.toUpperCase())} Steps`, stride: "Stride" };
}
/** What the player's answer did, for the card's note and the history. answer: "steps" | "stride" | "timeout"; who: the mover's name; user: the
    player's name; n: squares. */
export function stepsAnswerWords(answer, who = "It", user = "the player", n = 2) {
  const steps = STEPS_WORDS[n] ?? n;
  return answer === "steps" ? `No reaction: ${who} took ${steps} Steps, ${steps} of ${who}'s actions (${user} said so).` : answer === "stride" ? `strode ${n * 5} feet (${user} said so)`
    : `${user} didn't answer whether it was ${steps} Steps or a Stride.`;
}

/* ---------- the party's reactions (0.27.0) ----------
   Rhea, 2026-11-11 (docs/features/reactions.md): each character's reaction is tracked like a focus point that comes back at the start of its turn; a
   character whose reaction is used, who is Delaying, or who is a minion is never asked; every reduction says why. */
/** Who has a reaction box and is asked: a character, or an ordinary NPC fighting on the party's side; never a minion (summons, companions and
    familiars can't use reactions, Player Core pg. 416, checked on Archives of Nethys 2026-11-11). a: { type, traits } */
export const canReact = (a = {}) => ["character", "npc"].includes(a.type) && !(a.traits ?? []).includes("minion");
/** Does a held shield let its bearer Shield Block without the feat? The impulse's own shield says so in its text, and the module reads what the
    character can do, not only a feat with that slug (Rhea, 2026-11-11). shield: { slug, text } (its description as plain text). */
export const shieldGrantsBlock = (shield = {}) => shield.slug === "metal-carapace-shield" || /shield block\W{0,3}with this shield even if you don.t have/i.test(String(shield.text ?? ""));
/** Glimpse of Redemption, refused: resistance to all of the triggering damage, 2 + the champion's level. */
export const glimpseResistance = level => 2 + Math.max(0, Math.round(Number(level) || 0));
/** Interposing Earth: how much comes off the damage when the barrier is destroyed (8 from 4th rank). */
export const earthLess = rank => (Number(rank) || 1) >= 4 ? 8 : 2;
/* ---------- Interposing Earth's barrier on the map (0.35.0; Rhea, 2026-11-16, q-36: "Wall plus picture") ---------- */
/** The barrier's numbers by the rank it was cast at (Rage of Elements pg. 95, checked on Archives of Nethys 2026-11-16: AC 5, Hardness 2, 5 HP;
    heightened 4th: Hardness 8, 20 HP). It lasts 3 rounds: one comes off at the start of each of the caster's turns (a spell's duration in rounds). */
export const barrierStats = rank => (Number(rank) || 1) >= 4 ? { ac: 5, hardness: 8, hp: 20, rounds: 3 } : { ac: 5, hardness: 2, hp: 5, rounds: 3 };
/** Where the barrier stands: on the border between the caster's space and the square next to it toward the source ("between you and the source of
    the triggering effect"), one square long (5 ft). caster: { pos: [x, y], span }; src: the source's centre in squares { x, y }. Returns { side
    (east, west, north or south of the caster), a, b (the edge's two grid points, in squares), near (the caster's square at that edge), far (the
    square across it, the source's side) }. The side is the axis the source is furthest along (east or west on a tie); along the edge, the row or
    column of the caster's space nearest the source. */
export function barrierEdge(caster = {}, src = {}) {
  const n = Math.max(1, Number(caster.span) || 1), [px, py] = caster.pos ?? [0, 0], cx = px + n / 2, cy = py + n / 2;
  const dx = (Number(src.x) || 0) - cx, dy = (Number(src.y) || 0) - cy, clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  if (Math.abs(dx) >= Math.abs(dy)) {
    const row = clamp(Math.floor(Number(src.y) || 0), py, py + n - 1), east = dx >= 0, x = east ? px + n : px;
    return { side: east ? "east" : "west", a: [x, row], b: [x, row + 1], near: [east ? x - 1 : x, row], far: [east ? x : x - 1, row] };
  }
  const col = clamp(Math.floor(Number(src.x) || 0), px, px + n - 1), south = dy > 0, y = south ? py + n : py;
  return { side: south ? "south" : "north", a: [col, y], b: [col + 1, y], near: [col, south ? y - 1 : y], far: [col, south ? y : y - 1] };
}
/** The words on the slab's picture, for everyone. */
export const barrierLabel = b => `Earth barrier ${Math.max(0, b.hp)}/${b.max} HP · ${b.left} round${b.left === 1 ? "" : "s"}`;
/** The GM's line for a barrier that stands (pronoun markers: the caster's). */
export const barrierCardWords = (name, b) => `${name}'s earth barrier stands on the edge ${b.side} of {them}: a wall no one can pass, cover behind it, AC ${b.ac}, Hardness ${b.hardness}, ${b.hp} HP, ${b.left} round${b.left === 1 ? "" : "s"} left (one comes off at the start of each of {their} turns).`;
/** What a blow at the barrier takes off its HP: the damage less its Hardness (an object's Hardness, Player Core). */
export const slabHit = (rolled, hardness = 2) => Math.max(0, Math.floor(Number(rolled) || 0) - (Number(hardness) || 0));
/** The line for everyone after a monster's Strike at a barrier. who: the monster as players may name it. */
export function slabWords({ who = "A creature", outcome = "miss", rolled = 0, dealt = 0, hardness = 2, hp = 0, max = 5, gone = false } = {}) {
  const hit = ["hit", "critical hit"].includes(outcome);
  return `${who} struck the earth barrier: ${outcome}${hit ? `, ${rolled} damage, ${dealt} after its Hardness ${hardness}` : ""}. ${gone ? "It was already gone." : hp > 0 ? `It stands at ${hp}/${max} HP.` : "It crumbles."}`;
}

/* ---------- Ready (0.35.0; Rhea, 2026-11-16, q-37: the Now! button) ---------- */
/** While someone has an action readied, each monster step waits this long before it goes on, so the player can press Now! (sample 4). */
export const READY_WAIT_MS = 3000;
/** The trigger as the player typed it on the chip: one line, short. */
export const cleanTrigger = text => String(text ?? "").replace(/\s+/g, " ").trim().slice(0, 120);
/** The amber line on the monster's card while someone is readied. */
export const readyWords = (name, trigger) => `${name} has an action readied${trigger ? `: "${trigger}"` : ""}. Each step waits ${READY_WAIT_MS / 1000} s before it goes on, so ${name}'s player can press Now!`;
/** The line once Now! was pressed: the turn waits for the readied action. */
export const readiedWords = (name, moved = false) => `${name}'s readied action: the turn waits${moved ? " (the monster stopped in the square it was entering)" : ""}. ${name}'s player makes it, then Done.`;
/** The lowest rank a reaction spell can be cast at now. slots: [{ rank, left }]; base: the spell's own rank. Null when none is left. */
export function castRank(base = 1, slots = []) {
  return slots.filter(s => s.rank >= base && s.left > 0).sort((a, b) => a.rank - b.rank)[0]?.rank ?? null;
}
/** How long "until the end of its next turn" is as a PF2e effect that expires at a turn's end, counted from the monster's own initiative: 0 rounds
    when its turn this round is still to come (that turn is its next), 1 when its turn is under way or already over this round. */
export const untilNextTurnEnds = ({ ownTurn = false, acted = false } = {}) => ownTurn || acted ? 1 : 0;
/** What the refused enemy gets, in plain words for the champion's player (Rhea, 2026-11-11: so she never has to look it up; Player Core pp. 443 and
    446, checked on Archives of Nethys 2026-11-11). */
export const GUILT = {
  enfeebled: { name: "Enfeebled 2", words: "Enfeebled 2: -2 to its Strength-based attack rolls, its Strength-based damage and Athletics (Grapple, Trip, Shove). Best against a creature that fights with weapons, claws or teeth." },
  stupefied: { name: "Stupefied 2", words: "Stupefied 2: -2 to its spell attacks, spell DCs, Will saves and Intelligence-, Wisdom- and Charisma-based skills, and each spell it casts is lost unless it rolls 7 or higher on a flat check. Best against a spellcaster." }
};
/* the same two lines with pronoun markers (pronoun.mjs), so the window writes about the enemy as the rest of the module does (0.30.1) */
const GUILT_OF = { enfeebled: "Enfeebled 2: -2 to {their} Strength-based attack rolls, {their} Strength-based damage and Athletics (Grapple, Trip, Shove). Best against a creature that fights with weapons, claws or teeth.",
  stupefied: "Stupefied 2: -2 to {their} spell attacks, spell DCs, Will saves and Intelligence-, Wisdom- and Charisma-based skills, and each spell {they} {casts|cast} is lost unless {they} {rolls|roll} 7 or higher on a flat check. Best against a spellcaster." };
export const guiltLines = (who, forms = IT) => [`${who} refused your Glimpse of Redemption. Weight of Guilt: make {them} Enfeebled 2 or Stupefied 2? Both last until the end of {their} next turn.`, GUILT_OF.enfeebled, GUILT_OF.stupefied, "No answer in time is Enfeebled 2."].map(t => pro(t, forms));
export const guiltWords = (who, forms = IT) => guiltLines(who, forms).join(" ");
/** Why a character with a fitting reaction wasn't asked, for the GM's card. list: [{ name, reaction, why }] */
export function notAskedWords(list = []) {
  const W = { used: "reaction already used", delaying: "Delaying" };
  return list.map(x => `${x.name}: ${x.reaction} not asked (${W[x.why] ?? x.why}).`).join(" ");
}
/** What a hit did after the reactions to it, for everyone (Rhea, 2026-11-11, PR-10: every reduction says why, with the numbers).
    o: { name, enemy ("the creature" as players may name it), hit (the damage as rolled, after doubling or halving), taken (what came off HP and
    temporary HP), repent, resist (Glimpse refused: the resistance), less (Interposing Earth: what came off), block (Shield Block was used) } */
export function harmWords(o = {}) {
  const name = o.name ?? "Someone", enemy = o.enemy ?? "the creature";
  if (o.repent) return `${name} is unharmed: ${enemy} repented (Glimpse of Redemption).`;
  const why = [o.resist ? `Glimpse of Redemption, refused: resistance ${o.resist} to all of it` : null, o.less ? `Interposing Earth: ${o.less} less, and the barrier is destroyed` : null, o.block ? "Shield Block" : null].filter(Boolean);
  if (!why.length) return "";
  return `${name} takes ${o.taken ?? 0} (the hit was ${o.hit ?? 0}; ${why.join("; ")}).`;
}
/** A hit turned into a miss by a reaction, for everyone. */
export const missWords = (name, reaction, strike = "The hit") => `${strike} at ${name} becomes a miss: ${reaction === "Interposing Earth" ? "cover from Interposing Earth" : reaction}.`;
/** What the thinker is told when its monster must answer Glimpse of Redemption: words, never numbers (Rhea, 2026-11-11, reading a). */
export const CHOICES = ["repent", "refuse"];
export const choiceWords = ally => `As your blow lands on ${ally || "your enemy"}, a vision floods your mind: the harm you are doing, and another way. You must choose now. "repent": you hold back, and this blow does ${ally || "them"} no harm at all. "refuse": the blow lands, but weaker, and you are left weakened until the end of your next turn.`;

/* ---------- Moment E: a monster casts a spell (0.36.0) ----------
   Counteracting (Player Core pg. 431, checked on Archives of Nethys 2026-11-16): a spell's counteract rank is its rank; the check is the
   spellcasting attribute modifier plus the spellcasting proficiency bonus against the caster's spell DC. Critical success: counteract it if its
   rank is no more than 3 higher than yours; success: no more than 1 higher; failure: only if it is lower; critical failure: never. */
/** Does a counteract check of this degree (0 to 3) with my counteract rank beat theirs? */
export function counteracts(degree, mine, theirs) {
  const d = (Number(theirs) || 0) - (Number(mine) || 0);
  return degree === 3 ? d <= 3 : degree === 2 ? d <= 1 : degree === 1 ? d < 0 : false;
}
/** Which prepared copy (or slot) Counterspell spends, from those it could: [{ rank, ... }]. The lowest rank that still counteracts on a success
    (no more than 1 below the spell's), else the highest it has (Angel's reading, 0.36.0: keep the bigger slots for later). */
export function counterCopy(copies = [], target = 1) {
  const up = copies.filter(c => c.rank >= target - 1).sort((a, b) => a.rank - b.rank);
  return up[0] ?? [...copies].sort((a, b) => b.rank - a.rank)[0] ?? null;
}
/** DCs by spell rank and the rarity adjustments (GM Core pg. 52, checked on Archives of Nethys 2026-11-16). */
export const SPELL_RANK_DC = [14, 15, 18, 20, 23, 26, 28, 31, 34, 36, 39];
export const RARITY_ADJ = { common: 0, uncommon: 2, rare: 5, unique: 10 };
export const recognizeDc = (rank, rarity = "common") => SPELL_RANK_DC[Math.max(0, Math.min(10, Math.round(Number(rank) || 0)))] + (RARITY_ADJ[rarity] ?? 0);
/** The highest rank Recognize Spell identifies at once, by proficiency rank in the tradition's skill (0 untrained to 4 legendary). */
export const recognizeCap = prof => [0, 2, 4, 6, 10][Math.max(0, Math.min(4, Number(prof) || 0))];
export const TRADITION_SKILL = { arcane: "arcana", divine: "religion", occult: "occultism", primal: "nature" };
/** Recognize Spell's degree after its own rules: untrained, no better than failure; automatic, no worse than success. */
export function recognizeDegree(degree, { prof = 0, rank = 1, rarity = "common" } = {}) {
  if (!(Number(prof) > 0)) return Math.min(degree, 1);
  if (rarity === "common" && Number(rank) <= recognizeCap(prof)) return Math.max(degree, 2);
  return degree;
}
const RANK_WORD = r => { const n = Math.round(Number(r) || 0); return `${n}${n === 1 ? "st" : n === 2 ? "nd" : n === 3 ? "rd" : "th"}`; };
/** The window's words for one reaction to a cast (the player's; gm: the GM's card, which always names the spell). x: the row. */
export function castWords(x = {}, who = "A creature", spell = "a spell", gm = false) {
  const name = gm || x.slug?.startsWith("counterspell") ? spell : "a spell";
  if (x.slug?.startsWith("counterspell")) return `${who} is casting ${spell}. You have ${spell} ${x.copy?.kind === "spontaneous" ? "in your repertoire" : "prepared"}. Counterspell? It uses up your ${x.copy?.kind === "spontaneous" ? `${RANK_WORD(x.copy?.rank)}-rank slot` : `prepared ${spell}`}.`;
  if (x.slug === "spell-riposte") return `${who} is casting ${name} at you. React with ${x.reaction}?`;
  if (x.slug === "shadow-siphon") return `${who} is casting ${name} that will deal damage. React with ${x.reaction}?`;
  if (x.slug === "redirect-teleportation") return `${who} is casting ${gm ? spell : "a teleportation spell"}. React with ${x.reaction}?`;
  return `${who} is casting ${name}. React with ${x.reaction}?`;
}
/** What each reaction to a cast would do, in numbers worked out now (the sample's line under the button). */
export function castDetail(x = {}) {
  if (x.slug?.startsWith("counterspell") || x.slug === "shadow-siphon") return `counteract check ${x.mod >= 0 ? "+" : ""}${x.mod} vs DC ${x.dc}${x.slug === "shadow-siphon" ? "; on a success its damage is halved" : ""}`;
  if (x.slug === "nullify") return `counteracted automatically; you lose ${x.rank}d8 HP`;
  if (x.slug === "recognize-spell") return x.auto ? "you know it at once; the roll is only for a critical success" : `${x.skillName ?? "skill"} ${x.mod >= 0 ? "+" : ""}${x.mod}, rolled in secret`;
  if (KNOWN[x.slug]?.pause) return "then make it yourself";
  return "";
}
/** The public line after a counteract check (PR-10: every reduction says why). */
export function counterLine({ who = "Someone", reaction = "Counterspell", monster = "A creature", spell = "spell", total = 0, dc = 0, degree = 1, ok = false, halved = false } = {}) {
  const deg = ["Critical failure", "Failure", "Success", "Critical success"][degree] ?? "Failure";
  monster = String(monster).replace(/^A creature$/, "a creature");   /* mid-sentence (seen live in test build 1: "on A creature's Fear") */
  return `${who} uses ${reaction} on ${monster}'s ${spell}: counteract check ${total} vs DC ${dc}, ${deg.toLowerCase()}. ${ok ? (halved ? "The spell still works, but its damage is halved." : "The spell is lost.") : "The spell goes on."}`;
}
/** What Recognize Spell tells the player, by degree (0 to 3). */
export function recognizeWords(degree, spell = "the spell", rank = 1) {
  if (degree === 3) return `You recognize it: ${spell} (${RANK_WORD(rank)} rank). You get +1 to your save or AC against it.`;
  if (degree === 2) return `You recognize it: ${spell} (${RANK_WORD(rank)} rank).`;
  if (degree === 1) return "You don't recognize the spell.";
  return "You think you recognize it, but you are wrong: the GM tells you which spell you think it is.";
}
