/* Lythara Encounter Builder: monster minds in Foundry (0.24.0). Where each layer of a profile is kept and how a monster's profile is put together:
   the Minds Library (one GM-only journal, one page per entry, the entry in the page's flags: Rhea's decisions 8 and 9, design review 9), this
   encounter's lines in the brief on the scene (design review 10), a single monster's own profile, and what was agreed in this fight on the Combat.
   The rules themselves are pure, in minds.mjs. Everything here writes as a GM only. */
import { ID } from "./builder.mjs";
import { cleanBrief } from "./brief.mjs";
import { applyNature } from "./bands.mjs";
import { IT, formsOf, fromGender, guessPronoun } from "./pronoun.mjs";
import { addSuggestions, answerSuggestion, applyPartyLines, cleanPartyEntry, freshFights, partyForPacket, partyKey, relinkCandidates, seedFromToken } from "./party.mjs";
import { MIND_SCHEMA, LINES, applyLines, assemble, baseName, baseLevel, cleanEntry, cleanLines, exportData, forPacket, fromStatBlock, importPlan, kindKey, namesFor, rowLines } from "./minds.mjs";

const LIBRARY_NAME = "Minds Library (Encounter Builder)";
const gmOnly = () => { if (!game.user.isGM) throw new Error("Only a GM can do this."); };
const NONE = () => CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE;

/* ---------- the library ---------- */
/** The library's journal, or null before anything was saved to it. GM-only: no ownership for anyone, pages inherit. */
export const libraryJournal = () => game.journal.find(j => j.getFlag(ID, "mindsLibrary")) ?? null;
let making = null;
async function ensureLibrary() {
  gmOnly(); const have = libraryJournal(); if (have) return have;
  /* one create at a time on this page: two saves in a row must not make two journals */
  making ??= JournalEntry.create({ name: LIBRARY_NAME, ownership: { default: NONE() }, flags: { [ID]: { mindsLibrary: { schema: MIND_SCHEMA } } } }).finally(() => { making = null; });
  return making;
}
/* key → { entry, page }: read at every packet, so kept until a page of the library changes (main.mjs calls dropLibraryCache from the journal hooks) */
let index = null;
export const dropLibraryCache = () => { index = null; };
function libraryIndex() {
  if (index) return index; index = new Map();
  /* every journal with the flag is read: two GM pages saving for the first time at the same moment can make two (0.24.0 review 11); the first to hold a key wins */
  for (const j of game.journal.filter(x => x.getFlag(ID, "mindsLibrary"))) for (const page of j.pages) { const e = cleanEntry(page.getFlag(ID, "mind")); if (e && !index.has(e.key)) index.set(e.key, { entry: e, page }); }
  return index;
}
export const libraryEntries = () => [...libraryIndex().values()].map(x => x.entry);
export const libraryGet = key => libraryIndex().get(key)?.entry ?? null;
const pageText = e => `<p>${foundry.utils.escapeHTML(e.type === "people" ? "A people or family" : e.type === "band" ? "A kind of group" : "A kind of creature")} in the Minds Library. Read and edit it in the Minds Library window (the Encounters tools); what is typed on this page is not used.</p>`;
/** Save an entry: its lines are laid over what the library has (minds.mjs `applyLines`: Angel never replaces the GM's words unless `force`; a line
    given as null goes back to inherit). `by` is "gm" or "angel". Out: { entry, skipped, created }. */
export async function libraryPut(raw, { by = "gm", force = false, keepBy = false } = {}) {
  gmOnly(); const known = raw?.key ? libraryIndex().get(String(raw.key)) : null;
  /* an entry already here keeps its type and, unless a new one is given, its name: a write that names neither can't turn a people into a kind */
  const want = cleanEntry({ ...raw, type: known ? known.entry.type : raw?.type, name: raw?.name ?? known?.entry.name, lines: {} }); if (!want) throw new Error("A library entry needs a name.");
  /* a kind of group (0.26.0) holds a band's nature in place of profile lines */
  const have = libraryIndex().get(want.key), group = want.type === "band";
  const { lines, skipped } = group ? applyNature(have?.entry.nature ?? {}, raw.nature ?? {}, { by, force, keepBy, now: Date.now() }) : applyLines(have?.entry.lines ?? {}, raw.lines ?? {}, { by, force, keepBy, library: true, now: Date.now() });
  const entry = group ? { ...want, nature: lines } : { ...want, people: raw.people === undefined && have ? have.entry.people : want.people, lines };
  if (entry.type === "kind" && entry.people && !libraryGet(entry.people)) { if (raw.people !== undefined) throw new Error("That people isn't in the library."); entry.people = null; }   /* its people was removed: it stands on its own */
  const j = await ensureLibrary();
  if (have) await have.page.update({ name: entry.name, [`flags.${ID}.==mind`]: entry });
  else await j.createEmbeddedDocuments("JournalEntryPage", [{ name: entry.name, type: "text", text: { content: pageText(entry), format: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML }, flags: { [ID]: { mind: entry } } }]);
  dropLibraryCache(); return { entry, skipped, created: !have };
}
/** Remove an entry: the GM's own press in the window, or a chat doing it because she asked. A people's kinds stay, with no people. */
export async function libraryRemove(key) {
  gmOnly(); const have = libraryIndex().get(key); if (!have) return false;
  if (have.entry.type === "people") for (const x of [...libraryIndex().values()]) if (x.entry.people === key) await x.page.update({ [`flags.${ID}.==mind`]: { ...x.entry, people: null } });
  await have.page.delete(); dropLibraryCache(); return true;
}
export const libraryExport = () => exportData(libraryEntries());
/** Import a library file. Without `apply` nothing is written and the plan comes back (new, match, collision per entry). With it, new entries are added
    and a collision is replaced only when `theirs` names its key (the GM's choice, entry by entry). Peoples go first so their kinds find them. */
export async function libraryImport(data, { apply = false, theirs = [] } = {}) {
  const plan = importPlan(libraryEntries(), data); if (!apply || !plan.ok) return plan;
  gmOnly(); const j = await ensureLibrary(), take = new Set(theirs); let added = 0, replaced = 0, kept = 0;
  const rows = [...plan.rows].sort((a, b) => (a.entry.type === "people" ? 0 : 1) - (b.entry.type === "people" ? 0 : 1));
  for (const r of rows) {
    if (r.status === "match") continue;
    if (r.status === "collision" && !take.has(r.entry.key)) { kept++; continue; }
    const have = libraryIndex().get(r.entry.key), e = r.entry.people && !libraryGet(r.entry.people) ? { ...r.entry, people: null } : r.entry;   /* its people came with neither the file nor this library */
    if (have) { await have.page.update({ name: e.name, [`flags.${ID}.==mind`]: e }); replaced++; }
    else { await j.createEmbeddedDocuments("JournalEntryPage", [{ name: e.name, type: "text", text: { content: pageText(e), format: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML }, flags: { [ID]: { mind: e } } }]); added++; }
    dropLibraryCache();
  }
  return { ...plan, added, replaced, kept };
}

/* ---------- what kind of creature ---------- */
/** The facts `kindKey` needs. A built monster is a copy: its actor's flag names what it was copied from and how it was adjusted. A world actor that
    came from a compendium is that compendium creature's kind; one that didn't goes by its name and level. */
export function kindFacts(actor) {
  if (!actor) return null;
  const flagged = actor.getFlag?.(ID, "source") ?? null, from = flagged && !flagged.startsWith("Compendium.") ? fromUuidSync(flagged) : null, base = from ?? actor;
  /* how it was adjusted: a copy of a world actor carries that actor's own Elite or Weak; anything else the builder's flag or PF2e's own mark */
  const adjustment = (from ? from.system?.attributes?.adjustment : actor.getFlag?.(ID, "adjust") || actor.system?.attributes?.adjustment) || null;
  /* an unlinked token's own actor carries the token's name ("Wolf 2"): the kind is named after the world actor behind it, and a compendium
     creature after its pack entry (seen live 2026-11-11: Save to library offered "Wolf 1") */
  const world = actor.isToken ? actor.token?.baseActor ?? game.actors.get(actor.id) ?? actor : actor, pack = flagged?.startsWith("Compendium.") ? fromUuidSync(flagged) : null;
  const name = from ? from.name : pack?.name ?? world.name, level = from ? from.level : actor.level;
  /* its compendium source: the builder's flag; a compendium creature read straight from its pack is its own source (it carries no flag); a world
     actor's import record counts only while it still has the pack creature's name, so a named boss made from a stock creature is its own kind
     (0.24.0 review 6) */
  let source = flagged?.startsWith("Compendium.") ? flagged : actor.pack ? actor.uuid : null;
  if (!source) { const cs = base._stats?.compendiumSource ?? null, stock = typeof cs === "string" && cs.startsWith("Compendium.") ? fromUuidSync(cs) : null;
    if (stock && String(stock.name ?? "").trim().toLowerCase() === baseName(name, adjustment).trim().toLowerCase()) source = cs; }
  const src = from ? null : Number(actor._source?.system?.details?.level?.value), lv0 = Number.isFinite(src) ? src : null;   /* PF2e keeps the unadjusted level in the source */
  const facts = { source: typeof source === "string" && source.startsWith("Compendium.") ? source : null, name, level, adjustment, base: lv0 };
  return { ...facts, key: kindKey(facts), kindName: baseName(facts.name, facts.adjustment), baseLevel: baseLevel(facts.level, facts.adjustment, facts.base) };
}
const statFacts = actor => ({ traits: actor?.system?.traits?.value ?? [], int: actor?.system?.abilities?.int?.mod ?? null });

/* ---------- this encounter ---------- */
export const briefOf = scene => { const b = scene?.getFlag(ID, "brief"); return b ? cleanBrief(b) : null; };
/** Where a token stands in the build on its scene: { row, n } (its brief row and its number in the row), or null for a creature the build didn't place. */
export function builtRef(scene, tok) {
  const b = scene?.getFlag(ID, "build"); if (!b || tok?.getFlag(ID, "built") !== b.id) return null;
  const m = String(tok.getFlag(ID, "key") ?? "").match(/^c(\d+)-(\d+)$/), row = m ? scene.getFlag(ID, "brief")?.creatures?.[+m[1]] : null; if (!row) return null;
  /* the row must still be the creature this token was built from: a brief stored over a standing build can have other rows at that number, and
     their lines must never reach this monster (0.24.0 review 5). Then it counts as a creature the build didn't place. */
  const src = tok.actor?.getFlag?.(ID, "source") ?? null; if (src && row.uuid && src !== row.uuid) return null;
  return +m[2] < (row.count ?? 1) ? { row: +m[1], n: +m[2] } : null;
}
/* a kind the build didn't place keeps this encounter's lines on the scene, as a list (a kind's key has dots in it, which a flag's key can't) */
const looseOf = scene => (scene?.getFlag(ID, "minds") ?? []).filter(x => x && typeof x.kind === "string");
/** The layers a monster's profile is read from (minds.mjs `assemble` puts them in order). A creature on the party's side that Angel plays for the GM has
    only a profile the GM gave it herself: never the monsters' library (settled with Rhea, 2026-11-10). */
export function mindLayers(scene, tok, combat = null) {
  const actor = tok?.actor; if (!actor) return [];
  const mine = cleanLines(tok.getFlag(ID, "mind"));
  /* a monster that changed sides in this fight keeps its mind (0.30.0, design review 2): only a creature that began on the party's side has
     nothing but its own lines */
  const turned = actor.isOfType?.("npc") && combat?.getFlag(ID, "turns")?.sides?.[tok.id]?.from === "opposition";
  if (actor.alliance === "party" && !turned) return playsByPage(partyFor(actor)) ? [] : Object.keys(mine).length ? [{ from: "own", lines: mine }] : [];   /* a party member with a page in the Party section plays by it (0.45.0, F-9): mindOf */
  const kind = kindFacts(actor), ref = builtRef(scene, tok), brief = ref ? briefOf(scene) : null, row = brief?.creatures[ref.row] ?? null, layers = [];
  /* this fight's lines (release 4, 0.33.0): its kind's, with this one monster's laid over them line by line (a Discipline the leader's fall dropped
     to Loose no longer hides a line the fight-start look agreed for its whole kind) */
  const fight = combat?.getFlag(ID, "minds") ?? null, agreed = cleanLines({ ...((fight?.kinds ?? []).find(x => x?.kind === kind.key)?.lines ?? {}), ...(fight?.own?.[tok.id] ?? {}) });
  if (Object.keys(agreed).length) layers.push({ from: "fight", lines: agreed });
  const own = row ? row.own[String(ref.n)] : Object.keys(mine).length ? mine : null; if (own) layers.push({ from: "own", lines: own });
  const here = row ? rowLines(row) : cleanLines(looseOf(scene).find(x => x.kind === kind.key)?.lines); if (Object.keys(here).length) layers.push({ from: "encounter", lines: here });
  const entry = libraryGet(kind.key); if (entry) layers.push({ from: "kind", name: entry.name, lines: entry.lines });
  const people = entry?.people ? libraryGet(entry.people) : null; if (people) layers.push({ from: "people", name: people.name, lines: people.lines });
  layers.push({ from: "statblock", lines: fromStatBlock(statFacts(actor)) });
  return layers;
}
/** Who a profile's free text may not name unless the monster perceives them: everyone on the party's side on the scene, every other character in
    the world, and the party's other members (companions, familiars). Each by its whole name and by each word of it (`namesFor`: a character's from 3
    letters, another creature's from 4), so a first name alone is caught. Users aren't in it: an account's name isn't a creature's, and common ones
    ("Will") would hold ordinary lines (0.24.0 review 9). labelOf(tokenId): that creature's label when this monster perceives it or knows it as
    an ally, else null. The same shape `noteForThinker` takes for the GM's note. */
export function partyPeople(scene, labelOf = () => null) {
  const out = [], onScene = new Set(), names = (a, ...ns) => [...new Set(ns.flatMap(n => namesFor(n, a.isOfType?.("character") ? 3 : 4)))];
  for (const t of scene?.tokens.contents ?? []) { const a = t.actor; if (!a || a.alliance !== "party") continue; onScene.add(a.id); out.push({ names: names(a, t.name, a.name), label: labelOf(t.id) ?? null }); }
  const others = new Map(); for (const a of [...game.actors.filter(x => x.isOfType?.("character")), ...(game.actors.party?.members ?? [])]) if (a && !onScene.has(a.id)) others.set(a.id, a);
  for (const a of others.values()) out.push({ names: names(a, a.name), label: null });
  return out;
}
/** The words to write about a creature with (0.30.1, R-2; Rhea, 2026-11-12 and 13): a character by its sheet's Gender box; anything else by the
    Pronoun line of its mind profile, which the stat block fills when nobody wrote one ("it" for an animal or a mindless creature, "they" for
    the rest). A party-side creature with no profile of its own gets the stat block's pick too. Out: forms for pronoun.mjs `pro`. */
export function pronounOf(tok, combat = null) {
  const actor = tok?.actor; if (!actor) return IT;
  if (actor.isOfType?.("character")) return formsOf(fromGender(actor.system?.details?.gender?.value));
  const line = assemble(mindLayers(tok.parent ?? null, tok, combat)).lines.pronoun;
  return formsOf(line ?? guessPronoun({ ...statFacts(actor), mind: fromStatBlock(statFacts(actor)).mind.pick }));
}
/** A monster's profile as things stand: { assembled, mind, held } (`mind` is what its packet carries, null when nothing is left to say). */
export function mindOf(scene, tok, combat = null, labelOf = () => null) {
  /* a party member with a page (0.45.0, F-9, 9-2): its own lines, through the same name gate; the pronoun from its sheet */
  const page = partyOn(tok, combat);
  if (playsByPage(page)) { const f = pronounOf(tok, combat), { mind, held } = partyForPacket(page, partyPeople(scene, labelOf), `${f.they}/${f.them}/${f.their}`); return { assembled: { lines: {}, own: false, party: page }, mind, held }; }
  const assembled = assemble(mindLayers(scene, tok, combat)), { mind, held } = forPacket(assembled, partyPeople(scene, labelOf));
  return { assembled, mind, held };
}

/* ---------- writing this encounter's lines ---------- */
/* a write from Monster Minds (minds lines, bands) is stamped `mindsWrite`, so an open Build window takes in only those and keeps its unsaved rows
   (0.39.11, the overnight review's P-1); a brief sent from a chat carries no stamp and is loaded whole. A time, so two writes in a row both show. */
export const writeBrief = (scene, brief) => scene.update({ [`flags.${ID}.==brief`]: cleanBrief(brief), [`flags.${ID}.mindsWrite`]: Date.now() });
/** Change lines of a profile on a scene. ref says whose: { row } a build row's kind for this encounter; { row, n } one built monster's own;
    { kind } a kind the build didn't place, for this scene; { token } one such monster's own. lines: key → words, { pick, text }, or null to take the
    line away. Angel never replaces the GM's words unless `force`. Out: { lines, skipped }. */
export async function setLines(scene, ref, lines, { by = "gm", force = false, keepBy = false, seeded = false } = {}) {
  gmOnly(); const opts = { by, force, keepBy, now: Date.now() };
  if (Number.isInteger(ref?.row)) {
    const brief = briefOf(scene), row = brief?.creatures[ref.row]; if (!row) throw new Error("This map's build has no such row.");
    if (Number.isInteger(ref.n)) { if (ref.n < 0 || ref.n >= row.count) throw new Error("That row has no such monster.");
      /* its first own line starts its own profile as a copy of what it follows now (decision 6; 0.33.1, review: a profile of that one line alone
         dropped every line of its kind and this encounter) */
      if (!seeded && !row.own[String(ref.n)]) { const tok = scene.tokens.find(t => { const b = builtRef(scene, t); return b?.row === ref.row && b?.n === ref.n; }); if (tok) { await giveOwn(scene, tok); return setLines(scene, ref, lines, { by, force, keepBy, seeded: true }); } }
      const r = applyLines(row.own[String(ref.n)] ?? {}, lines, opts);
      if (Object.keys(r.lines).length) row.own[String(ref.n)] = r.lines; else delete row.own[String(ref.n)]; await writeBrief(scene, brief); return r; }
    const r = applyLines(row.mind, lines, opts); row.mind = r.lines; await writeBrief(scene, brief); return r;
  }
  if (ref?.token) { const tok = scene.tokens.get(ref.token); if (!tok) throw new Error("That token isn't on this scene.");
    const at = builtRef(scene, tok); if (at) return setLines(scene, at, lines, { by, force, keepBy });
    if (!Object.keys(cleanLines(tok.getFlag(ID, "mind"))).length) await giveOwn(scene, tok);   /* the same for a monster the build didn't place */
    const r = applyLines(tok.getFlag(ID, "mind") ?? {}, lines, opts); await tok.update({ [`flags.${ID}.==mind`]: Object.keys(r.lines).length ? r.lines : null }); return r; }
  if (typeof ref?.kind === "string") { const list = looseOf(scene), had = list.find(x => x.kind === ref.kind), r = applyLines(had?.lines ?? {}, lines, opts);
    const next = [...list.filter(x => x.kind !== ref.kind), ...(Object.keys(r.lines).length ? [{ kind: ref.kind, lines: r.lines }] : [])];
    await scene.update({ [`flags.${ID}.==minds`]: next }); return r; }
  throw new Error("Whose profile? Give a row, a row and number, a kind or a token.");
}
/** Give one monster its own profile (Rhea's decision 6): a copy of the profile it follows now, which then stops following its kind's. One that
    already has its own keeps it: nothing is written over (0.24.0 review 3). */
export async function giveOwn(scene, tok) {
  gmOnly(); if (mindLayers(scene, tok).some(l => l.from === "own")) throw new Error(`${tok.name} already has its own profile.`);
  const layers = mindLayers(scene, tok).filter(l => l.from !== "fight" && l.from !== "own"), a = assemble(layers);
  const lines = Object.fromEntries(LINES.filter(k => a.lines[k]).map(k => [k, { ...(a.lines[k].pick ? { pick: a.lines[k].pick } : {}), text: a.lines[k].text, by: a.lines[k].by }]));
  const at = builtRef(scene, tok);
  if (at) { const brief = briefOf(scene); brief.creatures[at.row].own[String(at.n)] = cleanLines(lines); await writeBrief(scene, brief); }
  else await tok.update({ [`flags.${ID}.==mind`]: cleanLines(lines) });
  return cleanLines(lines);
}
/** Take a monster's own profile away: it follows its kind again. */
export async function dropOwn(scene, tok) {
  gmOnly(); const at = builtRef(scene, tok);
  if (at) { const brief = briefOf(scene); delete brief.creatures[at.row].own[String(at.n)]; await writeBrief(scene, brief); }
  else await tok.update({ [`flags.${ID}.==mind`]: null });
}
/** Everything the Monster Minds window lists for a scene: the build's rows, then the kinds of monsters the build didn't place; under each, the
    monsters with a profile of their own. Party-side creatures Angel plays come last, each on its own. */
export function mindRows(scene) {
  const brief = briefOf(scene), build = scene?.getFlag(ID, "build"), rows = [], loose = new Map(), party = [];
  const npcs = (scene?.tokens.contents ?? []).filter(t => t.actor && (t.actor.alliance === "party" ? !!t.getFlag(ID, "run") : t.actor.isOfType?.("npc")));
  if (brief && build) brief.creatures.forEach((c, g) => { const toks = npcs.filter(t => { const r = builtRef(scene, t); return r?.row === g; });
    rows.push({ ref: { row: g }, name: c.name || toks[0]?.name || "Creature", count: toks.length || c.count, tokens: toks.map(t => t.id), uuid: c.uuid,
      own: Object.keys(c.own).map(n => { const t = toks.find(x => builtRef(scene, x)?.n === +n); return { ref: { row: g, n: +n }, name: t?.name ?? `${c.name} ${+n + 1}`, token: t?.id ?? null }; }) }); });
  for (const t of npcs) { if (builtRef(scene, t)) continue; const a = t.actor;
    if (a.alliance === "party") { party.push({ ref: { token: t.id }, name: t.name, count: 1, tokens: [t.id], party: true, owned: !!a.hasPlayerOwner, own: [], learn: learnableActor(a), page: !!partyFor(a) }); continue; }   /* owned: a player's creature, which the module no longer plays (B-7, 0.31.0) */
    if (t.getFlag(ID, "cache") || a.isOfType?.("loot")) continue;
    const k = kindFacts(a), row = loose.get(k.key) ?? { ref: { kind: k.key }, name: k.kindName, count: 0, tokens: [], own: [] }; row.count++; row.tokens.push(t.id);
    if (Object.keys(cleanLines(t.getFlag(ID, "mind"))).length) row.own.push({ ref: { token: t.id }, name: t.name, token: t.id });
    loose.set(k.key, row); }
  return [...rows, ...loose.values(), ...party];
}
/** The actor a row stands for: one of its tokens, or the creature its brief row names (async: a compendium creature has to be fetched). */
export async function rowActor(scene, row) { const t = (row.tokens ?? []).map(id => scene.tokens.get(id)).find(x => x?.actor); return t?.actor ?? (row.uuid ? await fromUuid(row.uuid).catch(() => null) : null); }
/** A row's profile for the window: its layers (without any one monster's own) and the result. For an own-profile ref, that monster's. */
export async function rowProfile(scene, row, ref = row.ref) {
  const tok = ref.token ? scene.tokens.get(ref.token) : Number.isInteger(ref.n) ? scene.tokens.contents.find(t => { const r = builtRef(scene, t); return r?.row === ref.row && r.n === ref.n; }) : (row.tokens ?? []).map(id => scene.tokens.get(id)).find(Boolean);
  const actor = tok?.actor ?? await rowActor(scene, row), single = !!ref.token || Number.isInteger(ref.n) || !!row.party;
  let layers;
  if (tok) layers = mindLayers(scene, tok).filter(l => l.from !== "fight" && (single || l.from !== "own"));
  else { /* no token left on the map: the brief row and the library still say what it would be */
    const kind = actor ? kindFacts(actor) : null, b = briefOf(scene), r = Number.isInteger(ref.row) ? b?.creatures[ref.row] : null, entry = kind ? libraryGet(kind.key) : null, people = entry?.people ? libraryGet(entry.people) : null;
    layers = [...(single && r?.own[String(ref.n)] ? [{ from: "own", lines: r.own[String(ref.n)] }] : []), ...(r && Object.keys(rowLines(r)).length ? [{ from: "encounter", lines: rowLines(r) }] : []), ...(entry ? [{ from: "kind", name: entry.name, lines: entry.lines }] : []), ...(people ? [{ from: "people", name: people.name, lines: people.lines }] : []), ...(actor ? [{ from: "statblock", lines: fromStatBlock(statFacts(actor)) }] : [])];
  }
  return { layers, assembled: assemble(layers), kind: actor && actor.alliance !== "party" ? kindFacts(actor) : null, token: tok?.id ?? null };
}

/** Whose profile lives in the Party section (0.45.0): a character on the party's side, or a member of PF2e's party (the same test as the record's). */
export const learnableActor = a => !!a && (!!game.actors.party?.members?.some(m => m.id === worldId(a)) || (!!a.isOfType?.("character") && a.alliance === "party"));
/* ---------- the Party section (0.45.0, F-9): one page per party member, tied to its actor by id ---------- */
/** The world actor behind a token's actor: an unlinked token's synthetic actor has the world actor's id. */
const worldId = actor => actor?.isToken ? (actor.token?.baseActor?.id ?? actor.id) : actor?.id ?? null;
export const partyEntries = () => libraryEntries().filter(e => e.type === "party");
/** A party member's page by its actor (or the actor's id), or null. */
export const partyFor = actorOrId => { if (typeof actorOrId === "string" && actorOrId.startsWith("party:")) return libraryGet(actorOrId);   /* a page's own key (review 3) */
  const id = typeof actorOrId === "string" ? actorOrId : worldId(actorOrId); return id ? libraryGet(partyKey(id)) : null; };
/** Whether a creature plays by its page: only once the page has a line (review 17); a page made but still empty leaves the token's old lines in force. */
export const playsByPage = page => !!page && Object.keys(page.lines ?? {}).length > 0;
/** The page a token in a fight plays by: a party-side creature with a page, never a monster that changed sides. */
export function partyOn(tok, combat = null) {
  const actor = tok?.actor; if (!actor || actor.alliance !== "party") return null;
  if (actor.isOfType?.("npc") && combat?.getFlag(ID, "turns")?.sides?.[tok.id]?.from === "opposition") return null;
  return partyFor(actor);
}
/** What a party member is, for its page's list line: its class (or "NPC") and whether a player plays it (a companion otherwise). */
const partyFacts = actor => ({ actorId: worldId(actor), name: (actor.isToken ? actor.token?.baseActor?.name : null) ?? actor.name, kind: actor.hasPlayerOwner ? "player" : "companion", what: actor.class?.name ?? (actor.isOfType?.("npc") ? "NPC" : "") });
async function writeParty(entry) {
  gmOnly(); const e = cleanPartyEntry(entry); if (!e) throw new Error("A party page needs its actor and a name.");
  const have = libraryIndex().get(e.key) ?? null, j = await ensureLibrary();
  if (have) await have.page.update({ name: e.name, [`flags.${ID}.==mind`]: e });
  else await j.createEmbeddedDocuments("JournalEntryPage", [{ name: e.name, type: "text", text: { content: `<p>A party member's page in the Minds Library. Read and edit it in the Minds Library window (the Encounters tools); what is typed on this page is not used.</p>`, format: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML }, flags: { [ID]: { mind: e } } }]);
  dropLibraryCache(); return e;
}
/** A party member's page, made if it has none (her press on "Make a page", or Angel drafting a first profile). A token's own lines from before
    0.45.0 are carried over where they mean the same (party.mjs `seedFromToken`), so nothing she wrote on it is lost. */
export async function partyEnsure(actorOrId, { token = null } = {}) {
  gmOnly(); const actor = typeof actorOrId === "string" ? game.actors.get(actorOrId) : actorOrId; if (!actor) throw new Error("No such actor.");
  const have = partyFor(actor); if (have) return { entry: have, created: false };
  const seed = token ? seedFromToken(cleanLines(token.getFlag(ID, "mind"))) : {};
  return { entry: await writeParty({ ...partyFacts(actor), lines: seed }), created: true };
}
/* the cache is dropped first (review 6): a write from another page since this one last read must not be overwritten by an older copy */
const partyOrThrow = ref => { dropLibraryCache(); const e = partyFor(ref); if (!e) throw new Error("That party member has no page in the Minds Library."); return e; };
/** Change lines of a page: her own words, from the window or written for her when she asked (review 30: always hers; Angel's words reach a
    page only as a suggestion she accepts, 9-3). Out: { entry, skipped }. */
export async function partySet(ref, lines) {
  const e = partyOrThrow(ref), r = applyPartyLines(e.lines, lines, { by: "gm", force: true, now: Date.now() });
  return { entry: await writeParty({ ...e, lines: r.lines }), skipped: r.skipped };
}
/** Angel's suggestions (the daily check, or her first draft), waiting for the GM's Accept or Keep mine. Out: { entry, added, dropped }. */
export async function partySuggest(ref, payload = {}) {
  const e = partyOrThrow(ref), r = addSuggestions(e, payload, { now: Date.now(), newId: i => `${foundry.utils.randomID(8)}${i}` });
  if (r.entry) await writeParty(r.entry); return r;
}
/** Her answer to a suggestion: "accept" or "keep". */
export async function partyAnswer(ref, id, answer) {
  const e = partyOrThrow(ref), r = answerSuggestion(e, id, answer, { now: Date.now() }); if (!r) throw new Error("That suggestion isn't waiting any more.");
  return writeParty(r.entry);
}
/** Tie a page to another actor (9-2): the character was rebuilt, or the page came from another world. Its lines, suggestions and counts go with it. */
export async function partyRelink(ref, actorId) {
  const e = partyOrThrow(ref), actor = game.actors.get(actorId); if (!actor) throw new Error("No such actor.");
  if (partyFor(actor) && partyFor(actor).key !== e.key) throw new Error(`${actor.name} already has a page.`);
  const have = libraryIndex().get(e.key); const next = cleanPartyEntry({ ...e, ...partyFacts(actor), formerIds: [...(e.formerIds ?? []), e.actorId] });   /* the old id kept, so fights saved under it still count (review 15) */
  await have.page.update({ name: next.name, [`flags.${ID}.==mind`]: next }); dropLibraryCache(); return next;
}
/** Pages whose actor isn't in this world, each with the actors that have its name (brackets aside: "Odile Fenn (L5 test)" finds "Odile Fenn"). */
export function partyLost() {
  const bare = n => String(n ?? "").replace(/\([^)]*\)/g, " ").replace(/\s+/g, " ").trim(), actors = game.actors.contents.filter(a => !partyFor(a)).map(a => ({ id: a.id, name: bare(a.name) }));   /* an actor that has a page of its own isn't offered (review 16) */
  return partyEntries().filter(e => !game.actors.get(e.actorId)).map(e => ({ entry: e, candidates: relinkCandidates({ ...e, name: bare(e.name) }, actors) }));
}
/** The saved fights' party records (9-1), for the daily check: every History page that has one, with its night's date. Characters Angel played
    in a fight are marked; `fresh` lists, per page, the fights it hasn't learned from yet (party.mjs `freshFights`). since: "YYYY-MM-DD". */
export function partyRecords({ since = null } = {}) {
  const folder = game.folders.find(f => f.type === "JournalEntry" && f.getFlag(ID, "history")), fights = [];
  for (const j of game.journal.filter(x => folder && x.folder?.id === folder.id)) { const date = j.getFlag(ID, "historyDate") ?? null; if (since && date && date < since) continue;
    for (const p of j.pages) { const rec = p.getFlag(ID, "partyRecord"); if (!rec?.members) continue; fights.push({ combatId: p.getFlag(ID, "historyCombat"), date, scene: p.name, members: rec.members }); } }
  fights.sort((a, b) => String(a.date).localeCompare(String(b.date)));
  return { fights, fresh: Object.fromEntries(partyEntries().map(e => [e.actorId, freshFights(e, fights).map(f => ({ combatId: f.combatId, date: f.date, scene: f.scene, turns: f.me.turns }))])) };
}
