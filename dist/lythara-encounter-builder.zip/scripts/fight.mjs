/* A fight's turns. One named account does the work (the runner: the Angel Bridge unless the setting says otherwise), on its own page with the
   fight scene open; any other GM's browser only asks it to, through the Combat's flag. Everything is kept on that flag, so a reload or a
   summarised chat loses nothing. It runs Strikes, Strides, Steps, Crawls, Fly, Swim, Climb, Release, Stand, Drop Prone, Take Cover, abilities, spells, Hide, Sneak, Seek, Interact, Delay and fleeing off the map; what is still to come is in the repo's docs/features and the project's plan doc. */
import { handedOn, withoutAsks, couldSetOff, untouched, settleFrom, settleWait, CHANGEABLE, NOTE_MAX, changeProblem, describeStep, nameWords, noteForThinker, planPrint } from "./turn.mjs";
import { CHECK_OUTCOMES, CHECK_WORD, FOLLOW_UPS, MAX_REPLANS, OUTCOMES, SAVE_MULT, POSTURES, SIDES, WORD, absorbOwn, movedOn, shouldFall, shouldSink, edgeSides, areaHurt, forThinker, listWords, nextArea, nextSpell, spellActions, spellMultiplier, spellRange, spellTargets, followUpOutcome, lastAction, nextAbility, changesSince, checkPlan, coverAfterTaking, currentOf, damageOptions, describeChanges, doneStep, nextCommand, nextPoint, endsCover, isMove, latestNote, nextAction, nextCover, nextMove, nextPosture, nextStealth, requestBusy, revealsAfter, revealsBefore, situationOf, spentBy, strikeIds, nextInteract, nextClimb, climbResult, tookTurn } from "./turn.mjs";
import { BURROW_DEPTH, FT, distanceBetween, burrowWorld, crossesWalls, cutShort, diagonalsIn, featureNear, findRoute, findStep, flyWaypoints, flyWorld, footprintAt, heightWhenCut, rockSquares, routeWordsIt, routeWords, swimWorld, glideWorld, treeTop, treesBeside, wallSquares, waterKinds, waterUnder } from "./move.mjs";
import { actionsFor, assignLabels, canTarget, flatDC, groundAround, healthEntries, healthWord, labelsOf, lightAt, packetOf, perceiveOne, plainText, remember, sensesOf, strikeMods, visibleConditions } from "./perceive.mjs";
import { giveOwn, kindFacts, mindLayers, mindOf, partyPeople, pronounOf, setLines } from "./library.mjs";
import { LOOK_ID, LOOK_TRIES, cleanLook, escapeLines, isLook, knowsAfter, lookOut, lookPacket, lookWaiting, openItems } from "./look.mjs";
import { lineWords } from "./minds.mjs";
import { IT, pro } from "./pronoun.mjs";
import { PLANNED, bandKeyOf, bandOf, bandPacket, bandsOf, disciplineOf, fightBand, jobGroups, langsOf, leaderOf, membersOf, natureLayers, planOf, secondOf, shiftBandSpots } from "./bandlib.mjs";
import { natureOf } from "./bands.mjs";
import { HOLDS, NEVER_GIVES_UP, applyHeard, canOrder, cleanOrder, fallBackWords, fallOutcome, dropperOf, holdWords, fromPending, hearing, labelsIn, logWords, orderLanguage, orderWords, ordersForPacket, roundLine, shiftHeard, toPending } from "./orders.mjs";
import { namer } from "./history.mjs";
import { RUNGS, STORE_MAX, GM_LINE_MAX, evict, forPacket, gmLine, lineKey, render, rethinkFor, rungOf, severity, sideWords, spellWords, witnessLines } from "./memory.mjs";
import { readMap, partyLevels, partySize, suggestedLevel } from "./builder.mjs";
import { aimArea, aimWords, alliesCaught, burstReachable, caughtBy, shapeOf, squaresNear } from "./area.mjs";
import { AC_ROWS, TRADITION_SKILL, castDetail, castWords, counterCopy, counterLine, counteracts, makesItself, recognizeDc, recognizeDegree, recognizeWords, CHOICES, GUILT, KNOWN, MONSTER_REACTIONS, answerWords, barrierStats, barrierEdge, barrierLabel, barrierCardWords, slabHit, slabWords, READY_WAIT_MS, cleanTrigger, readiedWords, acAdds, canReact, castRank, coverInDc, choiceWords, earthLess, glimpseResistance, guiltLines, guiltWords, harmWords, missWords, notAskedWords, shieldGrantsBlock, spentRows, untilNextTurnEnds, readCard, cardTrigger, degreeAgainst, equipTrigger, finished, fits, gateWords, moveTrigger, proneOffTrigger, stepsAnswerWords, reactionStrike, reactionsOf, routeGates, squaresAlong, untilFor } from "./react.mjs";
import { MAX_TRIES, choiceOut, cleanChoice, cleanMeta, cleanPlan, eventOut, hello, isChoice, listening, live, nextSeq, pickEvent, stale, stallOf, text, waitSeconds } from "./brain.mjs";
import { esc } from "./journal.mjs";
import { breaksYield, cleanGmSay, gestureWords, orderHtml, sayHtml, speechFor, speechForPacket, speechLanguage, understands } from "./speech.mjs";
import { canCommand, commandForPacket, commandInForce, commandSpent, commandTag, commandWords, degreeOf, outcomeOf, resultWords } from "./command.mjs";
import { allyGets, allyResult, canPointOut, hasLost, pointLines, previewLines, squareFeet, withBelief, wrongSquare } from "./pointout.mjs";
import { changedForPacket, sideCardWords, sideChange, sideTag, sideWord } from "./sides.mjs";
import { HOLD_MS, apiNoteWords, modelFor, routeOf, wakeState, whoGets } from "./route.mjs";

const ID = "lythara-encounter-builder", WORKBENCH = "xdy-pf2e-workbench", TOOLBELT = "pf2e-toolbelt", VISIONER = "pf2e-visioner", HUD = "pf2e-hud", GROUND_RADIUS = 10, STEP_MS = 20000, SETTLE_MS = 400, SCENE_MS = 30000, RESUMABLE = ["ready", "running", "held", "stopped", "saves"];
export const runnerName = () => game.settings.get(ID, "runner");
const runner = () => game.users.getName(runnerName());
const isRunner = () => game.user.isGM && runner()?.id === game.user.id;
/** What the card should say when nobody can run a turn; null when the runner is there. */
export function runnerProblem() {
  const u = runner(); if (!u) return `There's no account called ${runnerName()}, so monster turns wait. Change it in the module's settings, or play this turn yourself.`;
  return u.active ? null : `${u.name} is offline, so monster turns wait. They carry on when it's back, or play this turn yourself.`;
}
const turns = combat => ({ requests: {}, ...combat.getFlag(ID, "turns") });   /* memory can land before the first request */
export const applySetting = () => game.settings.get(ID, "applyMonsterDamage");
/* frequent writes: don't make the tracker redraw for each one. Two browsers write here, so only the change goes: a whole copy of the request could
   put back what the other just wrote. */
/* Each creature's own pronoun (0.30.1, R-2; pronoun.mjs). The module's sentences about a creature are written with markers ("{they} {is|are}")
   and turned into its words: `P(tok)` gives them. A request's note is about the monster whose turn it is, so `save` and `saveTurns` turn a note's
   markers on the way in: nothing with a marker is ever stored. Text about anyone else is turned where it is written. */
const P = (tok, combat = game.combat ?? null) => { try { return pronounOf(tok, sceneOf(combat) === tok?.parent ? combat : null); } catch (e) { console.warn(`${ID} | pronoun`, e); return IT; } };
const voiced = (combat, tokenId, text) => typeof text === "string" && text.includes("{") ? pro(text, P(sceneOf(combat)?.tokens.get(tokenId), combat)) : text;
async function save(combat, id, change) {
  for (const k of ["note", "verdict", "changeVerdict"]) if (typeof change[k] === "string") change = { ...change, [k]: voiced(combat, change.tokenId ?? turns(combat).requests?.[id]?.tokenId, change[k]) };
  if (["state", "pos", "log"].some(k => k in change)) change = { ...change, since: clock() };   /* it moved on: the stall check counts from here */
  await combat.update({ [`flags.${ID}.turns.requests.${id}`]: change }, { render: false, [ID]: { quiet: true } }); }
const saveTurns = (combat, change) => combat.update(Object.fromEntries(Object.entries(change).map(([k, v]) => { const m = /^requests\.([^.]+)\.note$/.exec(k); return [`flags.${ID}.turns.${k}`, m ? voiced(combat, turns(combat).requests?.[m[1]]?.tokenId, v) : v]; })), { render: false, [ID]: { quiet: true } });
const request = (combat, id) => turns(combat).requests[id];
export const currentRequest = combat => currentOf(turns(combat).requests, combat.round, combat.combatant?.id);   /* only this turn's: an old unfinished one stays out of the way */
/** The last finished turn, if it left something for the GM to read. */
export const lastNote = combat => latestNote(turns(combat).requests);
/** A party member the GM plays (Rhea, 2026-11-09: "the option is OK to be there, but always have the default be unticked"): a character no player owns.
    Angel can run it like a monster, only when the GM ticks it; the module never ticks it. */
export const partyMember = actor => !!actor?.isOfType?.("character") && !actor.hasPlayerOwner && actor.alliance === "party";   /* a villain built as a character isn't one (0.18.0 review) */
/** Who Angel can run: a monster (any NPC, on either side) or a party member the GM plays. */
export const runnable = t => (!!t?.actor?.isOfType?.("npc") && !t.actor.hasPlayerOwner) || partyMember(t?.actor);   /* 0.30.0 (R3-15): the module stops playing a monster once a player owns it */
/** On the party's side (a party member, or an NPC fighting with the party): fleeing off the map is a monster's escape, not theirs. */
const onParty = actor => actor?.alliance === "party";
/** What the thinker calls a character (0.18.0): never its name (the module's rule: no PC's name goes to the thinker), but its ancestry and class. */
const kindOf = actor => [actor?.ancestry?.name, actor?.class?.name].filter(Boolean).join(" ") || (actor?.type === "familiar" ? "familiar" : actor?.isOfType?.("npc") ? "companion" : "party member");
/** Only a monster's own kind of name goes to the thinker: an NPC no player owns. A character, a familiar or a player's companion (often named after its
    master or given a pet's name) goes as what it is (0.18.0 review). */
const nameFor = tok => tok.actor?.isOfType?.("npc") && !tok.actor.hasPlayerOwner ? tok.name : kindOf(tok.actor);
/** HP with temporary HP, for the history's "from 18 to 9" (kept on the step's record when damage is applied). */
const hpNow = tok => (tok?.actor?.hitPoints?.value ?? 0) + (tok?.actor?.hitPoints?.temp ?? 0);
const tokenOf = (combat, c) => c?.token ?? null;
/* a chance to stop before each stage, which the reload tests use */
function stepGate(stage, id) { return Hooks.call(`${ID}.step`, stage, id) !== false; }

/* ---------- the fight's scene ---------- */
/** The runner needs the fight on its canvas: reach, distance and targets all use it, and Visioner answers "observed" for tokens it can't find. Anyone
    activating another scene pulls this page along, so it's checked before everything that uses the canvas. */
async function ensureScene(combat) {
  for (let tries = 0; tries < 3; tries++) {   /* a view can lose to an activation already on its way, so look again */
    if (canvas.scene?.id === sceneOf(combat)?.id && canvas.ready) return true;
    try { await within(sceneOf(combat).view(), SCENE_MS, "Opening the fight map took too long."); } catch (e) { console.error(`${ID} | scene`, e); return false; }
    await new Promise(r => setTimeout(r, 500));
  }
  return canvas.scene?.id === sceneOf(combat)?.id && canvas.ready;
}
const within = (work, ms, words) => { let timer; return Promise.race([work, new Promise((_, rej) => { timer = setTimeout(() => rej(new Error(words)), ms); })]).finally(() => clearTimeout(timer)); };

/* ---------- what a monster perceives ---------- */
/* Worked out here rather than asked of Visioner: with its automatic system off it answers "observed" for a pair with no record, walls or no walls, and a monster
   token isn't a vision source. So: core's own sight and sound tests on the fight scene, the light at the target, the monster's senses, then Visioner's record on top. */
const onFightScene = combat => canvas.ready && canvas.scene?.id === sceneOf(combat)?.id;
/** The monster's Strikes with the ids plans use. */
const strikesWithIds = actor => { const list = (actor.system.actions ?? []).filter(a => a.type === "strike" && (actor.isOfType?.("npc") || (a.ready !== false && a.visible !== false))),   /* a character's Strike with a stowed weapon isn't ready; an NPC's always counts (a Goblin's worn shortbow shoots) */ ids = strikeIds(list.map(a => ({ slug: a.slug ?? a.item?.id, ranged: !!a.item?.isRanged }))); return list.map((a, i) => ({ id: ids[i], strike: a })); };
const conditionsOn = actor => (actor.conditions?.active ?? []).map(c => c.slug);
const squareOf = (tok, scene) => { const px = scene.grid.size, d = scene.dimensions; return [Math.round((tok.x - d.sceneX) / px), Math.round((tok.y - d.sceneY) / px)]; };
/** Where a token really is for distances, as PF2e's `distanceTo` measures it (its `mechanicalBounds`, PF2e 8.7.0): { pos, span } in squares, pos fractional
    when it sits off the grid (a Small creature dropped between squares), span its real width. A Tiny token counts as the whole square holding its top-left
    corner. Routes, occupancy and the square the thinker is told use squareOf and sizeOf. Rounded to a millionth so pixel arithmetic can't land a hair off a
    whole square. */
const placeOf = (tok, scene) => {
  const px = scene.grid.size, d = scene.dimensions, f = v => Math.round(v * 1e6) / 1e6, x = f((tok.x - d.sceneX) / px), y = f((tok.y - d.sceneY) / px), w = Number(tok.width) || 1;
  return (tok.isTiny ?? w < 1) ? { pos: [Math.floor(x), Math.floor(y)], span: 1 } : { pos: [x, y], span: Math.max(1, w) };
};
/** Is the token off the grid (its top-left corner between squares)? Its square is then the one it rounds to, while distances are from where it is. */
const offGrid = (tok, scene) => { const { pos } = placeOf(tok, scene); return !Number.isInteger(pos[0]) || !Number.isInteger(pos[1]); };
/** How many squares a side a token covers: 1 for Medium and smaller, 2 for Large... */
const sizeOf = tok => Math.max(1, Math.round(tok.width ?? 1));
const same = (a, b) => a?.[0] === b?.[0] && a?.[1] === b?.[1];
function lightOn(point, scene) {
  const fx = canvas.effects, sources = [];
  for (const s of fx.darknessSources ?? []) if (s.active && s.shape?.contains?.(point.x, point.y)) sources.push({ darkness: true });
  for (const s of fx.lightSources ?? []) { if (!s.active || s instanceof foundry.canvas.sources.GlobalLightSource || !s.shape?.contains?.(point.x, point.y)) continue; sources.push({ reach: Math.hypot(point.x - s.x, point.y - s.y) <= (s.data?.bright ?? 0) ? "bright" : "dim" }); }
  return lightAt({ sceneLevel: scene.lightLevel, sources });
}
function enemiesOf(scene, tok) { return scene.tokens.contents.filter(t => t.id !== tok.id && !t.hidden && t.actor?.isOfType?.("creature") && t.object && t.actor.isEnemyOf?.(tok.actor)); }
/** Every creature against this monster, with how it stands to each. Needs the fight on this page's canvas. */
/** How one monster perceives any one creature on the fight's map, enemy or not (0.25.0: fight memory asks it of allies and of whoever did a thing).
    Returns a function of the other token. Needs the fight on this page's canvas. */
function senser(combat, tok, memory = {}) {
  const scene = sceneOf(combat), me = tok.actor, conds = conditionsOn(me), blocked = (type, a, b) => !!CONFIG.Canvas.polygonBackends[type].testCollision(a, b, { mode: "any", type });
  const vis = game.modules.get(VISIONER)?.active ? game.modules.get(VISIONER).api : null, avs = !!vis && !!game.settings.get(VISIONER, "autoVisibilityEnabled");
  const senses = sensesOf([...(me.perception?.senses ?? [])], { deafened: conds.includes("deafened") }), below = isBelow(tok);   /* burrowed: only tremorsense reaches it (0.16.0) */
  const beliefs = turns(combat).pointed?.[tok.id] ?? {};
  return t => {
    const from = tok.object.center, to = t.object.center, distance = tok.object.distanceTo(t.object), theirs = conditionsOn(t.actor);
    const own = perceiveOne({ senses, blinded: conds.includes("blinded"), dazzled: conds.includes("dazzled"), sees: !blocked("sight", from, to), heard: !blocked("sound", from, to), light: lightOn(to, scene), distance, invisible: theirs.includes("invisible"), concealed: theirs.includes("concealed"), stored: vis?.getVisibility(tok.id, t.id) ?? null, avs, known: !!memory[t.id], below, aloft: heightUp(t) > 0 });
    /* Point Out (0.30.0, design review 15): a creature an ally pointed out is hidden to it at the square it believes, only while its own senses
       give it no square; `raw` is what its own senses say, and a believed square can be wrong (`wrong`, never sent to a thinker) */
    const seen = withBelief(own, beliefs[t.id] ?? null);
    if (seen.pointed) return { id: t.id, token: t, state: "hidden", by: "pointed", raw: own.state, pointed: true, wrong: seen.wrong, height: Number(beliefs[t.id].height) || 0, distance: seen.wrong ? squareFeet(squareOf(tok, scene), seen.square) : distance, square: seen.square };
    return { id: t.id, token: t, state: own.state, by: own.by, raw: own.state, distance, square: squareOf(t, scene) };
  };
}
function sense(combat, tok, memory = {}) { const one = senser(combat, tok, memory); return enemiesOf(sceneOf(combat), tok).map(one); }
const healthWords = () => healthEntries(game.settings.get("pf2e-hud", "healthStatusData"), game.i18n.localize("pf2e-hud.health-status.default"));
/* dead: core's Dead status, or a monster at 0 HP that isn't dying or unconscious (PF2e's NPCs die at 0); anyone else at 0 HP is "Down" */
const isDeadNow = actor => !!actor.statuses?.has?.("dead") || (actor.type === "npc" && (actor.hitPoints?.value ?? 1) <= 0 && !actor.hasCondition?.("dying") && !actor.hasCondition?.("unconscious"));
const wordsFor = actor => { try { return healthWord(actor.hitPoints ?? {}, healthWords(), { dead: isDeadNow(actor) }); } catch { const h = actor.hitPoints; return h?.max ? (h.value <= 0 ? (isDeadNow(actor) ? "Dead" : "Down") : h.value >= h.max ? "Unhurt" : "Hurt") : null; } };   /* PF2e HUD may be off or renamed its setting */
function gearOf(actor) {
  /* what it looks like: never a rune or an item's hidden name. PF2e builds "+1 Striking Longsword" from the runes; the source name is the plain one. */
  const show = i => i.isIdentified === false ? (i.system.identification?.unidentified?.name ?? i._source?.name ?? i.name) : (i._source?.name ?? i.name);
  return [...(actor.itemTypes?.weapon ?? []).filter(i => i.system.equipped?.carryType === "held"), ...(actor.itemTypes?.shield ?? []).filter(i => i.system.equipped?.carryType === "held"), ...(actor.itemTypes?.armor ?? []).filter(i => i.isWorn)].map(show);
}
function actionsOf(actor, combat) {
  const n = s => actor.getCondition?.(s)?.value ?? 0, r = actor.getFlag(WORKBENCH, "stunReduction"), reduced = r && r.combat === combat.id && r.round === combat.round ? r.reducedBy : 0;
  return actionsFor({ quickened: actor.hasCondition?.("quickened"), slowed: n("slowed"), stunned: n("stunned"), reduced });
}
/* Ammunition (Rhea, 2026-11-08: "Module takes 1 Arrow itself"). PF2e Ranged Combat 8.0.7 reads a monster's ammunition one short (it sees 1 Arrow as none)
   and its shot then takes 2 (a player's takes 1: tested with Valeros). So on a monster's shot the module turns Ranged Combat's counting off with its own
   "skip-post-processing" roll option and takes the weapon's expend itself, from the stack Ranged Combat's check chose. Its check before the shot still
   reads one short, so the last Arrow can't be fired: `shotsLeft` is what that check lets through, read from Ranged Combat itself so it follows its
   version. Without Ranged Combat, PF2e's own count (an NPC's attack has no ammunition linked, so nothing is counted or taken). */
const RANGED = "pf2e-ranged-combat", rangedOn = () => !!game.modules.get(RANGED)?.active;
let rangedSystem = null;
async function rangedWeapons() { if (!rangedOn()) return null; try { rangedSystem ??= (await import(foundry.utils.getRoute(`modules/${RANGED}/scripts/weapons/system.js`))).WeaponSystem; return rangedSystem; } catch (e) { console.warn(`${ID} | Ranged Combat`, e); return null; } }
/** What a Strike's shots use: null if nothing is counted, otherwise { shotsLeft, ammo (its name), stack (the item id it takes from), expend }. */
export async function ammoOf(actor, strike) {
  const item = strike.item; if (!item?.isRanged) return null;
  if (actor.type === "npc" && rangedOn()) {
    const W = await rangedWeapons(); let w = null; try { w = W?.transformWeapon(actor, item); } catch (e) { console.warn(`${ID} | Ranged Combat weapon`, e); }
    if (!W || !w) return { shotsLeft: null, unreadable: true };   /* Ranged Combat changed: it counts this shot itself, and the GM is told */
    if (w.expend == null || w.expend <= 0) return null;
    if (w.isRepeating || w.capacity > 0 || w.reloadActions > 0) return null;   /* weapons it loads: its own loading rules, not counted here */
    /* the stack its check will take from: the selected one (even when it reads it as empty), or the only usable one; several with none chosen,
       Ranged Combat would ask which, where nobody can answer, so no shot until the GM picks one */
    const all = w.compatibleAmmunition ?? [], usable = all.filter(a => a.quantity > 0), sel = w.selectedInventoryAmmunition;
    const pick = sel ? all.find(a => a.id === sel.id) ?? sel : usable.length === 1 ? usable[0] : null;
    if (!pick) return { shotsLeft: 0, ammo: usable.length ? "several kinds, none chosen in Ranged Combat" : (all[0]?.name ?? "ammunition"), stack: null, expend: w.expend };
    const uses = pick.quantity > 0 ? (pick.calculateTotalRemainingUses?.() ?? pick.quantity) : 0;
    return { shotsLeft: Math.floor(uses / w.expend), ammo: pick.name ?? "ammunition", stack: pick.id, expend: w.expend };
  }
  const expend = item.system?.expend ?? 0, a = item.ammo; if (!(expend > 0) || !a) return null;
  const left = a.isOfType?.("ammo") && a.system.uses?.max > 1 ? a.system.uses.value + (a.quantity - 1) * a.system.uses.max : a.quantity;
  return { shotsLeft: Math.floor(left / expend), ammo: a.name, stack: null, expend };
}
/** A Strike Ranged Combat refused this turn counts as having no shots for the rest of it, so a re-plan can't try it again (turns.noShot). */
const shotsFor = (combat, tok, id, m) => { const b = combat ? turns(combat).noShot?.[tok.id] : null; return b?.round === combat.round && b.items?.includes(id) ? 0 : m?.shotsLeft; };
const ammoFields = (m, left) => m && !m.unreadable ? { shotsLeft: left, ammo: m.ammo, ...(m.stack ? { stack: m.stack } : {}) } : {};
/** Take a monster's shot's ammunition from the stack (uses first, then the stack), as Ranged Combat would for one shot. */
async function takeAmmo(actor, ammo) {
  const it = ammo?.stack ? actor.items.get(ammo.stack) : null; if (!it) return null;
  let q = it.quantity, u = it.system.uses?.value ?? 1; const max = it.system.uses?.max ?? 1;
  for (let n = ammo.expend; n > 0 && q > 0; n--) { u -= 1; if (u <= 0) { q -= 1; u = max; } }
  await it.update({ "system.quantity": Math.max(0, q), ...(max > 1 ? { "system.uses.value": u } : {}) });
  return Math.max(0, q);
}
async function strikesOf(actor, combat = null, tok = null) {
  const out = []; for (const { id, strike: a } of strikesWithIds(actor)) {
    if (droppedWeapon(actor, a)) continue;   /* its weapon lies on the ground (a Release): "you.dropped" says so */
    let damage = null; try { damage = await a.damage({ getFormula: true }); } catch (e) { console.warn(`${ID} | damage formula`, e); }
    out.push({ id, name: a.label, ...(sheathedWeapon(actor, a) ? { sheathed: true } : {}), ...(weaponOf(actor, a)?.system?.usage?.value === "held-in-one-plus-hands" ? { bothHands: true } : {}), mod: strikeMods(a.variants.map(v => v.label)), reach: actor.getReach({ action: "attack", weapon: a.item }), ...(a.item?.isRanged ? { range: a.item.range?.increment ?? null, maxRange: a.item.range?.max ?? null } : {}), damage: typeof damage === "string" ? damage : null, traits: (a.traits ?? []).map(t => t.name).filter(t => t !== "attack"), effects: a.item?.system?.attackEffects?.value ?? [], ...(await ammoOf(actor, a).then(m => ammoFields(m, shotsFor(combat, tok, id, m))).catch(() => ({}))) });
  } return out;
}
const localize = k => game.i18n.localize(k);
/** The monster's abilities (its action items) with the ids plans use: the slug, or the name made into one, with -2 and so on when two share it. kind is
    action, free, reaction or passive; cost the actions an action takes; usesLeft what its frequency has left (null if it has none); followUp the check a
    Grab, Knockdown, Push or Pull rolls (FOLLOW_UPS), with `effect` the word a Strike's effects list for it. */
function abilityList(actor) {
  const seen = new Map();
  const own = [...(actor.itemTypes?.action ?? []), ...(actor.isOfType?.("npc") ? [] : (actor.itemTypes?.feat ?? []).filter(i => ["action", "free", "reaction"].includes(i.system.actionType?.value)))];   /* a character's actions are mostly feats (0.18.0 review) */
  const list = own.map(i => {
    const slug = i.slug ?? game.pf2e.system.sluggify(i.name), n = (seen.get(slug) ?? 0) + 1; seen.set(slug, n);
    const kind = i.system.actionType?.value ?? "passive", f = i.system.frequency;
    return { item: i, id: n === 1 ? slug : `${slug}-${n}`, name: i.name, kind, cost: kind === "action" ? (i.actionCost?.value ?? i.system.actions?.value ?? 1) : kind === "free" ? 0 : null,
      traits: [...(i.system.traits?.value ?? [])], usesLeft: f ? (f.value ?? f.max ?? null) : null, followUp: FOLLOW_UPS[slug] ?? null, effect: FOLLOW_UPS[slug] ? slug : null };
  });
  /* A Strike can list Grab or Knockdown with no matching item on the creature (PF2e's attack effects don't need one): it can still use it, as the rules say */
  for (const { strike } of strikesWithIds(actor)) for (const e of strike.item?.system?.attackEffects?.value ?? []) {
    if (!FOLLOW_UPS[e] || list.some(a => a.id === e)) continue;
    const free = e.startsWith("improved-");
    list.push({ item: null, id: e, name: e.split("-").map(w => w[0].toUpperCase() + w.slice(1)).join(" "), kind: free ? "free" : "action", cost: free ? 0 : 1, traits: [], usesLeft: null, followUp: FOLLOW_UPS[e], effect: e });
  }
  return list;
}
/** For the packet: what each ability is, in plain words, with what the module does with a follow-up. */
function abilitiesOf(actor) {
  return abilityList(actor).map(a => ({ id: a.id, name: a.name, kind: a.kind, cost: a.cost, ...(a.traits.length ? { traits: a.traits } : {}), ...(a.usesLeft != null ? { usesLeft: a.usesLeft } : {}),
    ...(a.followUp ? { followUp: `${CHECK_WORD[a.followUp]} check, right after a Strike that lists ${a.effect} and hits` } : {}), text: a.item ? plainText(a.item.system.description?.value, localize) : "" }));
}
/* ---------- spells ---------- */
/* What it can cast now, from PF2e's own spellcasting sheet data (the list a sheet shows: prepared slots not yet expended, a spontaneous caster's known and
   signature spells by rank with the slots it has left, innate spells with their uses, focus spells and the focus pool, cantrips). One entry per spell per
   spellcasting entry, with the ranks it can be cast at and the pool each rank spends from: a spontaneous caster's slots of a rank are one pool shared by
   every spell of that rank, a prepared caster's copies of one spell at one rank are one pool, an innate spell's uses its own, focus spells the focus pool.
   Cantrips and at-will spells have none. Rituals and staffs, wands and scrolls aren't here. */
const CASTERS = ["prepared", "spontaneous", "innate", "focus"];
async function spellBook(actor) {
  const book = new Map(), counts = {}, focus = Number(actor.system.resources?.focus?.value) || 0, entries = (actor.spellcasting?.regular ?? []).filter(e => e.statistic && !e.isRitual && CASTERS.includes(e.category));
  /* ids stay the same through the turn: a spell known in two entries is "slug" in the first and "slug-2" in the second, whatever is left to cast, so a plan
     can't end up casting from the other entry once one runs out */
  const slugOf = s => s.slug ?? game.pf2e.system.sluggify(s.name), owners = new Map();
  for (const e of entries) for (const s of e.spells?.contents ?? []) { const k = slugOf(s), list = owners.get(k) ?? []; if (!list.includes(e.id)) list.push(e.id); owners.set(k, list); }
  for (const e of entries) {
    let sd; try { sd = await e.getSheetData(); } catch (x) { console.warn(`${ID} | spells`, x); continue; }
    for (const g of sd.groups ?? []) {
      const cantrips = g.id === "cantrips", groupRank = Number(g.id);
      for (const x of g.active ?? []) {
        const sp = x?.spell; if (!sp || x.expended) continue;
        const base = sp.original ?? sp, rank = cantrips || !Number.isInteger(groupRank) ? sp.rank : groupRank, fp = Number(base.system.cast?.focusPoints) || 0;
        let pool = null, left = null, cost = 1;
        if (fp > 0 || (e.isFocusPool && !base.isCantrip)) { pool = "focus"; left = focus; cost = Math.max(1, fp); }
        else if (cantrips || base.isCantrip) { /* at will */ }
        else if (e.isInnate) { const u = x.uses ?? base.system.location?.uses; if (!sp.atWill && u?.max > 0) { pool = `innate:${e.id}:${base.id}:${rank}`; left = Number(u.value) || 0; } }
        else if (e.isPrepared && !e.isFlexible) { pool = `prep:${e.id}:${rank}:${base.id}`; left = counts[pool] = (counts[pool] ?? 0) + 1; }
        else { pool = `slots:${e.id}:${rank}`; left = Number(g.uses?.value) || 0; }
        const key = `${e.id}:${base.id}`;
        if (!book.has(key)) {
          const slug = slugOf(base), n = Math.max(1, (owners.get(slug) ?? [e.id]).indexOf(e.id) + 1);
          const act = spellActions(base.system.time?.value), rng = spellRange(base.system.range?.value), save = base.system.defense?.save, text = plainText(base.system.description?.value, localize);
          book.set(key, { id: n === 1 ? slug : `${slug}-${n}`, name: base.name, entryId: e.id, spellId: base.id, ranks: [], minActions: act.min, maxActions: act.max, time: base.system.time?.value ?? "",
            range: rng.range, touch: rng.touch, rangeText: base.system.range?.value ?? "", targets: spellTargets(base.system.target?.value), targetText: base.system.target?.value ?? "",
            area: base.system.area?.type ? { type: base.system.area.type, size: base.system.area.value } : null, attack: !!base.isAttack, save: save?.statistic ? { stat: save.statistic, basic: !!save.basic } : null,
            damaging: Object.keys(base.system.damage ?? {}).length > 0, damage: Object.values(base.system.damage ?? {}).map(d => `${d.formula} ${d.type ?? ""}`.trim()).join(" + "),
            variants: !!base.hasVariants && act.min !== act.max, lasting: !!String(base.system.duration?.value ?? "").trim() || !!base.system.duration?.sustained, traits: [...(base.system.traits?.value ?? [])], critText: /critical success/i.test(text), dc: e.statistic.dc?.value ?? null, attackMod: e.statistic.check?.mod ?? null, text });
        }
        const s = book.get(key), had = s.ranks.find(r => r.rank === rank);
        if (had) { if (pool?.startsWith("prep:")) had.left = left; } else s.ranks.push({ rank, pool, left, cost });
      }
    }
  }
  return [...book.values()].map(s => ({ ...s, ranks: s.ranks.sort((a, b) => a.rank - b.rank) }));
}
/** For the packet: each spell in plain words, with the ranks it can be cast at and what each has left. */
function spellsOf(book) {
  const cap = (t, n) => t.length > n ? `${t.slice(0, n - 1)}…` : t;
  return book.map(s => ({ id: s.id, name: s.name, ranks: Object.fromEntries(s.ranks.map(r => [r.rank, r.pool == null ? "at will" : r.pool === "focus" ? `${r.left} focus point${r.left === 1 ? "" : "s"} (costs ${r.cost})` : r.left])),
    actions: s.time, ...(s.rangeText ? { range: s.rangeText } : {}), ...(s.targetText ? { targets: s.targetText } : {}), ...(s.area ? { area: `${s.area.size}-foot ${s.area.type}`, aim: aimWords(s.area.type) ?? "the GM places it" } : {}),
    ...(s.area && s.lasting ? { lasting: "its area stays on the map after the turn" } : {}),
    ...(s.attack ? { defense: "AC", attackMod: s.attackMod } : s.save ? { defense: `${s.save.basic ? "basic " : ""}${s.save.stat[0].toUpperCase()}${s.save.stat.slice(1)} save`, dc: s.dc } : {}),
    ...(s.damage ? { baseDamage: s.damage } : {}), ...(s.variants ? { variants: "what it does depends on the actions spent: the GM applies it from its card" } : {}), traits: s.traits, text: cap(s.text, 900) }));
}
/** The spell a step casts, found again by its entry and item. */
const spellFor = (actor, step) => { const entry = actor.spellcasting?.get(step.entryId); const spell = entry?.spells?.get(step.spellId) ?? actor.items.get(step.spellId); return entry && spell ? { entry, spell } : null; };
const isHeld = actor => ["grabbed", "restrained"].some(c => actor?.hasCondition?.(c));
/* Allies know where each other are, by default. */
function alliesOf(scene, tok) { return scene.tokens.contents.filter(t => t.id !== tok.id && t.actor?.isOfType?.("creature") && t.actor.isAllyOf?.(tok.actor)); }
/** The allies a thinker is told of: those the GM hasn't hidden, and a burrowed one (hidden only because it is below ground) unless the GM had hidden it
    before it went down (0.16.0 review). The packet and a Delay use the same list. */
const knownAllies = (scene, tok) => alliesOf(scene, tok).filter(a => !a.hidden || (isBelow(a) && !a.getFlag(ID, "burrowed")?.wasHidden));
/** What its next diagonal costs this turn, 5 or 10 ft: the 5-10 count runs across all its movement in the turn (Rules ID 444), and Foundry keeps that
    movement as the token's history until the turn changes. The thinker can't see the history, so the packet says it. */
function nextDiagonalFt(tok, scene) { const px = scene.grid.size, d = scene.dimensions; return diagonalsIn((tok.movementHistory ?? []).map(w => [Math.round((w.x - d.sceneX) / px), Math.round((w.y - d.sceneY) / px)])) % 2 ? 10 : 5; }
/** A monster's packet as things stand, plus the labels it needs. Writes nothing. turn: what this turn already used ({ spent, attacks, done, note }), on a re-plan. */
async function buildPacket(combat, tok, turn = {}) {
  /* notebook writes give out labels too: let the ones on their way land first, and hold new ones back until this packet's labels are saved by its
     caller (review 2: two creatures could be given the same label) */
  await bookQueue; packetsBuilding++; setTimeout(() => { packetsBuilding = Math.max(0, packetsBuilding - 1); }, 4000);
  const scene = sceneOf(combat), t = turns(combat), memory = t.memory?.[tok.id] ?? {}, others = sense(combat, tok, memory), allies = knownAllies(scene, tok);   /* a GM-hidden or escaped ally isn't there for the thinker; a burrowed one is (it knows where its own are) */
  const known = others.filter(o => canTarget(o.state) || (o.state === "undetected" && memory[o.id])), labels = { ...(t.labels ?? {}) };
  const fresh = { ...assignLabels(labels, known.map(o => o.id), "E"), ...assignLabels(labels, [tok.id, ...allies.map(a => a.id)], "M") }; Object.assign(labels, fresh);
  const { model, read } = await readMap(scene), a = tok.actor, h = a.hitPoints, square = squareOf(tok, scene);
  const water = waterKinds(deepWater(scene, model), read), swimming = heightUp(tok) > 0 ? null : waterUnder(square, sizeOf(tok), water);   /* "calm" | "flowing" | null; a flier above the water isn't swimming */
  const speeds = a.system.movement?.speeds ?? {}, extra = Object.fromEntries(["fly", "swim", "climb", "burrow"].filter(k => speeds[k]?.value).map(k => [k, speeds[k].value]));
  const you = { label: labels[tok.id], name: nameFor(tok), ...(onParty(a) ? { side: "party" } : {}), square, size: a.size, nextDiagonal: nextDiagonalFt(tok, scene), actionsLeft: Math.max(0, actionsOf(a, combat) - (turn.spent ?? 0)), attacksMade: turn.attacks ?? 0, hp: `${h.value}/${h.max}`, speed: speeds.land?.value ?? 0, ...(Object.keys(extra).length ? { speeds: extra } : {}), ...(heightUp(tok) ? { height: heightUp(tok) } : {}), ...(swimming ? { swimming } : {}), conditions: (a.conditions?.active ?? []).map(c => c.value ? `${c.slug} ${c.value}` : c.slug), strikes: await strikesOf(a, combat, tok), abilities: abilitiesOf(a) };
  const book = await spellBook(a); if (book.length) you.spells = spellsOf(book);
  /* Climb and Release (0.15.0): what it holds (a Climb needs both hands free), weapons it let go of, and the trees near it, tallest guess included */
  const held = heldItems(a); if (held.length) you.holding = held.map(({ id, name }) => ({ id, name }));
  const gone = [...new Set(strikesWithIds(a).filter(({ strike }) => droppedWeapon(a, strike)).map(({ strike }) => strike.label))]; if (gone.length) you.dropped = gone;
  const up = treeUp(tok, scene), far = t => Math.max(Math.abs(t.at[0] - square[0]), Math.abs(t.at[1] - square[1]));
  const near = treesOf(read).filter(t => far(t) <= GROUND_RADIUS).sort((x, y) => far(x) - far(y)).slice(0, 12);
  if (up || near.length) you.climb = { trees: near, ...(up ? { up: { tree: up.at, top: up.top } } : {}) };
  /* Burrow (0.16.0): whether it is under the ground now, whether the ground it stands on is soil, and on a map the module can't read whose ground isn't
     judged yet, the request to judge it from a picture (Rhea, 2026-11-08: Angel judges each map in play) */
  const burrows = burrowSpeedOf(a) > 0, glides = burrows && glidesThroughRock(a), isDeep = burrows ? deepWater(scene, model) : null, soil = burrows ? soilOf(scene, model, read, isDeep, glides ? glideBounds(scene, model) : null) : null;
  if (burrows) {
    /* a glider needs no soil judged (rock is no bar to it), but it needs to know which of the map's own walls are stone (0.17.0) */
    const below = isBelow(tok), judge = !glides && !read && !groundJudged(scene), judgeWalls = glides && plainWalls(scene).length > 0 && !wallsJudged(scene);
    const shown = (judge || judgeWalls) && isRunner() ? await showGroundPicture(scene).catch(e => { console.warn(`${ID} | ground picture`, e); return false; }) : false;
    const picture = { size: mapSquares(scene), picture: shown ? `a picture of the whole map with numbered squares is on the runner's page, element #${GROUND_EL}` : "no picture could be drawn: judge from the scene's name and the ground map, or answer \"none\"", sceneName: scene.name };
    you.burrow = { below, soilHere: footprintAt(square, sizeOf(tok)).every(([i, j]) => soil(i, j)),
      ground: glides ? "it glides through rock and earth alike (\"r\" on the ground map is no bar to it); only deep water, trees, doors and walls that aren't stone stop it, and it comes up only onto open floor"
        : read ? "known: the module read this map (\"r\" on the ground map is rock)" : judge ? "not judged yet: everywhere counts as rock" : "judged: soil is where the GM's soil areas are (\"r\" on the ground map is rock)",
      ...(glides ? { glides: true, walls: !plainWalls(scene).length ? "known: the map's own walls (stone features pass, trunks don't)" : judgeWalls ? "not judged yet: every wall stops it" : "judged: walls inside the GM's stone-walls areas are stone; others stop it" } : {}),
      ...(judge ? { judgeGround: picture } : {}), ...(judgeWalls ? { judgeWalls: picture } : {}) };
  }
  const cover = visionerApi();
  if (offGrid(tok, scene)) you.offGrid = true;
  /* already Taking Cover: the cover it has now comes from that, so it isn't listed as cover to Take Cover from (it can't take it again until it moves or attacks) */
  const taking = takingCover(tok), coverList = cover ? others.filter(o => SEES.includes(o.state) && labels[o.id] && STANDARD.includes(coverOf(cover, o.token, tok))).map(o => labels[o.id]) : [];
  you.takeCover = { taking, ...(taking ? { why: "It is Taking Cover now: the cover it has comes from that. It ends when it moves off its square or attacks." } : {}), nextToCover: nearCoverFor(scene)(square, sizeOf(tok)), standardCoverFrom: taking ? [] : coverList };
  /* what it knows of its own stealth (Rhea, 2026-11-07, B): what it last tried and whether it is still hiding, the light where it stands, its own
     concealment and who it has standard cover from; never whether a secret roll worked */
  const tried = t.stealth?.[tok.id] ?? null;
  you.stealth = { lastTried: tried ? `${tried.did === "sneak" ? "Sneaked" : "Hid"} in round ${tried.round}, and has only Hidden, Sneaked or Stepped since` : null, light: lightOn(tok.object.center, scene), concealed: !!a.hasCondition?.("concealed"), standardCoverFrom: coverList };   /* the real list: Taking Cover itself allows a Hide */
  /* its mind (0.24.0): the profile from its layers, with party names turned into the labels of those it perceives or knows as allies and any line
     naming someone else held back (the same gate as the GM's note); `mindHeld` goes with the request so the GM can be told why a line was left out */
  const nameable = new Set([tok.id, ...allies.map(x => x.id), ...others.filter(o => canTarget(o.state)).map(o => o.id)]), minded = mindOf(scene, tok, combat, id => nameable.has(id) ? labels[id] ?? null : null);
  /* its notebook (0.25.0): what it remembers of this fight that its Mind can use, its allies' deeds since its last turn, its side's tally */
  /* its band (0.26.0): by its Discipline, the band's nature, who leads and the plan written at build, and once the leader has fallen, that it has
     (the band knows at once: Rhea, R3-10). A creature with no Discipline shares nothing: no band, and nothing of what the others did or how its
     side stands. The leader is named only by a label this monster already has (a GM-hidden ally stays unnamed). */
  const discipline = minded.assembled.lines.discipline?.pick ?? "loose", banded = onParty(a) ? { band: null, bandNow: null, held: [] } : bandPacket(scene, tok, combat, { labelOf: id => nameable.has(id) ? labels[id] ?? null : null, fallen: fellWord, discipline });
  const notebook = forPacket(books(combat)[tok.id], { rung: rungOf(minded.mind?.pick?.mind), since: deedsSince(combat, tok.id), side: sideOf(combat, tok), shares: onParty(a) || discipline !== "none", forms: P(tok, combat) });
  /* orders (0.28.0): what it has heard from its leader, whom it was told of and hasn't perceived, and for a leader whether it may give one */
  const orders = onParty(a) ? null : ordersBlock(combat, tok, { labels, nameable, memory, discipline });
  /* speech (0.29.0): whether it may say its sentence to the party this round and whether it may yield; and who around it has given itself up */
  const speech = speechForPacket(speechCtx(combat, tok), { party: onParty(a) });
  /* tier 3d (0.30.0): which of the creatures it sees its allies have lost (it could Point one out); a handler's command in force for this turn;
     and for a creature that changed sides, where it came from */
  const lost = lostByAllies(combat, tok, others);
  const cmd = commandNow(combat, tok), command = cmd && (cmd.degree >= 2 || cmd.angel) ? commandForPacket(cmd, { from: nameable.has(cmd.by) ? labels[cmd.by] ?? null : null, sees: !cmd.foe || others.some(o => labels[o.id] === cmd.foe && canTarget(o.state)), forms: P(tok, combat) }) : null;
  const turned = turnedPacket(combat, tok, id => nameable.has(id) ? labels[id] ?? null : null); if (turned) you.changedSides = turned;
  /* earth barriers (0.35.0): what it sees of each slab on the map, its caster by label only when it perceives them */
  const barriers = a.hasCondition?.("blinded") ? [] : barriersOf(combat, scene.id).map(b => ({ label: b.label, squares: b.squares, by: nameable.has(b.caster) ? labels[b.caster] ?? null : null, ac: b.ac, hardness: b.hardness, hp: `${Math.max(0, b.hp)}/${b.max}` }));
  const packet = packetOf({ you, mind: minded.mind, band: banded.band, bandNow: banded.bandNow, orders, speech, command, notebook, round: combat.round, memory, note: turn.note ?? null, done: turn.done ?? [], barriers, ground: groundAround(model, square, GROUND_RADIUS, undefined, takeCoverSquares(scene), water, soil && !glides ? (x, y) => !soil(x, y) && !model.blocked[model.idx(x, y)] && !water(x, y) : null),
    allies: allies.map(x => ({ label: labels[x.id], name: nameFor(x), square: squareOf(x, scene), ...(heightUp(x) ? { height: heightUp(x) } : {}), ...(isBelow(x) ? { below: true } : {}), healthWord: wordsFor(x.actor), conditions: visibleConditions(conditionsOn(x.actor)), ...(stoodDown(x) ? { yielded: true } : {}) })),
    others: others.map(o => ({ id: o.id, state: o.state, label: labels[o.id], square: o.square, ...(o.pointed ? { pointed: true } : {}), ...(lost.has(o.id) ? { alliesLost: true } : {}), height: o.pointed ? o.height ?? 0 : heightUp(o.token), offGrid: offGrid(o.token, scene), size: o.token.actor.size, distance: o.distance, gear: gearOf(o.token.actor), conditions: visibleConditions(conditionsOn(o.token.actor)), healthWord: wordsFor(o.token.actor), cover: cover?.getAutoCoverState?.(tok.object, o.token.object) ?? "none", ...(stoodDown(o.token) ? { yielded: true } : {}) })) });
  return { packet, labels: labelsOf(others.map(o => ({ id: o.id, state: o.state, label: labels[o.id] }))), fresh, others, mindHeld: [...minded.held.map(h => h.key), ...banded.held.map(k => `band.${k}`)] };
}
/** Has this creature fallen, as its band counts it (R3-2: down, dead or fled)? */
function fallenWord(tok) { const a = tok?.actor; if (!a) return "gone";
  /* asleep is not fallen: the builder puts Unconscious on a monster built asleep, and its band must not run while the boss sleeps (0.26.0 review 1) */
  return tok.getFlag(ID, "escaped") ? "fled" : isDeadNow(a) ? "dead" : (a.hitPoints?.value ?? 1) <= 0 || a.hasCondition?.("dying") ? "down" : null; }
/** A creature that has yielded in a fight still going (0.29.0): its token's flag, or null. `prisonerOf`: its yield was accepted. `stoodDown`:
    either. `fellWord`: fallen as its band counts it, a leader that gave itself up included (its band acts on that as on a fall). */
const liveFlag = (tok, key) => { const y = tok?.getFlag?.(ID, key); return y && game.combats.get(y.combat)?.started ? y : null; };
/* a prisoner is out of the tracker. One still in it (Accepted cut off by a reload before its combatant went, or the GM putting it back in the
   tracker by hand) reads as yielded: it stands down and its row has the buttons again (0.29.0 review 1) */
const inTracker = (tok, combatId) => !!game.combats.get(combatId)?.combatants.some(c => c.tokenId === tok.id);
const yieldOf = tok => { const y = liveFlag(tok, "yielded"); if (y) return y; const p = liveFlag(tok, "prisoner"); return p && inTracker(tok, p.combat) ? { ...p, round: p.yielded ?? p.round } : null; };
const prisonerOf = tok => { const p = liveFlag(tok, "prisoner"); return p && !inTracker(tok, p.combat) ? p : null; }, stoodDown = tok => !!(yieldOf(tok) || prisonerOf(tok));
const fellWord = tok => fallenWord(tok) ?? (stoodDown(tok) ? "yielded" : null);
/* Keep what each ticked monster can perceive as the fight moves, so a monster's memory is where it last perceived someone and not where they stood on its own last turn. */
async function noteWhatTheySense(combat) {
  if (!onFightScene(combat)) return;
  const t = turns(combat), change = {};
  for (const c of combat.combatants) { const tok = c.token; if (!tok?.object || !(keepsBook(tok) || (tok.getFlag(ID, "run") && runnable(tok))) || tok.actor?.isDead) continue;   /* every monster, ticked or not (0.25.0): a notebook and a line of hers need to know whom it has perceived */
    const mem = t.memory?.[tok.id] ?? {}, now = remember(mem, sense(combat, tok, mem), combat.round);
    for (const [id, m] of Object.entries(now)) change[`memory.${tok.id}.${id}`] = m; }
  if (Object.keys(change).length) await saveTurns(combat, change);
}
/** What this monster perceives right now, as a packet. GM only, and only on a page with the fight open: anywhere else the sight tests would read the wrong map. */
export async function perceived(tokenId, combat = game.combat) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const tok = sceneOf(combat)?.tokens.get(tokenId); if (!tok) throw new Error("That token isn't in this fight's scene.");
  if (!onFightScene(combat) || !tok.object) throw new Error("This page doesn't have the fight's map open, so it can't tell.");
  return (await buildPacket(combat, tok)).packet;
}

/* ---------- a turn starts ---------- */
/* pf2e.startTurn fires on Foundry's active GM only, which the runner may not be, so the runner watches the Combat itself. The guard is by round and
   combatant, not turn number: Workbench moves a PC's initiative at 0 HP, which changes the turn number in the middle of a monster's turn. */
const starting = new Set(), turnAt = new Map(); let changedAt = null;
/** A creature in a fight changed (its actor, an item on it, its combatant): the runner notes when, for `settle`. Called from the hooks in main.mjs. */
export function noteChange(doc) {
  if (!isRunner()) return;
  const actor = doc?.documentName === "Actor" ? doc : doc?.documentName === "Combatant" ? doc.actor : doc?.parent?.documentName === "Actor" ? doc.parent : null; if (!actor) return;
  if (game.combats.some(c => c.started && c.combatants.some(x => x.actor === actor))) changedAt = performance.now();
}
/** Waits for the start of the turn to settle (`settleWait` in turn.mjs) and returns how long that took, in ms, counted from the turn change. A turn
    asked for some other way (a tick during the turn, a reload) has no turn change to count from, so it waits from now. */
async function settle(combat, combatant) {
  const since = settleFrom(turnAt.get(combat.id) ?? null, performance.now()); turnAt.delete(combat.id);
  /* PF2e's own turn start has arrived once the combatant's flag names this round (already true for a turn that comes back after a Delay) */
  const begun = () => combatant.flags?.pf2e?.roundOfLastTurn === combat.round;
  for (;;) { const ms = settleWait({ since, lastChange: changedAt, now: performance.now(), begun: begun() }); if (ms <= 0) return Math.round(performance.now() - since); await sleep(Math.min(ms, 50)); }
}
async function onTurnChange(combat) {
  if (!isRunner() || !combat?.started) return;
  const combatant = combat.combatant, tok = tokenOf(combat, combatant);
  if (tok && yieldOf(tok) && runnable(tok)) return passTurn(combat, combatant, tok);   /* it has yielded (0.29.0): the module passes its turn, ticked or not */
  /* Command an Animal (0.30.0): its handler's command is for this turn. A failure: it does nothing, and the module passes the turn (0.29.0's
     pass request), ticked or not, unless she took it with Play it myself. A critical failure: the turn waits for her (Play it myself, or Let
     Angel plan it). A success goes on as any turn, with the command in its packet. */
  const cmd = tok && runnable(tok) && turns(combat).commands?.[tok.id] ? await commandAtTurn(combat, tok) : null;
  if (combat.combatant?.id !== combatant?.id) return;
  if (cmd && outcomeOf(cmd.degree) === "nothing") return cmd.own ? undefined : passTurn(combat, combatant, tok, "command");   /* taken with Play it myself: hers, and Angel isn't asked */
  if (cmd && outcomeOf(cmd.degree) === "gm" && !cmd.angel) return;
  if (!tok?.getFlag(ID, "run") || !runnable(tok)) return;
  if (partyMember(tok.actor) && isDown(tok.actor)) return;   /* dying or unconscious: its turn (the recovery check) is the GM's, and every plan would be refused (0.18.0 review) */
  /* the round as this call found it (0.29.0, u-81): a turn asked for late (a tick during the turn) could wait out the settle time while the round
     moved on and the same creature came up again, and was then stamped with the new round beside that round's own request: two for one turn */
  const round = combat.round, key = `${combat.id}.${round}.${combatant.id}`; if (starting.has(key)) return;
  /* a Delay ends the request and the monster comes back later this round for a whole new turn (0.12.0): a delayed request never blocks it */
  const mine = Object.values(turns(combat).requests).filter(r => !r.reaction && r.combatantId === combatant.id && r.round === combat.round);
  if (mine.some(r => !r.delayed && !r.passed)) return;   /* a turn the module passed for a yield that has since ended (Fight on, a blow) is asked for after all */
  const afterDelay = mine.some(r => r.delayed);
  if (afterDelay && combatant.getFlag(HUD, "delayed")) await combatant.unsetFlag(HUD, "delayed").catch(e => console.warn(`${ID} | HUD delayed flag`, e));   /* back in the order: the tracker's hourglass goes */
  starting.add(key);
  try {
    const settled = await settle(combat, combatant);   /* start-of-turn effects: wait until the creatures have stopped changing (0.23.0) */
    if (combat.combatant?.id !== combatant.id || combat.round !== round) return;
    const opened = await ensureScene(combat);
    if (combat.combatant?.id !== combatant.id || combat.round !== round) return;
    const id = foundry.utils.randomID(8), base = { state: "requested", combatantId: combatant.id, tokenId: tok.id, round, turn: combat.turn, at: Date.now(), since: clock(), settled, log: {}, ...(afterDelay ? { afterDelay: true } : {}) };
    if (!opened || !tok.object) return await save(combat, id, { ...base, labels: {}, note: cantOpen() });   /* no map, no packet: words instead of silent wrong answers */
    /* with the fight-start look's packets, one at a time (0.33.0): two packets built at once could give one label to two creatures */
    const failed = await withPackets(async () => {
      let built; try { built = await buildPacket(combat, tok); } catch (e) { console.error(`${ID} | packet`, e); await save(combat, id, { ...base, labels: {}, note: `I couldn't work out what ${tok.name} perceives (${e.message}). Play this turn yourself.` }); return true; }
      await saveTurns(combat, { [`requests.${id}`]: { ...base, labels: built.labels, packet: built.packet, ...(built.mindHeld.length ? { mindHeld: built.mindHeld } : {}), seen: situationNow(combat, tok, built.labels, built.others), nbAt: Date.now(), note: null, tries: 0, pos: 0 }, ...eventChange("turn", id, 0), ...packetExtras(combat, tok, built) });
      return false; });
    if (failed) return;
    if (!tok.getFlag(ID, "run")) await playMyself(combat, id);   /* unticked while it was being asked for (0.29.1 review 1): hers, as an untick on the turn is */
  } finally { starting.delete(key); }
}
const cantOpen = () => `${game.user.name} couldn't open the fight map. Play this turn yourself.`;
/* new labels and memory that come with a packet */
function packetExtras(combat, tok, built) {
  const change = {}; for (const [k, v] of Object.entries(built.fresh)) change[`labels.${k}`] = v;
  for (const [k, v] of Object.entries(remember(turns(combat).memory?.[tok.id] ?? {}, built.others, combat.round))) change[`memory.${tok.id}.${k}`] = v;
  /* a pointed-out belief ends once its own senses give it a square (0.30.0): it doesn't come back when it loses the creature again */
  const held = turns(combat).pointed?.[tok.id] ?? {}; for (const o of built.others) if (held[o.id] && canTarget(o.raw)) change[`pointed.${tok.id}.${o.id}`] = gone();
  return change;
}
/* Down: no HP left, dying, unconscious or dead. A creature the monster can see falling is the change that matters most. */
const isDown = actor => !actor || (actor.hitPoints?.value ?? 1) <= 0 || !!actor.isDead || ["dying", "unconscious"].some(c => actor.hasCondition?.(c));
const conditionWords = actor => (actor.conditions?.active ?? []).map(c => c.value ? `${c.slug} ${c.value}` : c.slug);
/** What the rest of the turn rests on, as things stand: the monster itself, and each creature it could name when asked (labels: label to token id). */
function situationNow(combat, tok, labels = {}, others = null) {
  const a = tok.actor, h = a.hitPoints ?? {};
  others ??= sense(combat, tok, turns(combat).memory?.[tok.id] ?? {});
  const byId = new Map(others.map(o => [o.id, o])), seen = {};
  for (const [label, id] of Object.entries(labels)) { const o = byId.get(id); if (o) seen[label] = { square: o.square, state: o.state, down: ["observed", "concealed"].includes(o.state) ? isDown(o.token.actor) : null }; }   /* a hidden one shows its square only: whether it went down isn't the monster's to know (0.33.1, review) */
  return situationOf({ me: { square: squareOf(tok, sceneOf(combat)), hp: (h.value ?? 0) + (h.temp ?? 0), actions: actionsOf(a, combat), conditions: conditionWords(a) }, others: seen });
}
/** The runner's answer to any change on the Combat. */
/* whose turn the runner last handled, by combat: a turn can pass with no `updateCombat` carrying `turn` (0.24.0, below) */
const turnOf = new Map();
/** A fight is over: nothing of it is kept on this page. */
export const onCombatGone = combat => { turnOf.delete(combat?.id); clearTimeout(looking.get(combat?.id)); looking.delete(combat?.id); };
/** The current combatant was deleted (Let it get away, or the GM removing it): the turn number stays the same, so core hands the turn to the next
    survivor with `combatTurnChange` and the system's turn start but no `updateCombat` with `turn` in it (14.370, seen live 2026-11-10: the next
    ticked monster was never asked). Called from both `combatTurnChange` and `deleteCombatant`; it waits a moment so an ordinary turn change, which
    `updateCombat` handles, has been noted first, and then handles only a turn nobody handled. */
export function onTurnHandedOn(combat) {
  if (!isRunner() || !combat?.started) return;
  setTimeout(() => { if (!game.combats.has(combat.id) || !combat.started) return; const now = combat.combatant?.id ?? null;
    if (!handedOn(turnOf.has(combat.id), turnOf.get(combat.id) ?? null, now)) return;
    onCombatUpdate(combat, { turn: combat.turn }); }, 150);
}
/* A second look a moment after every turn change (0.29.0, seen live): when two turn changes land within about 200 ms (an Auto monster ends its
   turn and the GM presses next turn in the same moment), this page's `combat.combatant` can read the creature before for an instant, so the look
   above takes the turn for an unticked creature's and nobody asks for the monster's. `onTurnChange` asks at most once for a turn, so looking
   again costs nothing when the first look was right. */
const LOOK_AGAIN_MS = 1200, looking = new Map();
function lookLater(combat) {
  clearTimeout(looking.get(combat.id));
  looking.set(combat.id, setTimeout(() => { looking.delete(combat.id); if (game.combats.get(combat.id)?.started) onTurnChange(combat).catch(e => console.error(`${ID} | turn`, e)); }, LOOK_AGAIN_MS));
}
export function onCombatUpdate(combat, change) {
  if (!isRunner()) return;
  if ("turn" in change || "round" in change) turnOf.set(combat.id, combat.combatant?.id ?? null);
  if ("turn" in change || "round" in change) turnAt.set(combat.id, performance.now());
  if ("turn" in change || "round" in change) booked(() => markTurn(combat));   /* fight memory: allies' deeds count from a monster's last turn */   /* when the turn change arrived: `settle` counts from here */
  if ("turn" in change || "round" in change) turnReactions(combat).catch(e => console.warn(`${ID} | reactions`, e));   /* monsters' reactions (0.21.0): open offers lapse, the new creature's reaction comes back */
  if ("turn" in change || "round" in change) leaveWaiting(combat).catch(e => console.warn(`${ID} | waiting`, e)).then(() => dropInstantAreas(combat, currentRequest(combat) ? { id: currentRequest(combat).id, pos: 0 } : null)).catch(e => console.warn(`${ID} | areas`, e));
  if ("turn" in change || "round" in change) { const prev = { ...(combat.previous ?? {}) };   /* the turn that just ended, read before anything awaits */
    fallIfAloft(combat, prev).catch(e => console.warn(`${ID} | fall`, e)).then(() => sinkNote(combat, prev)).catch(e => console.warn(`${ID} | sink`, e)).then(() => settleClimbers(combat)).catch(e => console.warn(`${ID} | climbing`, e)).then(() => settleBurrowers(combat)).catch(e => console.warn(`${ID} | burrowing`, e)).then(() => noteWhatTheySense(combat)).catch(e => console.warn(`${ID} | memory`, e)).then(() => checkSides(combat)).catch(e => console.warn(`${ID} | sides`, e)).then(() => settleBands(combat)).catch(e => console.warn(`${ID} | bands`, e)).then(() => onTurnChange(combat)).catch(e => console.error(`${ID} | turn`, e));
    lookLater(combat); lookCheck(combat).catch(e => console.warn(`${ID} | look`, e)); }   /* the fight-start look (0.33.0): started at the fight's start, dropped once round 1 is over */
  if (combat.started && !turns(combat).hidStart) hiddenAtStart(combat).catch(e => console.warn(`${ID} | hidden at the start`, e));   /* B-7 (0.33.2) */
  act(combat);
}
/* ---------- falling ---------- */
/** A ticked monster still in the air at the end of a turn the module ran, with no Fly in that round, falls (Rules ID 2344: "If you're airborne at the end
    of your turn and didn't use a Fly action this round, you fall"). It uses Arrest a Fall (its reaction, needing a fly Speed: Acrobatics or Reflex, the
    better, against DC 15); on a failure it takes bludgeoning damage of half the distance and lands prone (Player Core, falling). A turn the GM played
    herself, or one ended by a Delay, is left alone: the GM may have flown it by hand, and a Delay hasn't ended its turn. prev: Combat#previous. */
async function fallIfAloft(combat, prev) {
  if (!prev?.combatantId || prev.round == null) return;
  const c = combat.combatants.get(prev.combatantId), tok = c?.token; if (!tok?.getFlag(ID, "run") || !runnable(tok)) return;
  const fall = heightUp(tok), mine = Object.entries(turns(combat).requests ?? {}).filter(([, r]) => !r.reaction && r.combatantId === c.id && r.round === prev.round).sort((a, b) => (a[1].at ?? 0) - (b[1].at ?? 0));
  const what = shouldFall({ requests: mine.map(([, r]) => r), height: fall, flies: flySpeedOf(tok.actor) > 0, dead: !!tok.actor?.isDead, forward: movedOn(prev, { round: combat.round, turn: combat.turn }), clinging: !!treeUp(tok, sceneOf(combat)) });
  if (!what) return;
  const lastId = mine.at(-1)[0];
  const before = request(combat, lastId)?.note ?? null, kept = w => [before, w].filter(Boolean).join(" ");   /* the turn's own note stays (0.33.1, review) */
  /* first, so a second turn change can't make it fall twice; the note says what is under way in case a reload cuts it short */
  await save(combat, lastId, { fell: { from: fall }, note: kept(`${tok.name} didn't Fly this round and is falling ${fall} ft. If {they} still {shows|show} in the air, move {them} to the ground and check {their} HP.`) });
  if (!(await ensureScene(combat) && tok.object)) { await save(combat, lastId, { note: kept(`${tok.name} didn't Fly this round and falls ${fall} ft. I couldn't open the map, so move {them} down yourself${what === "fall" ? `; {they} may Arrest the Fall (DC 15), or else {they} {takes|take} ${Math.floor(fall / 2)} bludgeoning damage and {lands|land} prone` : ""}.`) }); return; }
  if (what === "drop") { await watched(() => tok.update({ elevation: 0 })); await save(combat, lastId, { fell: { from: fall, dead: true }, note: kept(`${tok.name}'s body fell ${fall} ft to the ground.`) }); return; }
  const actor = tok.actor, stats = [actor.skills?.acrobatics, actor.saves?.reflex].filter(Boolean).sort((a, b) => (b.mod ?? 0) - (a.mod ?? 0));
  let saved = false;
  if (stats[0] && !cantAct(actor)) {   /* Arrest a Fall is a reaction: not while it can't act. Reactions used earlier aren't tracked yet. */
    const roll = await watched(() => stats[0].roll({ dc: { value: 15 }, skipDialog: true, label: "Arrest a Fall", extraRollOptions: ["action:arrest-a-fall"], token: tok, rollMode: "publicroll" }));
    saved = (roll?.degreeOfSuccess ?? 0) >= 2;
  }
  await watched(() => tok.update({ elevation: 0 }));
  let words = `${tok.name} didn't Fly this round, so {they} fell ${fall} ft`;
  const dmg = saved ? 0 : await fallDamage(tok, fall);
  if (dmg > 0) words += `, took ${dmg} bludgeoning damage and landed prone.`;
  else words += saved ? `; {they} Arrested the Fall and took no damage.` : `${fall <= 5 ? " (no damage from 5 ft or less)" : ""}.`;
  await save(combat, lastId, { fell: { from: fall, saved, damage: saved ? 0 : dmg }, note: kept(words) });
}
/** Falling damage (Player Core, Falling, Rules ID 2352): a fall of more than 5 ft deals bludgeoning damage of half the distance (at most 750), and a
    creature that takes any lands prone. It is the monster's own, so it is applied whatever the monster-damage setting says. Returns the damage taken.
    (0.15.0: before, a 5-ft fall dealt 2.) */
async function fallDamage(tok, fall) {
  const dmg = fall > 5 ? Math.min(750, Math.floor(fall / 2)) : 0, actor = tok.actor; if (!(dmg > 0)) return 0;
  const DamageRoll = CONFIG.Dice.rolls.find(r => r.name === "DamageRoll"), roll = await new DamageRoll(`${dmg}[bludgeoning]`).evaluate();
  await watched(() => roll.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Falling ${fall} ft` }, { rollMode: "publicroll" }));
  await watched(() => actor.applyDamage({ damage: roll, token: tok, item: null, shieldBlockRequest: false }));
  if (!actor.isDead) await watched(() => actor.increaseCondition?.("prone"));
  return dmg;
}
/** A ticked monster whose turn the module ran to the end, left in deep water without a successful Swim: the rules sink it 10 ft or let the current take
    it, as the GM decides (Player Core Swim, Actions ID 2381). Swimming is at the surface only for now (Rhea, 2026-11-08), so the module moves nothing and
    says so on its card. Same guards as the fall (`shouldSink`); `sank` is saved with the note so a second turn change can't repeat it. */
async function sinkNote(combat, prev) {
  if (!prev?.combatantId || prev.round == null) return;
  const c = combat.combatants.get(prev.combatantId), tok = c?.token; if (!tok?.getFlag(ID, "run") || !runnable(tok)) return;
  const mine = Object.entries(turns(combat).requests ?? {}).filter(([, r]) => !r.reaction && r.combatantId === c.id && r.round === prev.round).sort((a, b) => (a[1].at ?? 0) - (b[1].at ?? 0));
  const wet = await stillInWater(combat, tok);
  if (!shouldSink({ requests: mine.map(([, r]) => r), wet: !!wet, dead: !!tok.actor?.isDead, forward: movedOn(prev, { round: combat.round, turn: combat.turn }) })) return;
  await save(combat, mine.at(-1)[0], { sank: true, note: joinNote(combat, mine.at(-1)[0], `${tok.name} ended {their} turn in deep ${wet} water without a successful Swim, so by the rules {they} {sinks|sink} 10 ft or the current carries {them}, as you decide. The module keeps swimmers at the surface for now, so it hasn't moved {them}.`) });
}
/** The deep water under a token now ("calm", "flowing" or null), read from the scene's own documents (no canvas needed). */
async function stillInWater(combat, tok) {
  const scene = sceneOf(combat); if (heightUp(tok) > 0) return null;
  const { model, read } = await readMap(scene); return waterUnder(squareOf(tok, scene), sizeOf(tok), waterKinds(deepWater(scene, model), read));
}
/** The turn moved on while a monster's spell waited for a save: that request ends, and the note tells the GM what's left on the card. */
async function leaveWaiting(combat) {
  const change = {};
  for (const [id, r] of Object.entries(turns(combat).requests ?? {})) {
    if (!["saves", "fled"].includes(r.state) || (r.round === combat.round && r.combatantId === combat.combatant?.id)) continue;
    if (r.state === "fled") { change[`requests.${id}.state`] = "done"; change[`requests.${id}.extend`] = null; change[`requests.${id}.note`] = [r.note, "The turn moved on while {they} stood at the map's edge."].filter(Boolean).join(" "); continue; }
    const step = r.steps?.[r.pos ?? 0];
    change[`requests.${id}.state`] = "done"; change[`requests.${id}.note`] = [r.note, `The turn moved on while ${step?.itemName ?? "a spell"} waited for ${step?.area?.aim ? "saves" : `${step?.target ? `${step.target}'s` : "a"} save`}: apply what's left from its card.`].filter(Boolean).join(" ");
  }
  if (Object.keys(change).length) await saveTurns(combat, change);
}
function act(combat) {
  for (const [id, x] of Object.entries(turns(combat).requests ?? {})) if (x.reaction && x.go && x.state === "ready") doReaction(combat, id).catch(e => console.error(`${ID} | reaction`, e));   /* Do it on a monster's reaction, pressed in another GM's browser */
  if (Object.keys(ordersOf(combat).pending ?? {}).length) runPending(combat).catch(e => console.error(`${ID} | order`, e));   /* her Give orders box (0.28.0) */
  if (Object.keys(turns(combat).speech?.pending ?? {}).length) runSpeech(combat).catch(e => console.error(`${ID} | speech`, e));   /* her Speak / Yield box (0.32.0) */
  /* Let Angel plan it, after a command critically failed (0.30.0): the turn that waited for her is asked for now */
  { const ct = combat.combatant?.token ?? null, cc = ct ? turns(combat).commands?.[ct.id] : null;
    if (cc?.angel && cc.used?.round === combat.round && !Object.values(turns(combat).requests ?? {}).some(x => !x.reaction && x.combatantId === combat.combatant.id && x.round === combat.round && !x.delayed && !x.passed)) onTurnChange(combat).catch(e => console.error(`${ID} | turn`, e)); }
  const r = currentRequest(combat); if (!r) return;
  if (r.state === "submitted") judge(combat, r.id).catch(e => console.error(`${ID} | plan`, e));
  else if (r.state === "saves" && Object.values(r.rollFor ?? {}).some(Boolean)) doIt(combat, r.id).catch(e => console.error(`${ID} | turn`, e));   /* Roll it for them */
  else if ((r.ask || r.edit) && CHANGEABLE.includes(r.state)) runChange(combat, r.id).catch(e => console.error(`${ID} | change`, e));   /* the Change button (0.19.0), before a press */
  else if (r.nbEdit && !r.go && CHANGEABLE.includes(r.state)) runRemember(combat, r.id).catch(e => console.error(`${ID} | notebook`, e));   /* her notebook edit (0.25.0): the rest is thought through again */
  else if (r.go && RESUMABLE.includes(r.state)) doIt(combat, r.id).catch(e => console.error(`${ID} | turn`, e));
  else if (r.state === "fled" && r.extend) runExtend(combat, r.id).catch(e => console.error(`${ID} | extend`, e));
}
/** A monster ticked during its own turn. */
export function onTokenFlag(tok, change) {
  if (!isRunner()) return;
  if (foundry.utils.getProperty(change, `flags.${ID}.run`)) for (const c of game.combats.filter(c => c.started && c.combatant?.tokenId === tok.id)) onTurnChange(c).catch(e => console.error(`${ID} | turn`, e));
  /* unticked during its own turn (0.29.1, F-1; Rhea, 2026-11-12: "Close it as Play it myself"): a request nothing of has run yet closes as Play it
     myself would, so a listening chat can't plan for a monster she has taken over. A turn Angel has started is left alone. */
  if (foundry.utils.getProperty(change, `flags.${ID}.run`) === false) for (const c of game.combats.filter(c => c.started && c.combatant?.tokenId === tok.id)) {
    const r = currentRequest(c);
    if (r?.tokenId === tok.id && untouched(r) && !running.has(r.id)) playMyself(c, r.id).catch(e => console.error(`${ID} | untick`, e));
  }
  /* its yield ended during its own turn (Fight on, a blow; 0.29.0): it gets the turn the module was passing */
  if (foundry.utils.hasProperty(change, `flags.${ID}.yieldOver`) && !yieldOf(tok)) for (const c of game.combats.filter(c => c.started && c.combatant?.tokenId === tok.id)) onTurnChange(c).catch(e => console.error(`${ID} | turn`, e));
  /* Auto ticked while its plan waits on the card (ready: before its first step, or between steps for Next step): it runs as if Auto had been on from the
     start (Rhea, 2026-11-09), waiting out the game's pause like Auto's own start. A held, stopped or running turn is left as it is. */
  if (foundry.utils.getProperty(change, `flags.${ID}.auto`) === true) for (const c of game.combats.filter(c => c.started && c.combatant?.tokenId === tok.id)) {
    const r = currentRequest(c), still = n => n?.state === "ready" && !n.hold && !n.gmWait && (n.pos ?? 0) === (r.pos ?? 0) && !!tok.getFlag(ID, "auto");
    /* a pause the GM has to apply an ability's effects in waits for her Next step, Auto or not; read again after the game's pause (0.17.0 review) */
    if (still(r) && r.tokenId === tok.id && !running.has(r.id)) (async () => { if (!(await pausedAuto(c, r.id, tok)) && still(request(c, r.id))) await doIt(c, r.id); })().catch(e => console.error(`${ID} | turn`, e));
  }
}
/** The runner has just loaded: pick up whatever happened while it was away. A turn left "running" stopped when the page went, so it waits for Do it,
    which carries on from the record and never repeats a step. */
export async function onRunnerReady() {
  if (!isRunner()) return;
  await sweepBarriers().catch(e => console.warn(`${ID} | barrier`, e));   /* earth barriers left by a fight that is gone, or half-made (0.35.0) */
  for (const combat of game.combats.filter(c => c.started)) {
    const r = currentRequest(combat);
    if (r?.state === "running" && !running.has(r.id)) await save(combat, r.id, { state: "stopped", go: false, note: `${game.user.name}'s page reloaded during this turn. Check the chat and HP, then Do it carries on from where it stopped.` });
    /* a reload after the extension was recorded and before the new ask (0.33.1, review): the squares are already moved, so it only asks again */
    if (r?.state === "extending" && !r.extending && r.extended && !running.has(r.id)) { const tok = sceneOf(combat)?.tokens.get(r.tokenId);
      if (tok && await ensureScene(combat)) await replan(combat, { ...r, id: r.id }, r.pos ?? r.steps?.length ?? 0, [{ who: "me", what: "extended", side: r.extended }], tok, { counted: false }).catch(e => console.error(`${ID} | extend`, e)); }
    /* a reload while the map was extending: whether or not it grew, asking again from a fresh packet is right (the monster can flee to the same edge again) */
    if (r?.state === "extending" && r.extending && !running.has(r.id)) { const tok = sceneOf(combat)?.tokens.get(r.tokenId);
      /* the Survey Sheet's job ran on this page and went with it (0.25.0, seen live: the map hadn't grown, and the card said it had): only a map
         that did grow is treated as extended; otherwise the buttons come back, which is safe because the job is gone with the page */
      const [cols, rows] = mapSquares(sceneOf(combat)), grew = !Array.isArray(r.extendFrom) || cols > r.extendFrom[0] || rows > r.extendFrom[1];
      if (tok && grew && await ensureScene(combat)) await afterExtend(combat, r.id, r.extending, tok, { history: tok.movementHistory?.length ?? 0 }).catch(e => console.error(`${ID} | extend`, e));
      else if (tok && !grew) await save(combat, r.id, { state: "fled", extending: null, extendFrom: null, note: `${game.user.name}'s page reloaded while the map was being extended, and the map didn't grow. Extend it again, or let it get away.` }); }
    noteGap(combat);   /* fight memory (0.25.0): what happened while this page was away isn't in any notebook, and the notebooks say so */
    /* a Delay cut off by the reload after its turn ended and before its place moved (0.12.0): the request isn't current any more, so it is closed here */
    for (const [id, x] of Object.entries(turns(combat).requests ?? {})) { const s = x.steps?.[x.pos ?? 0]; if (x.state === "running" && s?.do === "delay" && x.log?.[x.pos ?? 0]?.ended && !x.log[x.pos ?? 0].moved && !running.has(id)) await save(combat, id, { state: "done", delayed: true, note: joinNote(combat, id, `${game.user.name}'s page reloaded as ${sceneOf(combat).tokens.get(x.tokenId)?.name ?? "the monster"} delayed: {their} turn ended, but {their} place in the order may not have moved. Check the tracker and drag {them} to just after ${s.after} if {they} {isn't|aren't}.`) }); }
    /* a monster's reaction cut off by the reload (0.21.0): never repeated; the chat and HP say how far it got */
    for (const [id, x] of Object.entries(turns(combat).requests ?? {})) if (x.reaction && x.state === "running" && !running.has(id)) await save(combat, id, { state: "done", go: false, note: joinNote(combat, id, `${game.user.name}'s page reloaded during this Reactive Strike. Check the chat and HP: it may not have finished.`) });
    noteCarried(combat);
    if (!turnOf.has(combat.id)) turnOf.set(combat.id, combat.combatant?.id ?? null);   /* this page's first look: the turn it finds is the one it handles below */
    await onTurnChange(combat); act(combat);
    if (r?.state === "saves") doIt(combat, r.id).catch(e => console.error(`${ID} | turn`, e));   /* a save rolled while this page was away */
  }
}
/** Live values for the legality check. Reach, distance and moves need the canvas on the fight scene. used: what this request's finished steps took. Names
    are labels, because a refusal's reason goes back to the thinker; the card puts names in. */
async function gather(combat, req, used = { actions: 0, attacks: 0 }, { moves = true, before = null, spells = false } = {}) {
  const scene = sceneOf(combat), tok = scene.tokens.get(req.tokenId), actor = tok.actor;
  const holding = heldItems(actor);
  const strikes = await Promise.all(strikesWithIds(actor).map(async ({ id, strike: a }) => { const m = await ammoOf(actor, a).catch(() => null), w = weaponOf(actor, a); return { id, name: a.label, weapon: holding.find(h => h.itemId === w?.id)?.id ?? null, dropped: droppedWeapon(actor, a), ...(sheathedWeapon(actor, a) ? { sheathed: true, weaponItem: w.id, hands: handsFor(w) } : {}), ...(w?.system?.usage?.value === "held-in-one-plus-hands" ? { bothToUse: true } : {}), reach: actor.getReach({ action: "attack", weapon: a.item }), ranged: !!a.item?.isRanged, maxRange: a.item?.range?.max ?? null, effects: [...(a.item?.system?.attackEffects?.value ?? [])], ...ammoFields(m, shotsFor(combat, tok, id, m)) }; }));
  /* only what it perceived when asked, and still does: a plan can't name anything else */
  const now = new Map(sense(combat, tok, turns(combat).memory?.[tok.id] ?? {}).map(o => [o.id, o])), targets = {};
  for (const [label, tokenId] of Object.entries(req.labels ?? {})) { const o = now.get(tokenId); if (o && canTarget(o.state)) targets[label] = { name: label, square: o.square, ...(o.state === "hidden" ? {} : placeOf(o.token, scene)), size: sizeOf(o.token), ...heightOf(o.token), ...(o.pointed ? { elev: o.height ?? 0 } : {}), flat: flatDC(o.state),   /* a pointed-out creature: the height it was pointed out at, never where it is now (0.30.0 review 3) */ cat: o.token.actor?.size ?? null, held: !!turns(combat).grips?.[tok.id]?.[tokenId] && isHeld(o.token.actor) }; }
  /* earth barriers standing on this map (0.35.0): a Strike may be aimed at one, counted to the square on its far side from its caster (the side
     a monster comes from); a blinded monster sees none */
  const slabs = {}; if (!actor.hasCondition?.("blinded")) for (const b of barriersOf(combat, scene.id)) slabs[b.label] = { name: "the earth barrier", square: b.squares[1], pos: b.squares[1], span: 1, size: 1, elev: 0, depth: 1, flat: 0, slab: true };   /* only a Strike may name one (review 6) */
  /* moves are worked out only for a plan that has a Stride, Step or Crawl, so trouble there can't stop a plan of Strikes */
  const speed = landSpeed(actor), flySpeed = flySpeedOf(actor), swimSpeed = swimSpeedOf(actor), burrowSpeed = burrowSpeedOf(actor); let route = null;
  if (moves) { try { route = await mover(combat, tok, speed, knownTo(combat, tok, [...now.values()]), flySpeed, swimSpeed, burrowSpeed); } catch (e) { console.error(`${ID} | moves`, e); const why = `I couldn't work out moves here (${e.message}).`; route = () => ({ ok: false, reason: why }); } }
  /* Take Cover: the cover Visioner gives it now against each creature it sees and could name, and the walls and trunks next to a square */
  const vis = visionerApi(), coverFrom = {};
  if (vis) for (const [label, tokenId] of Object.entries(req.labels ?? {})) { const o = now.get(tokenId); if (o && SEES.includes(o.state)) { const l = coverOf(vis, o.token, tok); if (STANDARD.includes(l)) coverFrom[label] = l; } }
  return { pro: P(tok, combat),   /* its own pronoun, for every reason `checkPlan` gives (0.30.1) */
    actions: Math.max(0, actionsOf(actor, combat) - (req.spent ?? 0) - used.actions), attacksBefore: (req.attacks ?? 0) + used.attacks, strikes, targets, slabs,
    me: { square: squareOf(tok, scene), ...placeOf(tok, scene), size: sizeOf(tok), ...heightOf(tok), cat: actor.size ?? null }, speed, flySpeed, swimSpeed, waterAt: route?.waterAt, waterIn: route?.waterIn,
    /* Climb and Release (0.15.0): its climb Speed, the trees beside a square, the tree it is up now, what it holds */
    /* Burrow (0.16.0): its burrow Speed, whether it is under the ground now, soil under a footprint, a creature it knows of where it would come up */
    burrowSpeed, below: isBelow(tok), soilAt: route?.soilAt ?? null, occupiedAt: route?.occupiedAt ?? null, glides: glidesThroughRock(actor), surfaceAt: route?.surfaceAt ?? null,
    climbSpeed: climbSpeedOf(actor), treesAt: route?.trees ? sq => treesBeside(sq, sizeOf(tok), route.trees) : null, onTree: treeUp(tok, scene), holding: holding.map(({ id, name, hands }) => ({ id, name, hands })),
    cantAct: cantAct(actor), cantMove: cantMove(actor), cantAttack: cantAttack(actor), prone: !!actor.hasCondition?.("prone"), route,
    tookCover: takingCover(tok), coverFrom, nearCover: nearCoverFor(scene),
    /* Interact and Delay (0.12.0): grabbed asks a DC 5 flat check of a manipulate action; a Delay needs an untouched turn and a creature still to act this round */
    grabbed: !!actor.hasCondition?.("grabbed"), fresh: !(req.spent ?? 0) && !used.actions && !(req.done?.length) && !before, order: turnOrder(combat, tok, req),
    /* flee: the map's edges as the scene stands now (an extended map has new bounds), never a stored size */
    edgeAt: (sq, n) => edgeSides(sq, n, ...mapSquares(scene)), party: onParty(actor),
    /* Hide: the light at a square (where it stands, or will after a move) and its own concealment */
    lightAt: sq => { const px = scene.grid.size, d = scene.dimensions, n = sizeOf(tok); return lightOn({ x: d.sceneX + (sq[0] + n / 2) * px, y: d.sceneY + (sq[1] + n / 2) * px }, scene); }, concealed: !!actor.hasCondition?.("concealed"),
    /* abilities, and its last action before this plan (a Grab or Knockdown needs it): the step just done, or the last thing done before a re-plan */
    allyLabels: Object.keys(alliesByLabel(combat, tok)),   /* only for words: a Strike at an ally is refused as one (0.19.0) */
    allies: alliesByLabel(combat, tok),   /* always, since 0.30.0 (B-5): an ability may be aimed at a friend, as a spell may */
    command: commandCtx(combat, tok),   /* 0.30.0: which of its allies it can Command as an animal, and why not */
    pointOut: pointCtx(combat, tok, req, now),   /* 0.30.0: which of the creatures it perceives it can Point Out (worked out only when a plan asks) */
    orders: orderCtx(combat, tok),   /* 0.28.0: whether it leads a band and may give this round's order */
    speech: speechCtx(combat, tok), yielded: !!yieldOf(tok),   /* 0.29.0: whether it may speak to the party and yield; a yielded monster's plan is refused */
    abilities: abilityList(actor).map(({ item, ...a }) => a), last: lastAction({ ...(before ?? { done: req.done?.at(-1) ?? null }), strikes }),
    /* spells: what it can cast now, and for a spell at a friend its allies (not hidden by the GM) and itself, by their labels */
    ...(spells ? { spells: await spellBook(actor), saveRows: targetHelperOn(), reach: actor.getReach?.({ action: "interact" }) ?? 5, areaOf: areaCheck(combat, tok, req, now) } : {}) };   /* touch: the creature's own reach, not a weapon's */
}
/** Its allies the GM hasn't hidden, and itself, by label, for a spell aimed at a friend. */
function alliesByLabel(combat, tok) {
  const labels = turns(combat).labels ?? {}, scene = sceneOf(combat), out = {};
  for (const t of [tok, ...alliesOf(scene, tok).filter(a => !a.hidden)]) { const l = labels[t.id]; if (l) out[l] = { name: l, square: squareOf(t, scene), ...placeOf(t, scene), size: sizeOf(t), ...heightOf(t), flat: 0, ally: true }; }
  return out;
}
/** For a Delay: for each creature the monster could name (what it perceived when asked, its allies and itself), whether its turn is still to come this
    round ("later"), has passed ("earlier"), or is the monster's own ("self"). Order is the fight's current order; a creature not in the fight is left out. */
function turnOrder(combat, tok, req) {
  const out = {}, order = combat.turns ?? [], mine = order.findIndex(c => c.tokenId === tok.id);
  if (mine < 0) return out;   /* not in the order: nothing can be said, so every label reads as unknown */
  const allies = knownAllies(sceneOf(combat), tok);   /* as in the packet: a GM-hidden ally stays out, a burrowed one is there */
  const named = { ...Object.fromEntries(Object.entries(turns(combat).labels ?? {}).filter(([id]) => id === tok.id || allies.some(a => a.id === id)).map(([id, l]) => [l, id])), ...(req.labels ?? {}) };
  for (const [label, tokenId] of Object.entries(named)) { const i = order.findIndex(c => c.tokenId === tokenId); if (i < 0 || order[i].isDefeated || order[i].initiative == null) continue; out[label] = tokenId === tok.id ? "self" : i > mine ? "later" : "earlier"; }
  return out;
}
/** A label's token: the creatures it perceived when asked, then its allies and itself. */
const tokenIdOf = (combat, r, label) => r.labels?.[label] ?? Object.entries(turns(combat).labels ?? {}).find(([, l]) => l === label)?.[0] ?? null;
/** Toolbelt's Target Helper puts a row per target on a spell's card, where a player rolls their own save (Rhea, 2026-11-07). Without it, a save spell is the GM's. */
const targetHelperOn = () => { try { return !!game.modules.get(TOOLBELT)?.active && !!game.settings.get(TOOLBELT, "targetHelper.enabled"); } catch { return false; } };

/* ---------- moving ---------- */
/** Height for distances: PF2e counts the vertical gap when two creatures stand at different elevations. */
/** How far above the ground a token is, in feet, for the packet (0 on the ground). */
const heightUp = tok => Math.max(0, Math.round(Number(tok?.elevation) || 0));
/** A token's height span in feet, for an area's vertical test: from its elevation up by its depth (squares of 5 ft). at: an elevation to use instead. */
const spanOf = (tok, at = null) => { const elev = at != null ? Number(at) || 0 : Number(tok.elevation) || 0; return { elev, top: elev + (Number(tok.depth) || sizeOf(tok)) * 5 }; };
const heightOf = tok => ({ elev: Number(tok.elevation) || 0, depth: Number(tok.depth) || sizeOf(tok) });
const hasMove = steps => (steps ?? []).some(s => isMove(s) || s?.do === "climb");   /* a Burrow is a move (0.16.0), so it gets the routes and the soil */   /* a Climb needs the map's trees, which come with the routes */
const hasSpell = steps => (steps ?? []).some(s => s?.do === "spell");
/** The creatures a monster knows are there: allies (not hidden by the GM), and those it perceives well enough to know their square. Only these shape
    the routes it's told about, so a refusal never gives away a creature it can't perceive. others: what `sense` gave. */
function knownTo(combat, tok, others) {
  const known = new Set(others.filter(o => canTarget(o.state)).map(o => o.id));
  for (const a of alliesOf(sceneOf(combat), tok)) if (!a.hidden) known.add(a.id);
  /* a creature on nobody's side in plain view (a bystander): not in the packet, but in the way like anyone else (0.33.1, review: unknown, it cut
     every Stride short with no reason the thinker could act on) */
  /* only one it perceives (review of 0.33.1: a refusal never gives away a creature it can't perceive), and never for a creature that is on nobody's
     side itself (to it every creature would be a bystander) */
  if (tok.actor?.alliance) { let one = null;
    for (const t of sceneOf(combat).tokens) if (t.id !== tok.id && !t.hidden && t.actor?.isOfType?.("creature") && !t.actor.alliance && !t.getFlag(ID, "escaped")) { one ??= senser(combat, tok, turns(combat).memory?.[tok.id] ?? {}); if (canTarget(one(t).state)) known.add(t.id); } }
  return known;
}
/* Foundry has no pathfinding, so move.mjs finds the route; Foundry's own measurement then says what it costs, because that is what a real move charges
   (the same on 5 test routes over difficult terrain, 2026-11-07). Walls are core's own movement test between where the creature would stand. */
const landSpeed = actor => Number(actor.system.movement?.speeds?.land?.value) || 0;
const flySpeedOf = actor => Number(actor.system.movement?.speeds?.fly?.value) || 0;
const swimSpeedOf = actor => Number(actor.system.movement?.speeds?.swim?.value) || 0;
const climbSpeedOf = actor => Number(actor.system.movement?.speeds?.climb?.value) || 0;
/* ---------- burrowing (0.16.0) ---------- */
const burrowSpeedOf = actor => Number(actor?.system?.movement?.speeds?.burrow?.value) || 0;
/** Is this token burrowed under the ground: the module's flag and its token below 0. A token the GM lifted back to 0 or above isn't, whatever its flag. */
const isBelow = tok => !!tok?.getFlag?.(ID, "burrowed") && (Number(tok.elevation) || 0) < 0;
/** Soil regions on a scene: Angel's judgment (flag `soil`) or any region the GM names "Soil..." (Rhea, 2026-11-08: Angel judges maps the module can't read; she
    can change the result). */
const SOIL_NAME = /^soil\b/i;
const soilRegions = scene => scene.regions.filter(r => r.getFlag(ID, "soil") || SOIL_NAME.test(r.name ?? ""));
/** Whether the ground of a scene the module can't read has been judged (the scene's flag, or soil regions the GM drew herself). */
const groundJudged = scene => !!scene.getFlag(ID, "ground") || soilRegions(scene).length > 0;
/** Which squares a burrower can dig through, as (i, j) → boolean. A Survey Sheet encounter map: everything but rock (`rockSquares`: crag, outcrops, big
    boulders, standing stones, ruin walls, caves), solid things (trunks, walls through the square) and deep water. Any other scene: only inside soil
    regions; everywhere else counts as rock (and so does all of it until its ground is judged). */
function soilOf(scene, model, read, isDeep, glide = null) {
  const px = scene.grid.size, d = scene.dimensions, memo = new Map();
  if (glide) return (i, j) => model.inMap(i, j) && !isDeep(i, j) && !glide.hard(i, j);   /* Earth Glide: rock and earth alike (0.17.0) */
  if (read) { const rock = rockSquares(read, model.cols, model.rows); return (i, j) => model.inMap(i, j) && !rock[model.idx(i, j)] && !model.blocked[model.idx(i, j)] && !isDeep(i, j); }
  const regs = soilRegions(scene);
  return (i, j) => { if (!model.inMap(i, j)) return false; const k = model.idx(i, j);
    if (!memo.has(k)) memo.set(k, !model.blocked[k] && !isDeep(i, j) && regs.some(r => r.testPoint({ x: d.sceneX + (i + .5) * px, y: d.sceneY + (j + .5) * px, elevation: 0 }))); return memo.get(k); };
}
/* ---------- Earth Glide (0.17.0; Rhea, 2026-11-09: "Absolutely") ---------- */
/* Monster Core's abilities that let a burrower through rock: Earth Glide ("can Burrow through any earthen matter, including rock"), Rock Tunneler
   ("can burrow through solid stone") and Unstoppable Burrow. PF2e gives them no slug, so they are read by name. */
const GLIDE = /^(earth glide|rock tunneler|unstoppable burrow)$/i;
/** Whether it burrows through rock and earth by its own ability (it needs a burrow Speed too). */
const glidesThroughRock = actor => burrowSpeedOf(actor) > 0 && !!actor?.items?.some(i => GLIDE.test(String(i.name ?? "").trim()));
/** Stone-walls regions: Angel's judgment (flag `stoneWalls`) or any region the GM names "Stone walls..." (Rhea, 2026-11-09: what the walls are made of is
    Angel's choice for each place; she can change it). */
const STONE_NAME = /^stone walls?\b/i;
const stoneRegions = scene => scene.regions.filter(r => r.getFlag(ID, "stoneWalls") || STONE_NAME.test(r.name ?? ""));
/** The walls whose material the map doesn't say: anything that stops movement and isn't a door or one of Survey Sheet's (its trunks are wood, its stones,
    ruin walls, outcrops and cave rock are stone). */
const plainWalls = scene => scene.walls.filter(w => w.move !== CONST.WALL_MOVEMENT_TYPES.NONE && !w.door && !w.flags?.[SURVEY]?.enc && !w.flags?.[ID]?.barrier);   /* an earth barrier (0.35.0) is no wall of the map's own */
/** Whether the walls of a scene have been judged (the scene's flag, or stone-walls regions the GM drew herself). */
const wallsJudged = scene => !!scene.getFlag(ID, "walls") || stoneRegions(scene).length > 0;
/** wall -> whether a glider passes through it: Survey Sheet's features yes and its trunks no; a door never (a way through, wood or metal); any other
    wall when it lies in a stone-walls region (its middle, or a quarter square either side of it, so a wall along a region's edge counts), otherwise not:
    until a scene's walls are judged, they stop it. */
function earthenWall(scene) {
  const regs = stoneRegions(scene), q = scene.grid.size / 4;
  return w => { if (w.door) return false; const enc = w.flags?.[SURVEY]?.enc; if (enc) return enc === "feature"; if (!regs.length) return false;
    /* points along it (a long wall can run partly through a stone area: stone when most of it is, 0.17.0 review), each with a quarter square either side */
    const pts = [.1, .3, .5, .7, .9].map(t => [w.c[0] + (w.c[2] - w.c[0]) * t, w.c[1] + (w.c[3] - w.c[1]) * t]);
    const inside = ([x, y]) => [[0, 0], [q, 0], [-q, 0], [0, q], [0, -q]].some(([dx, dy]) => regs.some(r => r.testPoint({ x: x + dx, y: y + dy, elevation: 0 })));
    return pts.filter(inside).length >= 3; };
}
/** What stops a glider on this scene: every wall that stops movement and isn't earthen (an open door doesn't stop anything), as the squares those walls
    pass through (`hard`) and the test between two squares (`wallBetween`, for a creature `size` squares across). */
function glideBounds(scene, model) {
  const d = scene.dimensions, px = scene.grid.size, earthen = earthenWall(scene), open = CONST.WALL_DOOR_STATES.OPEN;
  const walls = scene.walls.filter(w => w.move !== CONST.WALL_MOVEMENT_TYPES.NONE && !(w.door && w.ds === open) && !earthen(w))
    .map(w => ({ ax: (w.c[0] - d.sceneX) / px, ay: (w.c[1] - d.sceneY) / px, bx: (w.c[2] - d.sceneX) / px, by: (w.c[3] - d.sceneY) / px }));
  const hard = wallSquares(walls, model.cols, model.rows);
  return { hard: (i, j) => model.inMap(i, j) && !!hard[model.idx(i, j)], wallBetween: (a, b, size = 1) => crossesWalls(walls, a, b, size) };
}
/** The open floor of a scene, for where a glider may come up (0.17.0): every square a creature could walk to from where creatures stand on the surface now
    (not below, not escaped), round every wall that stops movement except doors (a door is a way through), over nothing solid and no deep water. On a
    hand-built map the solid rock outside the rooms has no walls through it, so "nothing solid there" alone would let a glider come up inside the rock.
    Returns (i, j) → boolean. */
function openFloor(scene, model, isDeep) {
  const d = scene.dimensions, px = scene.grid.size;
  const walls = scene.walls.filter(w => w.move !== CONST.WALL_MOVEMENT_TYPES.NONE && !w.door)
    .map(w => ({ ax: (w.c[0] - d.sceneX) / px, ay: (w.c[1] - d.sceneY) / px, bx: (w.c[2] - d.sceneX) / px, by: (w.c[3] - d.sceneY) / px }));
  const ok = (i, j) => model.inMap(i, j) && !model.blocked[model.idx(i, j)] && !isDeep(i, j), seen = new Set(), todo = [];
  for (const t of scene.tokens) { if (isBelow(t) || t.getFlag(ID, "escaped") || !t.actor?.isOfType?.("creature")) continue;
    for (const [i, j] of footprintAt(squareOf(t, scene), sizeOf(t))) if (ok(i, j) && !seen.has(`${i},${j}`)) { seen.add(`${i},${j}`); todo.push([i, j]); } }
  while (todo.length) { const [i, j] = todo.pop();
    for (const [a, b] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const x = i + a, y = j + b, k = `${x},${y}`; if (seen.has(k) || !ok(x, y) || crossesWalls(walls, [i, j], [x, y])) continue; seen.add(k); todo.push([x, y]); } }
  return (i, j) => seen.has(`${i},${j}`);
}
/** Into the ground or out of it: the token's flag and its visibility. Underground it is hidden from everyone (Rhea: "unseen while below"), as the GM's own
    hidden toggle does it; coming up it shows again, unless the GM had hidden it before it went down. */
async function setBelow(tok, down) {
  const f = tok.getFlag(ID, "burrowed");
  if (down) { if (!f) await watched(() => tok.update({ hidden: true, [`flags.${ID}.burrowed`]: { wasHidden: !!tok.hidden } })); else if (!tok.hidden) await watched(() => tok.update({ hidden: true })); return; }
  if (f) await watched(() => tok.update({ hidden: !!f.wasHidden, [`flags.${ID}.-=burrowed`]: null }));
}
/** At each turn change: a token flagged as burrowed that the GM brought up to the surface (or above) by hand is above ground again: shown, flag gone. */
async function settleBurrowers(combat) {
  for (const tok of sceneOf(combat)?.tokens ?? []) if (tok.getFlag(ID, "burrowed") && !isBelow(tok)) await setBelow(tok, false).catch(e => console.warn(`${ID} | burrowing`, e));
}
/* The picture Angel judges a map's ground from (0.16.0): the scene's own background with the grid and every square numbered, in a small panel on this page
   (the runner's), which the thinker looks at (on the chat route, the bridge's ui_look on the runner with selector #lythara-encounter-builder-ground). */
const GROUND_EL = `${ID}-ground`;
async function showGroundPicture(scene) {
  if (typeof document === "undefined") return false;
  const src = scene.levels?.contents?.[0]?.background?.src ?? scene.background?.src ?? null, d = scene.dimensions, px = scene.grid.size;
  const cols = Math.round(d.sceneWidth / px), rows = Math.round(d.sceneHeight / px), cell = Math.max(12, Math.min(32, Math.floor(1100 / Math.max(cols, rows)))), pad = 22;
  let el = document.getElementById(GROUND_EL);
  if (el && el.dataset.scene === scene.id && el.dataset.src === String(src)) return true;
  el?.remove(); el = document.createElement("div"); el.id = GROUND_EL; el.dataset.scene = scene.id; el.dataset.src = String(src);
  el.style.cssText = "position:fixed;left:8px;top:8px;z-index:100000;background:#fff;color:#000;padding:6px;border:2px solid #333;font:12px sans-serif;box-shadow:0 2px 12px #0008";
  const c = document.createElement("canvas"); c.width = pad + cols * cell; c.height = pad + rows * cell; const g = c.getContext("2d");
  g.fillStyle = "#ddd"; g.fillRect(0, 0, c.width, c.height);
  if (src) { const img = new Image(); img.src = src; await new Promise(res => { img.onload = res; img.onerror = res; setTimeout(res, 15000); }); if (img.naturalWidth) g.drawImage(img, pad, pad, cols * cell, rows * cell); }
  /* walls, so a corridor's edges read even on a plain picture */
  g.strokeStyle = "#c00"; g.lineWidth = 2; for (const w of scene.walls) { g.beginPath(); g.moveTo(pad + (w.c[0] - d.sceneX) / px * cell, pad + (w.c[1] - d.sceneY) / px * cell); g.lineTo(pad + (w.c[2] - d.sceneX) / px * cell, pad + (w.c[3] - d.sceneY) / px * cell); g.stroke(); }
  g.strokeStyle = "#0006"; g.lineWidth = 1; for (let i = 0; i <= cols; i++) { g.beginPath(); g.moveTo(pad + i * cell, pad); g.lineTo(pad + i * cell, pad + rows * cell); g.stroke(); } for (let j = 0; j <= rows; j++) { g.beginPath(); g.moveTo(pad, pad + j * cell); g.lineTo(pad + cols * cell, pad + j * cell); g.stroke(); }
  g.fillStyle = "#000"; g.font = `${Math.min(11, cell - 2)}px sans-serif`; g.textAlign = "center"; g.textBaseline = "middle";
  const every = cell >= 18 ? 1 : 2; for (let i = 0; i < cols; i += every) g.fillText(String(i), pad + (i + .5) * cell, pad / 2); for (let j = 0; j < rows; j += every) g.fillText(String(j), pad / 2, pad + (j + .5) * cell);
  const head = document.createElement("div"); head.textContent = `Angel is judging the ground and walls of "${scene.name}": squares x across, y down. Red lines are walls.`; head.style.marginBottom = "4px";
  el.append(head, c); document.body.append(el);
  setTimeout(() => { if (document.getElementById(GROUND_EL) === el) el.remove(); }, 10 * 60000);   /* gone after 10 minutes, or as soon as the judgment is in */
  return true;
}
const hideGroundPicture = () => { if (typeof document !== "undefined") document.getElementById(GROUND_EL)?.remove(); };
/** Angel's judgment of a scene's ground, made real: GM-only soil regions (flag `soil`, named "Soil (Angel)"), and the scene's flag so it is asked once.
    ground: brain.mjs's cleanGround ({ soil: "all" | "none" | [[x0, y0, x1, y1]] }). The GM can reshape or delete the regions with the region tools. */
const applyGround = (scene, ground, by = "Angel") => applyAreas(scene, ground.soil, { name: `Soil (${by})`, color: "#8b5a2b", flag: "soil", sceneFlag: "ground", by });
/** Angel's judgment of which walls are stone, for a monster that glides through rock (0.17.0): a GM-only region "Stone walls (Angel)" (flag `stoneWalls`)
    over the squares whose walls are stone, and the scene's flag `walls` so it is asked once. walls: brain.mjs's cleanWalls. */
const applyWalls = (scene, walls, by = "Angel") => applyAreas(scene, walls.stone, { name: `Stone walls (${by})`, color: "#7a7a7a", flag: "stoneWalls", sceneFlag: "walls", by });
/* areas: "all", "none" or rectangles of squares, made into one GM-only region with a rectangle each; returns how many rectangles */
async function applyAreas(scene, areas, { name, color, flag, sceneFlag, by }) {
  const d = scene.dimensions, px = scene.grid.size, cols = Math.round(d.sceneWidth / px), rows = Math.round(d.sceneHeight / px);
  const rects = areas === "all" ? [[0, 0, cols - 1, rows - 1]] : areas === "none" ? [] : areas.map(([a, b, c, e]) => [Math.max(0, a), Math.max(0, b), Math.min(cols - 1, c), Math.min(rows - 1, e)]).filter(([a, b, c, e]) => a <= c && b <= e);
  if (rects.length) await watched(() => scene.createEmbeddedDocuments("Region", [{ name, color, visibility: CONST.REGION_VISIBILITY.GAMEMASTER, levels: [],
    shapes: rects.map(([a, b, c, e]) => ({ type: "rectangle", x: d.sceneX + a * px, y: d.sceneY + b * px, width: (c - a + 1) * px, height: (e - b + 1) * px, rotation: 0 })), flags: { [ID]: { [flag]: true } } }]));
  await watched(() => scene.setFlag(ID, sceneFlag, { by, at: Date.now(), [sceneFlag === "ground" ? "soil" : "stone"]: areas === "all" || areas === "none" ? areas : rects.length }));
  hideGroundPicture();
  return rects.length;
}
/** The trees on a map, for climbing (0.15.0): Survey Sheet's read gives each tree's square and trunk radius, and `treeTop` guesses its height from the
    trunk (Rhea, 2026-11-08: "height by size"). A map with no read has no trees to climb. */
const treesOf = read => (read?.things?.trees ?? []).filter(t => Array.isArray(t?.at)).map(t => ({ at: [...t.at], top: treeTop(t.trunk) }));
/** The tree a token is up: the one its last Climb left on its flag, while it is still off the ground and beside that tree; otherwise null (the GM
    moved it, or it came down some other way). */
function treeUp(tok, scene) {
  const f = tok.getFlag(ID, "climbing"); if (!Array.isArray(f?.at) || !(heightUp(tok) > 0)) return null;
  return treesBeside(squareOf(tok, scene), sizeOf(tok), [{ at: f.at, top: f.top }]).length ? { at: [...f.at], top: Number(f.top) || 0 } : null;
}
/** What it holds in its hands (a Climb needs both free; Rhea, 2026-11-08: by the rule): physical items carried "held" in one or two hands, with an
    id a plan can name (the slug, -2 and so on when two share it). */
function heldItems(actor) {
  const seen = new Map();
  return actor.items.filter(i => i.isOfType?.("physical") && i.system.equipped?.carryType === "held" && (Number(i.system.equipped.handsHeld) || 0) > 0).map(i => {
    const base = String(i.slug ?? i.name ?? "").toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || i.id, k = (seen.get(base) ?? 0) + 1; seen.set(base, k);
    return { id: k > 1 ? `${base}-${k}` : base, name: i.name, itemId: i.id, hands: Number(i.system.equipped.handsHeld) || 1 }; });
}
/** The weapon item a Strike is made with: a PF2e NPC's attack links its weapon by flag (PF2e 8.7.0), a character's Strike is the weapon itself. */
function weaponOf(actor, a) { const it = a?.item; if (!it) return null; if (it.type === "weapon") return it; const w = it.flags?.pf2e?.linkedWeapon; return w ? actor.items.get(w) ?? null : null; }
/** A Strike whose weapon lies on the ground: PF2e still offers an NPC's attack after its weapon is dropped, so the module leaves it out itself. */
const droppedWeapon = (actor, a) => weaponOf(actor, a)?.system?.equipped?.carryType === "dropped";
/** A Strike whose weapon it carries but doesn't hold (worn or stowed): a "draw" step comes first (0.33.2; PF2e still offers an NPC's attack with it). */
const sheathedWeapon = (actor, a) => ["worn", "stowed"].includes(weaponOf(actor, a)?.system?.equipped?.carryType);
const handsFor = item => (item?.hands === "2" || item?.system?.usage?.value === "held-in-two-hands") ? 2 : 1;
/** Why it can't act at all, or null: Paralyzed, Petrified and Unconscious creatures take no actions (and a dead one none either). */
function cantAct(actor) {
  if (actor.isDead) return "{they} {is|are} dead.";
  for (const c of ["paralyzed", "petrified", "unconscious"]) if (actor.hasCondition?.(c)) return `{they} {is|are} ${c} and can't act.`;
  return null;
}
/** Why it can't attack, or null. Rules: Restrained (Player Core) bars actions with the attack or manipulate trait except to Escape or Force Open. */
function cantAttack(actor) { return actor.hasCondition?.("restrained") ? "{they} {is|are} restrained, so {they} can't attack." : null; }
/** Why it can't use any move action (Stride, Step, Crawl, Stand, Drop Prone), or null. Rules: Immobilized bars every action with the move trait, and Grabbed and
    Restrained creatures are Immobilized. Grabbed and Restrained are named first because PF2e adds Immobilized with them, and the cause is what the reader
    needs. Prone (Stand first) and no land Speed are checkPlan's, because a Stand earlier in the plan changes the first. */
function cantMove(actor) {
  for (const c of ["restrained", "grabbed", "immobilized"]) if (actor.hasCondition?.(c)) return `{they} {is|are} ${c}, so {they} can't use move actions (Stride, Step, Crawl, Sneak, Stand or Drop Prone).`;
  return null;
}
/** The movement action a move is sent and priced with: crawl for a Crawl (a prone token can't walk); otherwise the token's own, except never crawl for a
    Stride or Step (one after a Crawl and a Stand in the same plan). */
const moveAction = (tok, kind) => kind === "crawl" ? "crawl" : kind === "fly" ? "fly" : kind === "swim" ? "swim" : kind === "burrow" ? "burrow" : ["crawl", "fly", "swim", "climb", "burrow"].includes(tok.movementAction) ? "walk" : tok.movementAction;   /* a Stride after a landing or a swim walks */
const DEEP = /deep water/i;   /* Survey Sheet's name for its greater-difficult water. Other greater difficult terrain is just 10 ft more a square. */
/** route(from, to, before, { step, kind }) for checkPlan, for this monster on this scene as it stands now: a Stride's route, or with step a single 5-ft
    square (a Step or a Crawl, which kind names for the words). */
async function mover(combat, tok, speed, known = null, flySpeed = 0, swimSpeed = 0, burrowSpeed = 0) {
  const scene = sceneOf(combat), px = scene.grid.size, d = scene.dimensions, ox = d.sceneX, oy = d.sceneY, size = sizeOf(tok);
  const { model, read } = await readMap(scene, { except: new Set(scene.tokens.map(t => t.id)) });   /* creatures are counted below, ally or enemy */
  const isDeep = deepWater(scene, model), terrain = (i, j) => { const c = model.costs[model.idx(i, j)] ?? 0; return c < 2 ? c : isDeep(i, j) ? null : 2; };
  const kind = waterKinds(isDeep, read);
  const who = new Map();
  for (const t of scene.tokens) { if (t.id === tok.id || !t.actor?.isOfType?.("creature") || (known && !known.has(t.id))) continue; const rel = t.actor.isAllyOf?.(tok.actor) ? "ally" : "enemy";
    for (const [i, j] of footprintAt(squareOf(t, scene), sizeOf(t))) if (who.get(`${i},${j}`) !== "enemy") who.set(`${i},${j}`, rel); }
  const centre = ([x, y]) => ({ x: ox + (x + size / 2) * px, y: oy + (y + size / 2) * px });
  const world = { cols: model.cols, rows: model.rows, terrain, blocked: (i, j) => !!model.blocked[model.idx(i, j)], creature: (i, j) => who.get(`${i},${j}`) ?? null,
    wall: (a, b) => !!CONFIG.Canvas.polygonBackends.move.testCollision(centre(a), centre(b), { mode: "any", type: "move" }) };
  const costFn = CONFIG.Token.movement.TerrainData.getMovementCostFunction(tok, {});
  /* squares before `from` (the turn so far) go with the token's own action, the new route with the move's own (crawl for a Crawl) */
  const measure = (squares, from = squares.length, kind = "stride") => squares.length < 2 ? 0 : tok.measureMovementPath(tok.object.createTerrainMovementPath(squares.map(([x, y], k) => ({ x: ox + x * px, y: oy + y * px, action: moveAction(tok, k >= from ? kind : "stride") }))), { cost: costFn }).cost;
  /* What it has already moved this turn: Foundry keeps the token's movement history for the turn (cleared when the turn changes) and charges a new move
     as the rest of that path, so diagonals carry on from it, as the rules say. */
  const history = (tok.movementHistory ?? []).map(w => [Math.round((w.x - ox) / px), Math.round((w.y - oy) / px)]);
  const glide = burrowSpeed > 0 && glidesThroughRock(tok.actor) ? glideBounds(scene, model) : null;   /* Earth Glide (0.17.0) */
  const soil = soilOf(scene, model, read, isDeep, glide), occupied = sq => footprintAt(sq, size).some(([i, j]) => !!who.get(`${i},${j}`));
  const route = (from, to, before = [], { step = false, kind = "stride", surface = false } = {}) => {
    const prefix = [...history]; for (const r of before) prefix.push(...(prefix.length && same(prefix.at(-1), r[0]) ? r.slice(1) : r));
    if (!prefix.length || !same(prefix.at(-1), from)) prefix.push(from);
    const fly = kind === "fly", swim = kind === "swim", dig = kind === "burrow", odd = diagonalsIn(prefix) % 2 === 1, budget = fly ? flySpeed : swim ? Math.max(swimSpeed, 20) : dig ? burrowSpeed : speed;
    if (dig && surface && occupied(to)) return { ok: false, reason: `another creature is at [${to[0]}, ${to[1]}], so {they} can't come up there.` };   /* below ground no one is in its way; where it comes up, anyone it knows of is */
    const r = step ? findStep({ from, to, size, odd }, world) : findRoute({ from, to, size, budget, odd }, fly ? flyWorld(world) : swim ? swimWorld(world, isDeep) : dig ? (glide ? glideWorld(world, isDeep, glide.hard, (a, b) => glide.wallBetween(a, b, size)) : burrowWorld(world, soil)) : world);
    if (!r.ok && (r.why !== "far" || !r.route)) return { ok: false, reason: dig && glide && r.why === "terrain" ? `[${to[0]}, ${to[1]}], or a square on the way there, is deep water, which {they} can't glide through.` : dig && glide && r.why === "blocked" ? `something {they} can't glide through (a tree, a door or a wall that isn't stone) is at [${to[0]}, ${to[1]}].` : routeWordsIt(r, to, budget, kind) };   /* "far" with no route: past where the search looked */
    /* a Swim is priced by Foundry with its swim action, which Survey Sheet's regions don't slow; a bank square it climbs out onto keeps its own terrain cost */
    const bank = swim ? Math.max(0, ...footprintAt(to, size).filter(([i, j]) => !isDeep(i, j)).map(([i, j]) => model.costs[model.idx(i, j)] ?? 0)) * FT : 0;
    return { ok: true, route: r.route, cost: measure([...prefix, ...r.route.slice(1)], prefix.length, kind) - measure(prefix) + bank };   /* checkPlan compares the cost with Speed */
  };
  /* the deep water under its footprint at a square, for checkPlan: "calm", "flowing" or null */
  route.waterAt = sq => waterUnder(sq, size, kind); route.waterIn = sq => waterUnder(sq, size, kind, true);
  route.trees = treesOf(read);   /* for a Climb: the trees beside a square */
  route.soilAt = sq => footprintAt(sq, size).every(([i, j]) => soil(i, j)); route.occupiedAt = occupied;   /* for a Burrow (0.16.0) */
  /* where a Burrow may come up: open floor, nothing solid and no deep water under its footprint (a glider may be below rock, but can't come up in it) */
  const floor = glide ? openFloor(scene, model, isDeep) : null;   /* a glider can be anywhere below, so where it comes up is checked against the open floor */
  route.surfaceAt = sq => footprintAt(sq, size).every(([i, j]) => model.inMap(i, j) && !model.blocked[model.idx(i, j)] && !isDeep(i, j) && (!floor || floor(i, j)));
  return route;
}
/** Whether a square of this scene is deep water: Survey Sheet's greater-difficult region named "Deep water" (other greater difficult terrain isn't).
    Returns a memoised (i, j) → boolean. */
function deepWater(scene, model) {
  const px = scene.grid.size, d = scene.dimensions, ox = d.sceneX, oy = d.sceneY, at = new Map();
  const deep = scene.regions.filter(r => DEEP.test(r.name ?? "") && r.behaviors.some(b => b.type === "modifyMovementCost" && !b.disabled));
  return (i, j) => { if (!model.inMap(i, j)) return false; const k = model.idx(i, j); if ((model.costs[k] ?? 0) < 2) return false;
    if (!at.has(k)) at.set(k, deep.some(r => r.testPoint({ x: ox + (i + .5) * px, y: oy + (j + .5) * px, elevation: 0 }))); return at.get(k); };
}
/** Hand a plan in. Any GM may call this; the runner checks it. meta says who made it ({ by: "chat" | "api" | "gm", model, generation, usage }); a plan
    from an older chat's generation is ignored. The plan is stored as it came and cleaned by the runner, so tries are counted in one place. */
export async function submitPlan(combat, requestId, plan, meta = {}) {
  if (requestId === LOOK_ID) return submitLook(combat, plan, meta);   /* the fight-start look (0.33.0) */
  const r = request(combat, requestId); if (!r) throw new Error("No such request.");
  /* a choice in the middle of an action (0.27.0): { choice, reason } where a plan would go; it is no plan and uses up no try */
  if ((r.choice && !r.choice.answer) || isChoice(plan)) {
    if (!r.choice || r.choice.answer) return { state: r.state, reason: "No choice is waiting on that turn." };
    if (stale(brainNow(routeOfMeta(meta)), cleanMeta(meta).generation)) return { state: r.state, ignored: true, reason: SUPERSEDED };
    const off = offRoute(combat, r, meta); if (off) return { state: r.state, ignored: true, reason: off };
    const c = cleanChoice(plan); if (!c.ok) return { state: "choice", reason: `This event asks for a choice, not a plan. ${c.reason}` };
    if (c.seq != null && c.seq !== r.choice.seq) return { state: r.state, reason: "That choice has already been answered; this one is another." };   /* an answer that arrives late never lands on the next question (review 6) */
    await save(combat, requestId, { "choice.answer": c.choice, "choice.answeredBy": "angel", "choice.reason": c.reason || null, "choice.by": whole({ ...cleanMeta(meta), at: Date.now() }) });   /* who answered, for the History's API total (0.31.0) */
    return { state: "chosen", choice: c.choice };
  }
  if (r.state !== "requested" && r.state !== "ready") throw new Error(`That turn is ${r.state}.`);
  if ((r.pos ?? 0) > 0) throw new Error("That turn is under way: its first steps are done, so a new plan can't replace them.");   /* between Next steps */
  const who = cleanMeta(meta); if (stale(brainNow(routeOfMeta(meta)), who.generation)) return { state: r.state, ignored: true, reason: SUPERSEDED };
  const off = offRoute(combat, r, meta); if (off) return { state: r.state, ignored: true, reason: off };
  if (JSON.stringify(plan ?? null).length > PLAN_BYTES) return { state: r.state, reason: "That plan is far too long to be a plan." };
  await save(combat, requestId, { plan: whole(plan), state: "submitted", verdict: null, changeVerdict: null, by: whole({ ...who, at: Date.now() }) });   /* `at` tells one plan's usage from another's (0.31.0) */   /* a new plan: an old change's refusal is about the old one */
  if (isRunner()) await judge(combat, requestId);
  for (let i = 0; i < 40; i++) { await new Promise(res => setTimeout(res, 250)); const n = request(combat, requestId); if (n.state !== "submitted") return answer(n); }
  return { state: "submitted", reason: runnerProblem() ?? `${runnerName()} hasn't answered.` };
}
/* accepted: ready, or already running or done when Auto picked it up at once */
const answer = r => ({ state: r.state, ...(["ready", "running", "done"].includes(r.state) ? { steps: forThinker(r.steps) } : { reason: r.verdict, triesLeft: Math.max(0, MAX_TRIES - (r.tries ?? 0)) }) });
/* the plan is checked once, and a turn runs once: the updateCombat hook and the submitter can both arrive here, and Auto calls doIt straight after */
const judging = new Set(), running = new Set();
export async function judge(combat, requestId) {
  if (!isRunner() || judging.has(requestId) || request(combat, requestId)?.state !== "submitted") return null;
  judging.add(requestId);
  try { return await judgeNow(combat, requestId); }
  catch (e) {   /* a throw while checking left the turn "Checking the plan" for good (0.33.1, review): it stops with the reason on the card */
    console.error(`${ID} | judge`, e);
    /* shown as a second refusal is: "Couldn't do" on the card with Play it myself (review of 0.33.1: a manual turn's note isn't on the card) */
    if (request(combat, requestId)?.state === "submitted") await save(combat, requestId, { state: "requested", tries: MAX_TRIES, steps: null, verdict: `Couldn't do: I couldn't check Angel's plan (${e.message}). Play the turn yourself.` }).catch(() => {});
    return { state: "requested", reason: `The plan couldn't be checked (${e.message}).`, triesLeft: 0 };
  }
  finally { judging.delete(requestId); }
}
async function judgeNow(combat, requestId) {
  if (!await ensureScene(combat)) { await save(combat, requestId, { state: "requested", verdict: cantOpen() }); return { state: "requested", reason: cantOpen() }; }
  const r = request(combat, requestId), clean = cleanPlan(r.plan);
  if (!clean.ok) return reject(combat, requestId, clean.reason);
  /* the ground Angel judged, when its packet asked for it (0.16.0): made real before the check, so this plan's Burrow is judged on it. Once only: a later
     plan's ground is ignored, and the GM changes the regions herself. */
  if (clean.plan.ground && r.packet?.you?.burrow?.judgeGround && !groundJudged(sceneOf(combat))) {
    try { const n = await applyGround(sceneOf(combat), clean.plan.ground); await addNote(combat, requestId, `Angel judged this map's ground: ${clean.plan.ground.soil === "all" ? "all soil" : n ? `soil in ${n} area${n === 1 ? "" : "s"}` : "all rock"} (GM-only "Soil (Angel)" regions: reshape or delete them with the region tools).`); }
    catch (e) { console.error(`${ID} | ground`, e); await addNote(combat, requestId, `I couldn't mark the ground Angel judged (${e.message}); everything counts as rock until you draw soil regions (name them "Soil").`); }
  }
  /* which walls are stone, for a monster that glides through rock (0.17.0): the same, once */
  if (clean.plan.walls && r.packet?.you?.burrow?.judgeWalls && !wallsJudged(sceneOf(combat))) {
    try { const n = await applyWalls(sceneOf(combat), clean.plan.walls); await addNote(combat, requestId, `Angel judged this map's walls: ${clean.plan.walls.stone === "all" ? "all stone" : n ? `stone in ${n} area${n === 1 ? "" : "s"}` : "none of them stone"} (a GM-only "Stone walls (Angel)" region: reshape or delete it with the region tools; doors are never stone).`); }
    catch (e) { console.error(`${ID} | walls`, e); await addNote(combat, requestId, `I couldn't mark the walls Angel judged (${e.message}); every wall stops it until you draw a region named "Stone walls".`); }
  }
  const c = checkPlan(clean.plan, await gather(combat, r, undefined, { moves: hasMove(clean.plan.steps), spells: hasSpell(clean.plan.steps) }));
  if (!c.ok) return reject(combat, requestId, c.reason);
  const tok = sceneOf(combat).tokens.get(r.tokenId);
  /* Play it myself pressed while the plan was being checked (0.33.1, review): her press stands; the plan is kept for the card */
  if (request(combat, requestId)?.state === "manual") { await save(combat, requestId, { plan: whole(clean.plan), steps: c.steps, verdict: null }); return { state: "manual", reason: "The GM took this turn over." }; }
  /* unticked while the plan was being checked, or the untick's save landed under the hand-in (0.29.1 review 1): hers, as an untick on the turn is */
  if (tok && !tok.getFlag(ID, "run") && !r.reaction) { await save(combat, requestId, { state: "manual", plan: whole(clean.plan), steps: c.steps, verdict: null }); return { state: "manual", reason: "The GM took this turn over (Angel was unticked)." }; }
  await save(combat, requestId, { state: "ready", plan: whole(clean.plan), steps: c.steps, verdict: null });
  /* 0.30.0, B-4: an untick whose echo landed after the read above and before that save was acted on by nobody (F-1's handler leaves a `submitted`
     request alone, and the read had already passed): the plan sat `ready`, Do it on the card, for a monster she had taken over. Read the tick again. */
  if (tok && !tok.getFlag(ID, "run") && !r.reaction && untouched(request(combat, requestId))) { await playMyself(combat, requestId); return { state: "manual", reason: "The GM took this turn over (Angel was unticked)." }; }
  if (tok?.getFlag(ID, "auto") && !request(combat, requestId).gmWait) (async () => { if (!(await pausedAuto(combat, requestId, tok)) && request(combat, requestId)?.state === "ready" && !request(combat, requestId).hold && !request(combat, requestId).gmWait) await doIt(combat, requestId); })().catch(e => console.error(e));   /* Auto's own start waits out the game's pause; read again after it (0.17.0 review) */
  return { state: "ready", steps: c.steps };
}
/* The reason goes back to the thinker once, as a retry event. A second refusal goes to the GM. */
async function reject(combat, requestId, reason) {
  if (request(combat, requestId)?.state === "manual") return { state: "manual", reason: "The GM took this turn over." };   /* her Play it myself stands (0.33.1, review) */
  const tries = (request(combat, requestId).tries ?? 0) + 1, last = tries >= MAX_TRIES, at = `requests.${requestId}`;
  await saveTurns(combat, { [`${at}.state`]: "requested", [`${at}.since`]: clock(), [`${at}.tries`]: tries, [`${at}.steps`]: null, [`${at}.verdict`]: last ? `Couldn't do: ${reason}` : reason, [`${at}.refused.${tries}`]: { reason, plan: cleanPlan(request(combat, requestId).plan).plan ?? null, at: Date.now(), by: request(combat, requestId).by ?? null }, ...(last ? {} : eventChange("retry", requestId, tries)) });   /* an earlier plan's steps go: they'd read as this one's */
  return { state: "requested", reason, triesLeft: Math.max(0, MAX_TRIES - tries) };
}

/* ---------- the brain: whoever thinks waits here for an event and hands plans in ---------- */
/* Events live on each Combat's flag with the rest of the fight, numbered across all fights so one cursor serves them all. Only the runner adds them.
   The listener (generation and when it last asked) is a world setting, because a chat can be waiting before any fight exists. */
/* a plan replaces the last one whole: a merge would keep keys the new one doesn't have */
const whole = v => v && typeof v === "object" ? foundry.data.operators.ForcedReplacement.create(v) : v;
const PLAN_BYTES = 8000, SUPERSEDED = "A newer chat is thinking for the monsters now, so this was ignored.";
/* the generation lives in "brain" and is written only by a hello; when the thinker last asked lives in "brainAt", which every wait renews.
   The API route (0.31.0) has its own three, so the bridge's worker and a chat never retire each other: a hello retires only its own route's
   older thinker. */
const BRAIN_KEYS = { chat: ["brain", "brainAt", "brainLaunch"], api: ["apiBrain", "apiBrainAt", "apiBrainLaunch"] };
const thinkerOf = route => route === "api" ? "api" : "chat";
const brainNow = (route = "chat") => { const [g, a, l] = BRAIN_KEYS[thinkerOf(route)]; return { generation: game.settings.get(ID, g)?.generation ?? 0, at: game.settings.get(ID, a) ?? 0, launch: game.settings.get(ID, l) ?? "" }; };
/* a plan, a choice or a giving-up counts against the generation of the route it came by */
const routeOfMeta = meta => cleanMeta(meta).by === "api" ? "api" : "chat";
/* which launch of the world this is: the server clock restarts with each, so a listening time is only good for its own (0.23.0). The same on every page. */
const launchNow = () => String(game.world?.lastPlayed ?? "");
/* the time first, the launch after: between the two a new time with an old launch reads as not listening, never the other way round */
const renewBrain = async (route = "chat") => { const [, a, l] = BRAIN_KEYS[thinkerOf(route)]; await game.settings.set(ID, a, clock()); if (game.settings.get(ID, l) !== launchNow()) await game.settings.set(ID, l, launchNow()); };
const fights = () => game.combats.filter(c => c.started);
const eventsOf = combat => Object.values(turns(combat).events ?? {}).map(e => ({ ...e, combatId: combat.id }));
function eventChange(kind, requestId, tries, extra = {}) {
  const seq = nextSeq(Math.max(0, ...game.combats.contents.flatMap(c => Object.keys(turns(c).events ?? {}).map(Number))), Date.now());
  return { [`events.${seq}`]: { seq, kind, requestId, tries, ...extra } };
}
/** A turn Auto finished but never ended: its END_MS timer lived on a page that reloaded in between (found in the second measured run, 2026-11-08).
    The runner's 10 s check ends it, as endAfter would have. Only the current creature's latest request, done, Auto still ticked. */
function endLeftOver(combat) {
  if (!combat.started || !combat.combatant) return;
  const [id, r] = Object.entries(turns(combat).requests ?? {}).filter(([, x]) => !x.reaction && x.combatantId === combat.combatant.id && x.round === combat.round).sort((a, b) => (b[1].at ?? 0) - (a[1].at ?? 0))[0] ?? [];
  /* never a delayed request (the monster is back for a new turn), and never one whose last step left a card for the GM to apply (Rhea: Auto ends a turn
     after its last action, never after a card the GM must apply; found by the 0.12.0 review) */
  if (r?.state === "done" && r.autoEnd && !r.delayed && !r.gmEnded && Number.isFinite(r.since) && clock() - r.since > END_MS + 3000) endAfter(combat, id);
}
/** The stall check, on the runner every 10 s (Rhea, 2026-11-08): a turn that has sat past its limit (brain.mjs's stallOf) is marked on its request,
    which turns the GM's card amber, and Angel gets a "stall" event to look into it. Card only, no chat (her rule: no whispered cards). Anything the
    turn does next moves `since` on, which clears the mark. */
let stallTimer = null;
export function watchStalls() { clearInterval(stallTimer); stallTimer = setInterval(() => { if (isRunner()) checkStalls().catch(e => console.warn(`${ID} | stalls`, e)); }, 10000); }
async function checkStalls() {
  for (const combat of fights()) {
    await lookCheck(combat).catch(e => console.warn(`${ID} | look`, e));   /* started here too, for a runner that was away at the fight's start (0.33.1, review), and dropped once round 1 is over (R4-1) */   /* a look still waiting when round 1 is over is dropped (R4-1), even with no turn change seen here */
    const r = currentRequest(combat);
    if (!r) { endLeftOver(combat); continue; }
    if (!Number.isFinite(r.since)) { await saveTurns(combat, { [`requests.${r.id}.since`]: clock() }); continue; }   /* a request from before 0.9.0 */
    const tok = sceneOf(combat)?.tokens.get(r.tokenId), s = stallOf(r, { now: clock(), auto: !!tok?.getFlag(ID, "auto"), machineMs: Math.max(60000, autoPause() * 1000 + 30000) });   /* a long Auto pause isn't a stall */
    if (!s || r.stall?.since === s.since) continue;
    await saveTurns(combat, { [`requests.${r.id}.stall`]: whole(s), ...eventChange("stall", r.id, r.tries ?? 0, { since: s.since }) });
  }
}
/** The first event after the cursor that is this thinker's (0.31.0): still live, for a turn that is still the fight's own (a turn the GM skipped past
    is never planned: it cost a wait each, and on the API money, seen live 2026-11-11), and offered to this route by the fight's route and who is
    listening (`whoGets`: API, then a listening chat, then the GM). Each goes out with the model the monster is thought for by (`modelOf`). */
function firstEvent(cursor, thinker = "chat") {
  const reqOf = e => request(game.combats.get(e.combatId), e.requestId), api = brainListening("api"), chat = brainListening("chat"), now = clock();
  const mine = e => { const c = game.combats.get(e.combatId), r = reqOf(e); if (!c || !live(e, r)) return false;
    if (["turn", "retry", "replan"].includes(e.kind) && !r.reaction && currentRequest(c)?.id !== e.requestId) return false;
    return whoGets({ route: fightRoute(c), kind: e.kind, api, chat, handedOff: !!r.handedOff, held: r.thinker ?? null, now }) === thinker; };
  /* the fight-start look (0.33.0) comes after every waiting turn, and to each thinker once (`lookEvent`), not by the cursor */
  const ev = pickEvent(fights().flatMap(eventsOf).filter(e => e.kind !== "look"), cursor, mine); if (!ev) return lookEvent(thinker, api, chat, now);
  const c = game.combats.get(ev.combatId), r = reqOf(ev), tok = sceneOf(c)?.tokens.get(r.tokenId), m = tok ? modelOf(tok, c) : null, model = m ? { model: m.model, modelWhy: m.why || null } : {};
  if (ev.kind === "choice") return { ...choiceOut(ev, r, packetFor(c, ev.requestId)), ...model };
  return { ...eventOut(ev, r), ...model };
}
/** A fight's route (0.31.0): its own, else the setting for new fights. */
export const fightRoute = combat => routeOf(combat?.getFlag(ID, "route"), game.settings.get(ID, "defaultRoute"));
/** Her "Thinks by" list on Monster Turns. Any GM. */
export async function setRoute(combat, route) { if (!game.user.isGM) throw new Error("Only a GM can do this."); if (!["api", "chat", "off"].includes(route)) throw new Error(`A route is api, chat or off, not ${route}.`); await combat.setFlag(ID, "route", route); return fightRoute(combat); }
/** Why a thinker's plan for this request no longer counts, or null: the fight moved to another route while it thought, or the API handed the
    turn on. A GM's own hand-in (no generation) always counts. */
function offRoute(combat, r, meta) {
  const m = cleanMeta(meta); if (m.generation == null || m.by === "gm") return null;
  const route = fightRoute(combat);
  if (route === "off") return "Angel is off for this fight, so this was ignored.";
  if (m.by === "api" && route !== "api") return "This fight isn't on the API route any more, so this was ignored.";
  if (m.by === "api" && r.handedOff) return "The API handed this turn on to the chat, so this was ignored.";
  /* the turn was given to the other thinker (0.31.0 review 1): its plan is the one that counts, so a second never replaces it */
  const mine = m.by === "api" ? "api" : "chat";
  if (r.thinker?.who && r.thinker.who !== mine) return `This turn went to ${r.thinker.who === "api" ? "the API" : "the chat"}, so this was ignored.`;
  return null;
}
/** Which model thinks for a monster, and why (`route.mjs` modelFor): her pick on the token, else Opus for a band leader (whoever leads now) or a
    spellcaster two or more levels above the party, else Sonnet. The party's level is the encounter's brief's, else the sheets'. */
export function modelOf(tok, combat = null) {
  const scene = tok?.parent, actor = tok?.actor; if (!actor) return modelFor({});
  const band = scene ? bandOf(scene, tok) : null, leads = !!band && leaderOf(scene, band, combat)?.tok?.id === tok.id;
  const casts = (actor.spellcasting?.regular ?? []).some(e => !e.isRitual && CASTERS.includes(e.category) && (e.spells?.size ?? 0) > 0);
  /* the party's level: the brief's, else the sheets' most common; unknown (no party found) means the rule can't call anyone 2+ above (review 12) */
  const pl = scene?.getFlag(ID, "brief")?.partyLevel, partyLevel = Number.isFinite(pl) ? pl : partyLevels().length ? suggestedLevel() : null;
  const pick = tok.getFlag(ID, "modelPick");
  const m = modelFor({ pick: pick === "opus" || pick === "sonnet" ? pick : null, leads, casts, level: Number.isFinite(actor.level) ? actor.level : null, partyLevel });
  return m.why ? { ...m, why: pro(m.why, P(tok, combat)) } : m;   /* "leads {their} band": its own pronoun (0.32.0, 0.31.0's known gap) */
}
/** Her tick on Monster Minds: "opus", "sonnet", or null to follow the rule again. On each token given. Any GM. */
export async function setModelPick(scene, tokenIds, pick) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const v = pick === "opus" || pick === "sonnet" ? pick : null;
  const updates = tokenIds.map(id => scene.tokens.get(id)).filter(Boolean).map(t => ({ _id: t.id, [`flags.${ID}.${v ? "modelPick" : "-=modelPick"}`]: v }));
  if (updates.length) await scene.updateEmbeddedDocuments("Token", updates);
  return updates.length;
}
/** The packet a choice goes out with: the request's own, or (a monster's reaction has none) the one from that monster's latest turn. */
function packetFor(combat, id) {
  const r = request(combat, id); if (r?.packet) return r.packet;
  return Object.values(turns(combat).requests ?? {}).filter(x => x?.tokenId === r?.tokenId && x.packet).sort((a, b) => (b.at ?? 0) - (a.at ?? 0))[0]?.packet ?? null;
}
/** Wait for something to think about. With no generation this is a new thinker: it gets `hello` (the prompt, the schemas, its generation) at once and
    any older thinker is retired. Otherwise it returns the first event after `cursor` whose request still waits, holding up to maxSeconds (at most 100)
    for one; { idle: true } if none came. The cursor only moves when the caller asks again with the one it was given, so a dropped call loses nothing. */
export async function waitForEvent(cursor = 0, maxSeconds = 90, { generation = null, route = "chat" } = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  cursor = Number.isFinite(cursor) ? cursor : 0;
  const who = thinkerOf(route);   /* the bridge's API worker waits with route "api" (0.31.0); a chat with none */
  if (generation == null) { const g = (brainNow(who).generation ?? 0) + 1; await game.settings.set(ID, BRAIN_KEYS[who][0], { generation: g, at: 0 }); await renewBrain(who);
    if (who === "api" && game.settings.get(ID, "apiNote")?.state) await game.settings.set(ID, "apiNote", {});   /* listening again: the old note is gone */
    return { cursor, hello: { ...hello(g), route: who } }; }
  if (stale(brainNow(who), generation)) return { cursor, superseded: true, reason: SUPERSEDED };
  await renewBrain(who);
  let got = firstEvent(cursor, who);
  if (!got) got = await new Promise(res => {
    let hook = null, timer = null;
    const done = v => { Hooks.off("updateCombat", hook); clearTimeout(timer); res(v); };
    hook = Hooks.on("updateCombat", () => { const e = firstEvent(cursor, who); if (e) done(e); });
    timer = setTimeout(() => done(null), waitSeconds(maxSeconds) * 1000);
  });
  if (stale(brainNow(who), generation)) return { cursor, superseded: true, reason: SUPERSEDED };
  /* the turn is this thinker's now (0.31.0 review 1): stamped on its request, so the other thinker isn't given it too, and the light renewed,
     since thinking can outlast it */
  if (got && got.kind !== "stall") { const c = game.combats.get(got.combatId), look = got.kind === "look";
    if (c) await saveTurns(c, look ? { "look.thinker": whole({ who, at: clock(), generation }) } : { [`requests.${got.requestId}.thinker`]: whole({ who, at: clock() }) }).catch(e => console.warn(`${ID} | thinker`, e)); await renewBrain(who); }
  /* a look keeps the cursor where it was: its number is older than turns already handed out, which must not come again */
  return got ? { cursor: got.kind === "look" ? cursor : got.seq, event: got } : { cursor, idle: true };
}
/** Foundry's server clock: the same in every browser, so the light means the same on Rhea's computer as on the server PC. */
export const clock = () => game.time.serverTime;
/** Is the thinker there? For the Monster Turns window. */
export const brainListening = (route = "chat") => listening(brainNow(route), clock(), launchNow()) && !(thinkerOf(route) === "api" && apiStopped());
/* the worker wrote that it stopped after it last listened (0.31.0): its light is off from that moment, so the next turn falls back at once */
const apiStopped = () => { const n = game.settings.get(ID, "apiNote"); return (n?.state === "stopped" || n?.state === "capped") && (n.launch ?? "") === launchNow() && (n.at ?? 0) >= (game.settings.get(ID, "apiBrainAt") ?? 0); };
export const brainSeenAt = (route = "chat") => brainNow(route).at ?? 0;
/** For the bridge's API worker (0.31.0), a read that writes nothing: is a fight on the API route, and Wake Angel's latest press. */
export function apiWanted() {
  return { ok: game.user.isGM, want: fights().some(c => fightRoute(c) === "api"), wake: game.settings.get(ID, "apiWake") ?? {}, launch: launchNow(), listening: brainListening("api"), generation: brainNow("api").generation ?? 0 };
}
/** The worker's note for the card: why it stopped ("stopped", "capped"), that it has no key ("no-key"), or {} to clear. */
export async function setApiNote(note = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const n = note && typeof note === "object" && ["stopped", "capped", "no-key"].includes(note.state) ? { state: note.state, reason: text(note.reason, 200) || null, at: clock(), launch: launchNow() } : {};
  /* a worker that stops is no longer listening: `brainListening("api")` reads this note, so its light goes off at once and the next turn falls
     back to a chat or the GM instead of waiting two minutes for the light to fade */
  await game.settings.set(ID, "apiNote", n); return n;
}
/** The worker's note in words for the card, when it was written in this launch of the world (an older one is about a bridge that has restarted since). */
export const apiNoteNow = () => { const n = game.settings.get(ID, "apiNote"); return n?.state && (n.launch ?? "") === launchNow() ? apiNoteWords(n) : ""; };
/** Where Wake Angel's latest press stands for the card: "waking" (under 20 s, no light yet), "silent" (nothing answered), or null. */
export const apiWakeNow = () => { const b = brainNow("api"); return wakeState(game.settings.get(ID, "apiWake"), { now: clock(), launch: launchNow(), api: brainListening("api"), seenAt: (b.launch ?? "") === launchNow() ? b.at ?? 0 : 0 }); };
/** Wake Angel on the card: a press the bridge's worker sees at its next look (every few seconds). On a turn the API handed on it also gives
    that turn back to the API, with a fresh event (0.31.0 review 5): otherwise a woken API would never see it. */
export async function wakeAngel(combat = null, requestId = null) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = combat && requestId ? request(combat, requestId) : null;
  if (r?.handedOff && r.state === "requested" && !r.gaveUp) await saveTurns(combat, { [`requests.${requestId}.handedOff`]: null, [`requests.${requestId}.thinker`]: null, ...eventChange((r.tries ?? 0) > 0 ? "retry" : r.why ? "replan" : "turn", requestId, r.tries ?? 0) });
  const w = game.settings.get(ID, "apiWake") ?? {}; const n = { n: (w.n ?? 0) + 1, at: clock(), launch: launchNow() }; await game.settings.set(ID, "apiWake", n); return n;
}
/** The worker is thinking (0.31.0 review 1): its light kept on while an answer takes long, for its own generation only. */
export async function apiAlive(generation) { if (!game.user.isGM) throw new Error("Only a GM can do this."); if (stale(brainNow("api"), generation)) return { ok: false, superseded: true }; await renewBrain("api"); return { ok: true }; }
/** What one API answer cost, kept on the fight whether its plan landed or not (0.31.0 review 8): the History's total reads these. */
export async function apiSpend(combat, use = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const num = v => Number.isFinite(v) && v >= 0 ? v : null;
  await saveTurns(combat, { [`apiUse.${Date.now().toString(36)}${foundry.utils.randomID(4)}`]: { model: text(use.model, 60) || null, cost: num(use.cost), in: num(use.in), out: num(use.out), seconds: num(use.seconds), requestId: text(use.requestId, 40) || null, at: Date.now() } });
  return true;
}
/** A fight started with no route of its own takes the setting's now, so changing the setting later moves only fights not yet begun (review 10). */
export async function fixRoute(combat) { if (!game.user.isGM || !combat || combat.getFlag(ID, "route")) return; await combat.setFlag(ID, "route", routeOf(null, game.settings.get(ID, "defaultRoute"))); }
/** Legality only: what the runner would say, with nothing written. Needs the fight open on this page. */
export async function checkOnly(combat, requestId, plan) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  if (requestId === LOOK_ID) { const c = cleanLook(plan, Object.keys(lookOf(combat)?.monsters ?? {}), lookKinds(lookOf(combat))); return c.ok ? { ok: true, suggestions: c.items.length } : c; }
  const r = request(combat, requestId); if (!r) throw new Error("No such request.");
  if (isChoice(plan)) { const c = cleanChoice(plan); return c.ok ? { ok: true, choice: c.choice } : c; }
  if (!onFightScene(combat)) throw new Error("This page doesn't have the fight's map open, so it can't tell.");
  const clean = cleanPlan(plan); if (!clean.ok) return { ok: false, reason: clean.reason };
  const c = checkPlan(clean.plan, await gather(combat, r, undefined, { moves: hasMove(clean.plan.steps), spells: hasSpell(clean.plan.steps) }));
  return c.ok ? { ...c, steps: forThinker(c.steps) } : c;
}
/** The thinker can't make a plan: the card says so and the GM plays. */
export async function reportFailure(combat, requestId, reason, meta = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  if (requestId === LOOK_ID) { const l = lookOf(combat); if (l?.state !== "asked") return { state: l?.state ?? "none", reason: "No fight-start look is waiting." };
    if (stale(brainNow(routeOfMeta(meta)), cleanMeta(meta).generation)) return { ignored: true, reason: SUPERSEDED };
    const off = offLook(combat, l, meta); if (off) return { ignored: true, reason: off };
    await saveTurns(combat, { "look.state": "failed", "look.reason": `Angel couldn't make it: ${text(reason, 160) || "no reason given"}` }); return { state: "failed", gaveUp: true }; }
  const r = request(combat, requestId); if (!r) throw new Error("No such request.");
  if (r.choice && !r.choice.answer) { if (stale(brainNow(routeOfMeta(meta)), cleanMeta(meta).generation)) return { ignored: true, reason: SUPERSEDED }; await save(combat, requestId, { "choice.gaveUp": true }); return { state: r.state, gaveUp: true }; }   /* the GM chooses on her card */
  if (r.state !== "requested") throw new Error(`That turn is ${r.state}.`);
  if (stale(brainNow(routeOfMeta(meta)), cleanMeta(meta).generation)) return { ignored: true, reason: SUPERSEDED };
  await save(combat, requestId, { gaveUp: true, verdict: `Angel couldn't plan this turn: ${text(reason, 200) || "no reason given"}. Play it yourself.` });
  return { state: "requested", gaveUp: true };
}
/** The API couldn't plan this turn (0.31.0): it falls back to a listening chat, then to the GM, as agreed. The card says why. A fresh event goes out,
    so a chat whose cursor is already past the turn's first event still gets it. Only the API route hands a turn on. */
export async function handOff(combat, requestId, reason, meta = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId); if (!r && requestId !== LOOK_ID) throw new Error("No such request.");
  const who = cleanMeta(meta); if (who.by !== "api") throw new Error("Only the API route hands a turn on.");
  if (stale(brainNow("api"), who.generation)) return { ignored: true, reason: SUPERSEDED };
  /* the look (0.33.0): to a listening chat, as a turn is; with none it waits until round 1 ends (R4-1) */
  if (requestId === LOOK_ID) { const l = lookOf(combat); if (l?.state !== "asked") return { state: l?.state ?? "none", reason: "No fight-start look is waiting." };
    await saveTurns(combat, { "look.handedOff": { reason: text(reason, 200) || "no reason given", at: clock() }, "look.thinker": null }); return { state: "asked", handedOff: true }; }
  const open = !!r.choice && !r.choice.answer && !r.choice.gaveUp;
  if (!open && r.state !== "requested") return { state: r.state, reason: `That turn is ${r.state}.` };
  const ev = open ? eventChange("choice", requestId, r.tries ?? 0, { choiceSeq: r.choice.seq }) : eventChange((r.tries ?? 0) > 0 ? "retry" : r.why ? "replan" : "turn", requestId, r.tries ?? 0);
  await saveTurns(combat, { [`requests.${requestId}.handedOff`]: { reason: text(reason, 200) || "no reason given", at: clock() }, [`requests.${requestId}.thinker`]: null, ...ev });
  return { state: r.state, handedOff: true };
}
/** A short read of where a fight stands, for whoever thinks. */
export function fightState(combat = game.combat) {
  if (!combat) return { fight: false };
  const r = currentRequest(combat);
  return { combatId: combat.id, started: combat.started, round: combat.round, route: fightRoute(combat), listening: brainListening(), apiListening: brainListening("api"), generation: brainNow().generation ?? 0,
    request: r ? { id: r.id, state: r.state, monster: r.packet?.you?.label ?? null, verdict: r.verdict ?? null, triesLeft: Math.max(0, MAX_TRIES - (r.tries ?? 0)), gaveUp: !!r.gaveUp } : null };
}

/* ---------- carrying it out ---------- */
/* Workbench's own auto-damage would open the damage dialog and roll in its own time, so a card this module makes opts out, with Workbench's own
   flag. It only ever fires on the card's author's browser, and this module always rolls the damage itself: one roller, one card. */
let pending = null;
export function onPreCreateMessage(message) { if (pending && message.speaker?.token === pending.tokenId && (pending.all || message.flags?.pf2e?.context?.type === "attack-roll")) message.updateSource({ [`flags.${WORKBENCH}.noAutoDamageRoll`]: true }); }   /* a spell's cards all opt out: its cast card too, which Workbench reads for save spells */
/* PF2e gives a spell's cast card the context type "spell-cast" only when the spell has a check, damage or save; one without (Mist, found live 2026-11-07)
   has PF2e's casting flag and no context, so that counts as the cast card too */
export function onCreateMessage(message) { if (!pending || message.author?.id !== game.user.id || message.speaker?.token !== pending.tokenId) return; const type = message.flags?.pf2e?.context?.type ?? (message.flags?.pf2e?.casting ? "spell-cast" : undefined); (pending.waiters.get(type) ?? pending.waiters.get("*"))?.(message, type); }
/* a waiter's timer removes only its own waiter: a stage that ended early (no roll) mustn't take the next stage's (found by the 0.9.0 review) */
const waitFor = type => { const box = pending; let own; const p = new Promise((res, rej) => { const t = setTimeout(() => { if (box?.waiters.get(type) === own) box.waiters.delete(type); rej(new Error(`No ${type} card came.`)); }, STEP_MS); own = m => { clearTimeout(t); if (box.waiters.get(type) === own) box.waiters.delete(type); res(m); }; box.waiters.set(type, own); }); p.catch(() => {}); return p; };
/* the first of several card types: a spell attack's card type isn't pinned down, so take the first attack card that comes */
const waitForAny = types => { const box = pending; let own; const p = new Promise((res, rej) => { const t = setTimeout(() => { if (box?.waiters.get("*") === own) box.waiters.delete("*"); rej(new Error(`No ${types.join(" or ")} card came.`)); }, STEP_MS); own = (m, type) => { if (!types.includes(type)) return; clearTimeout(t); if (box.waiters.get("*") === own) box.waiters.delete("*"); res(m); }; box.waiters.set("*", own); }); p.catch(() => {}); return p; };
const clickWith = key => new MouseEvent("click", { shiftKey: !!game.user.settings?.[key] });   /* PF2e flips the dialog on Shift */
/* Nobody can click a window on the runner's page, and a roll waits for its dialog for ever. So a stage gets a time limit, and a dialog ends it at once:
   closing it lets the roll give up, and the record says the stage may not have finished, so it goes to Rhea and nothing is repeated. */
const openWindows = () => [...foundry.applications.instances.values(), ...Object.values(ui.windows)];
const isPrompt = a => a instanceof foundry.applications.api.DialogV2 || /dialog|prompt/i.test(a.constructor?.name ?? "");
async function watched(work) {
  const before = new Set(openWindows()), fresh = () => openWindows().filter(a => !before.has(a));
  let poll, timer;
  const stop = new Promise((_, rej) => {
    poll = setInterval(() => { const p = fresh().find(isPrompt); if (p) rej(new Error(`The window "${p.title ?? p.constructor.name}" opened on ${game.user.name}'s page, where nobody can click it.`)); }, 250);
    timer = setTimeout(() => rej(new Error(`This took over ${STEP_MS / 1000} seconds.`)), STEP_MS);
  });
  try { return await Promise.race([work(), stop]); }
  catch (e) { for (const a of fresh()) await a.close?.().catch?.(() => {}); throw e; }
  finally { clearInterval(poll); clearTimeout(timer); }
}
/* Real targets, on the runner's own account: hers are never touched. Workbench's "Please target" and Toolbelt's Target Helper rows both read them. */
const aimAt = target => target.object?.setTarget(true, { user: game.user, releaseOthers: true, groupSelection: false });
/* With automatic damage on, a damage card's buttons can only apply a second time, and Block comes too late (the reaction pop-up is its proper route). So the
   card is marked, which hides PF2e's buttons from players, and Target Helper's row is taken off. That's done after the card is made, because Toolbelt fills
   the row in a preCreate hook that runs after this module's. If Toolbelt renames its flag the row simply stays. */
async function markApplied(message) {
  const change = { [`flags.${ID}.autoApplied`]: true }; if (message.flags?.[TOOLBELT]?.targetHelper) change[`flags.${TOOLBELT}.targetHelper`] = foundry.data.operators.ForcedDeletion.create();
  await message.update(change).catch(e => console.warn(`${ID} | card`, e));
}
/** Drawing a marked card for a player. It changes only what this browser shows, so if PF2e changes its markup the buttons just show again. */
export function onRenderMessage(message, html) { if (game.user.isGM || !message.getFlag(ID, "autoApplied")) return; for (const el of html.querySelectorAll?.(".damage-application") ?? []) el.remove(); }
const stopAiming = () => { if (game.user.targets.size) canvas.tokens?.setTargets?.([], { mode: "replace" }); };

async function runStrike(combat, id, i, step, tok, target) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {};
  const strike = strikesWithIds(tok.actor).find(x => x.id === step.item)?.strike; if (!strike) throw new Error(`${tok.name} has no ${step.itemName} now.`);
  /* no shot left: before anything is rolled (a flat check first would be a free reroll on the re-plan; found by the 0.9.0 review) */
  const ammo = await ammoOf(tok.actor, strike).catch(() => null), own = !!ammo?.stack;
  if (ammo && !ammo.unreadable && !Object.keys(get()).length && (shotsFor(combat, tok, step.item, ammo) ?? 1) < 1) return "noShot";   /* unreadable: Ranged Combat counts the shot, the card says so (0.33.1, review: null < 1 refused every shot) */
  for (let guard = 0; guard < 8; guard++) {
    const now = nextAction(get(), { apply: applySetting(), flat: step.flat ?? 0 });
    if (now === "next") return "next";
    if (now === "ask") return "ask";
    if (!stepGate(now, id)) return "stopped";
    if (now !== "apply" && !(await ensureScene(combat) && tok.object && target.object)) throw new Error(cantOpen());   /* applying needs no canvas */
    pending = { tokenId: tok.id, waiters: new Map() };
    try {
      if (now === "flat") {
        await record({ flatStarted: true });
        const roll = await watched(async () => { const r = await new Roll("1d20").evaluate(); await r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Flat check, DC ${step.flat}` }); return r; });
        await record({ flat: { dc: step.flat, total: roll.total, ok: roll.total >= step.flat } });
        if (roll.total < step.flat) await save(combat, id, { note: `${step.itemName} at ${step.targetName} failed its DC ${step.flat} flat check (${roll.total}). The action is spent.` });
      } else if (now === "attack") {
        aimAt(target); await record({ started: true });
        /* its "no valid ammunition" window, or no roll: nothing was rolled. After a flat check the action is spent (no free reroll), otherwise asked again with it unspent */
        const refused = async () => { await record({ started: false }); return get().flat ? "noShotSpent" : "noShot"; };
        let shot;
        try { shot = await watched(async () => { const card = waitFor("attack-roll"), roll = await strike.variants[step.variant].roll({ event: clickWith("showCheckDialogs"), target: target.object, ...(own ? { options: ["skip-post-processing"] } : {}) }); if (!roll) return { roll: null }; return { message: await card, roll }; }); }
        catch (e) { if (ammo && /ranged combat/i.test(e.message)) return refused(); throw e; }
        if (!shot.roll) { if (ammo) return refused(); throw new Error(`${step.itemName} didn't roll.`); }
        const { message, roll } = shot, left = own ? await takeAmmo(tok.actor, ammo) : null;
        if (ammo?.unreadable) await addNote(combat, id, `I couldn't read Ranged Combat's ammunition for ${tok.name}, so Ranged Combat took this shot's ammunition itself (on version 8.0.7 that is 2 for a monster).`);
        /* Nimble Dodge used before the roll (0.20.0): +2 circumstance to AC against this attack, over what circumstance bonus it already had (they don't
           stack); read against the attack's own DC, and recorded in the same save as the attack (review findings 5 and 17) */
        const base = roll?.degreeOfSuccess ?? message.rolls?.[0]?.degreeOfSuccess ?? 0, raised = acRaised(combat, id, i, target), bonus = raised.bonus, check = message.rolls?.[0] ?? roll;
        const add = bonus ? acAdds(bonus, Math.max(circNow(target.actor), coverInDc(message.flags?.pf2e?.context?.options))) : 0, dc = add ? (message.flags?.pf2e?.context?.dc?.value ?? target.actor.armorClass?.value ?? 0) + add : null, degree = add && check ? degreeAgainst(check.total, check.dice?.[0]?.total, dc) : base;
        await record({ attack: { message: message.id, degree, ...(degree !== base ? { was: base, against: dc } : {}), ...(left != null ? { ammoLeft: left } : {}) } });
        if (degree !== base) await addNote(combat, id, `${raised.by}: against AC ${dc} ${step.itemName}'s ${OUTCOMES[base] ?? "result"} becomes a ${OUTCOMES[degree] ?? "different result"}.`);
        if (base >= 2 && degree < 2) await sayToAll(target, missWords(target.name, raised.by));   /* every reduction says why (Rhea, 2026-11-11) */
        /* Interposing Earth's barrier outlives a miss: since 0.35.0 it stands on the map as a wall with its picture (Rhea, q-36) */
        if (raised.earth && degree < 2) await raiseBarrier(combat, id, i, target, tok, raised.earth.spell?.rank).catch(e => { console.error(`${ID} | barrier`, e); return addNote(combat, id, `${target.name}'s earth barrier should stand between ${target.name} and ${tok.name} for 3 rounds, but I couldn't put it on the map (${e.message}): yours to rule on.`); });
      } else if (now === "damage") {
        let hr; try { hr = await hitGate(combat, id, i, step, tok, target, { melee: !strike.item?.isRanged, damageTypes: damageTypesOf(strike) }, get); } catch (e) { console.error(`${ID} | reactions`, e); hr = null; await addNote(combat, id, `I couldn't ask the reactions to ${step.itemName}'s hit (${e.message}); damage went ahead.`); }   /* Shield Block, Reactive Shield (0.20.0) */
        if (hr === "manual") return "next"; if (hr === "held" || hr === "gone") return hr; if (hr === "missed") continue;
        const degree = get().attack.degree; aimAt(target); await record({ damageStarted: true });
        const message = await watched(async () => { const card = waitFor("damage-roll"); await strike[degree === 3 ? "critical" : "damage"]({ event: clickWith("showDamageDialogs"), target: target.object, mapIncreases: step.variant }); return card; });
        await record({ damage: { message: message.id } });
        if (applySetting()) await markApplied(message);
        else { const hb = await harmByHand(combat, id, i, tok, [{ target, hit: Math.floor(message.rolls?.[0]?.total ?? 0), block: !!get().shieldBlock }]); if (hb === "manual") return "next"; if (hb === "held" || hb === "gone") return hb; }
      } else if (now === "apply") {
        const message = game.messages.get(get().damage.message), roll = message?.rolls?.[0]; if (!roll) return "ask";
        /* the party's reactions to the damage (0.27.0): Glimpse of Redemption, before anything is applied */
        const hit = Math.floor(roll.total), hg = await harmGate(combat, id, i, tok, [{ target, hit }]);
        if (hg === "manual") return "next"; if (hg === "held" || hg === "gone") return hg;
        const hm = harmFor(combat, id, i, target, hit);
        await record({ applying: true }); const was = hpNow(target);
        if (!hm.repent) await watched(() => applyFromCard(message, roll, target, 1, !!get().shieldBlock, hm));
        await record({ applied: true, hp: [was, hpNow(target)] });
        await afterHarm(combat, id, i, tok, target, { hit, was, block: !!get().shieldBlock });
        /* undo restores HP but not what Workbench and PF2e did at 0 HP (seen in test D1) */
        if (target.actor?.isOfType?.("character") && target.actor.hitPoints?.value === 0) await save(combat, id, { note: `${target.name} is at 0 HP. If you undo this, PF2e restores the HP but you still need to remove Wounded and Prone and put their initiative back.` });
      }
    } finally { pending = null; }
  }
  return "ask";
}
/** A Stride, a Step or a Crawl, along the route the check found (a Step's or Crawl's is its one square), with the action the token moves by: its own for
    a Stride or Step, crawl for a Crawl (a prone token can't walk). Foundry's crawl action books each square at double (core's costMultiplier 2, tested
    2026-11-07), so a Crawl's charged cost reads 10 ft; the rules distance, which checkPlan uses, is 5 ft. Never sent twice: a move begun before a reload
    counts as done only if the monster is where it was going. Afterwards the monster's own square in `seen` moves with it, so the look before the next
    action doesn't take its own Stride for a change; anything else (an HP change from a reaction, someone now out of sight) still counts. */
async function runStride(combat, id, i, step, tok) {
  const scene = sceneOf(combat), record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {};
  /* the step's record, the baseline's square and any note go in one save: a reload between two saves would leave the step done with the old square,
     and the look before the next action would re-plan for its own move */
  const fly = step.do === "fly", dig = step.do === "burrow", up = () => heightUp(tok);
  const finish = async rec => { const at = squareOf(tok, scene), change = { log: { [i]: fly ? { ...rec, ...(rec.moved ? { moved: { ...rec.moved, elev: up() } } : {}) } : dig && rec.moved ? { ...rec, moved: { ...rec.moved, below: isBelow(tok) } } : rec } };
    if (request(combat, id).seen) change.seen = { me: { square: at } };   /* no baseline, nothing to move */
    /* gone under the ground: everyone vanishing from its senses is its own doing, so the baseline starts again from there (no re-plan for it). Coming up,
       what it perceives anew is news, and the look before the next action asks again if it changed (0.16.0). */
    if (dig && isBelow(tok) && !step.fromBelow && request(combat, id).seen) change.seen = whole(situationNow(combat, tok, request(combat, id).labels ?? {}));
    if (dig && isBelow(tok) !== !!step.below) change.note = `${tok.name} is ${isBelow(tok) ? "still below ground" : "at the surface"} instead of ${step.below ? "below ground" : "at the surface"}.`;
    if (!same(at, step.to)) change.note = `${tok.name} stopped at square ${at[0]}, ${at[1]} instead of ${step.to[0]}, ${step.to[1]}.`;
    else if (fly && up() !== step.height) change.note = `${tok.name} is ${up()} ft up instead of ${step.height} ft.`;
    await save(combat, id, change); };
  const now = nextMove(get(), squareOf(tok, scene), step.to, fly ? up() : dig ? isBelow(tok) : null, fly ? step.height : dig ? !!step.below : null);
  if (now === "next") return "next";
  if (step.inPlace && same(squareOf(tok, scene), step.to)) { await finish({ moved: { to: [...step.to], cost: 0 } }); return "next"; }   /* a flee from the edge it stands on (0.33.2): nothing to move */
  if (now === "arrived") { if (dig && tok.getFlag(ID, "burrowed") && !isBelow(tok)) await setBelow(tok, false); await finish({ moved: { to: squareOf(tok, scene), cost: null } }); return "next"; }   /* a reload after it came up and before it was shown: show it now (0.16.0 review) */
  if (now === "ask") { await save(combat, id, { note: `${tok.name} started a ${WORD[step.do] ?? "Stride"} and isn't where {they} {was|were} going.` }); return "ask"; }
  if (!stepGate(step.do, id)) return "stopped";
  if (!(await ensureScene(combat) && tok.object)) throw new Error(cantOpen());
  /* a Swim in flowing water without a swim Speed: PF2e's own Swim (an Athletics check, its card in chat) at the step's DC, rolled once (a reload
     keeps the result); below a success it makes no progress, and the turn goes on to the look before the next step, which asks again */
  if (step.do === "swim" && step.dc) {
    let rolled = get().swim;
    if (!rolled) {
      /* marked before the roll, so a reload between its card and its record asks the GM instead of rolling again (as a follow-up check does) */
      if (get().swimStarted) { await addNote(combat, id, `${tok.name}'s Swim check may already be in chat: check its card, then move {them} or press Next step.`); return "ask"; }
      await record({ swimStarted: true });
      const res = await watched(() => game.pf2e.actions.get("swim").use({ actors: [tok.actor], difficultyClass: { value: step.dc }, event: clickWith("showCheckDialogs") }));
      const got = (Array.isArray(res) ? res : []).find(x => x?.outcome in DEGREE); if (!got) { await addNote(combat, id, `${tok.name}'s Swim check gave no result: check the chat.`); return "ask"; }
      rolled = { dc: step.dc, degree: DEGREE[got.outcome], message: got.message?.id ?? null }; await record({ swim: rolled });
    }
    if (rolled.degree < 2) { await save(combat, id, { log: { [i]: { swim: rolled, moved: { to: squareOf(tok, scene), cost: 0 } } }, note: joinNote(combat, id, `${tok.name} failed {their} Athletics check to Swim (DC ${rolled.dc}) and made no progress.`) }); return "next"; }
  }
  const swum = step.do === "swim" ? { swum: true } : {};   /* an automatic success (a swim Speed, calm water) or a rolled one */
  /* someone it didn't know was there, on the way: the move ends before their space, as the rules say. The thinker is asked again without being told why. */
  const known = knownTo(combat, tok, sense(combat, tok, turns(combat).memory?.[tok.id] ?? {})), taken = new Set();
  for (const t of scene.tokens) if (t.id !== tok.id && t.actor?.isOfType?.("creature") && !known.has(t.id) && !t.getFlag(ID, "escaped") && !isBelow(t)) for (const [a, b] of footprintAt(squareOf(t, scene), sizeOf(t))) taken.add(`${a},${b}`);   /* an escaped token is gone, not an unknown creature; a burrowed one is under the ground */
  /* a Burrow passes under everyone: only the square it comes up on can be taken (then it stays below, one square short) */
  const endKeys = dig && !step.below ? new Set(footprintAt(step.to, sizeOf(tok)).map(([a, b]) => `${a},${b}`)) : null;
  const surfaceTaken = dig && !step.below && [...(endKeys ?? [])].some(k => taken.has(k));
  /* a Burrow stops one square short of where it would come up into an unseen creature (only the last square: a Large one's footprints overlap along the
     route), or, coming up where it is, doesn't move at all; either way it stays below (0.16.0 review) */
  const route = dig ? (surfaceTaken ? step.route.slice(0, -1) : step.route) : cutShort(step.route, sizeOf(tok), (a, b) => taken.has(`${a},${b}`));
  const below = dig ? (surfaceTaken ? true : !!step.below) : null;
  /* a Fly that stops short ends at the height it had reached there; a hover (Fly 0 ft) moves nothing and is recorded as flown */
  const height = fly ? heightWhenCut(up(), step.height, route.length - 1, route.length !== step.route.length) : null;
  if (route.length < 2 && !(fly && height !== up()) && !(dig && below !== isBelow(tok))) { await finish({ started: true, ...swum, moved: { to: squareOf(tok, scene), cost: 0 } }); return "next"; }   /* a hover, treading water, or cut short at once */
  const px = scene.grid.size, d = scene.dimensions, action = moveAction(tok, step.do), at = ([x, y]) => ({ x: d.sceneX + x * px, y: d.sceneY + y * px });
  /* a Burrow: down on its own square first, along the route at -5 ft, and up at the end; hidden before it goes down, shown again once it is up */
  const deep = -BURROW_DEPTH, here0 = route[0] ?? squareOf(tok, scene);
  const waypoints = fly ? flyWaypoints(route, up(), height).map(w => ({ ...at(w.square), elevation: w.elev, action }))
    : dig ? [...(isBelow(tok) ? [] : [{ ...at(here0), elevation: deep, action }]), ...route.slice(1).map(sq => ({ ...at(sq), elevation: deep, action })), ...(below ? [] : [{ ...at(route.at(-1)), elevation: 0, action }])]
    : route.slice(1).map(sq => ({ ...at(sq), action }));
  /* player reactions along the way (0.20.0): asked before it leaves the first square in each reactor's reach. A Stride's (Crawl's, flee's) whole route;
     a Fly, Swim or Burrow only where it starts (open item: a flier passing through someone's reach later on its route isn't asked). */
  const gates = (() => { try { return moveGates(combat, tok, step, route); } catch (e) { console.error(`${ID} | reactions`, e); return []; } })(), wasProne = !!tok.actor?.hasCondition?.("prone");
  /* it can't go on after a reaction if it went down, can't move, or was knocked prone (a Crawl is prone all along: review finding 1) */
  const stopped = () => downNow(tok) || !!cantMove(tok.actor) || (!wasProne && !!tok.actor?.hasCondition?.("prone"));
  if (gates.skipped?.length && !Object.keys(request(combat, id)?.gates?.[i] ?? {}).length) await noteSkipped(combat, id, gates.skipped);
  if (gates[0]?.k === 0) { const g = await askReactions(combat, id, i, "move:0", "move", tok, gates[0].list); if (g === "manual") return "next"; if (g === "gone") return "gone";
    if (stopped()) { await finish({ started: true, moved: { to: squareOf(tok, scene), cost: 0 } }); return "next"; } }
  await record({ started: true, ...swum });
  if (dig && !isBelow(tok)) await setBelow(tok, true);
  const go = wps => (async () => { try { return await watched(async () => {
    let got = null; const hook = Hooks.on("moveToken", (doc, mv) => { if (doc.id === tok.id) got = { cost: mv.passed?.cost ?? null, x: mv.destination?.x, y: mv.destination?.y, elevation: mv.destination?.elevation }; });
    try {
      /* a glider passes through earthen walls, which Foundry would stop it at: its route already keeps to what it may cross (0.17.0) */
      if (dig && glidesThroughRock(tok.actor)) await scene.moveTokens({ [tok.id]: { waypoints: wps, constrainOptions: { ignoreWalls: true } } }); else await tok.move(wps);
      for (let t = 0; t < STEP_MS && !(got && tok.x === got.x && tok.y === got.y && (got.elevation == null || tok.elevation === got.elevation)); t += 100) await new Promise(res => setTimeout(res, 100));   /* the hook comes before the update lands */
      await within(tok.object?.movementAnimationPromise ?? Promise.resolve(), 10000, "The move's animation didn't finish.").catch(() => {});   /* cover and sight are read from where the token is drawn */
      return got;
    } finally { Hooks.off("moveToken", hook); }
  }); } finally { if (dig) await setBelow(tok, isBelow(tok)).catch(e => console.warn(`${ID} | burrowing`, e)); } })();   /* hidden only while really below, even if the move failed (0.16.0 review) */
  /* a Stride's waypoint w is route square w + 1: to stop on route square k it moves along waypoints 0..k-1, is asked, then goes on (0.20.0) */
  let charged = null, from = 0, held = false; const add = got => { if (got?.cost != null) charged = { cost: (charged?.cost ?? 0) + got.cost }; else if (!charged) charged = got; };
  /* someone readied (0.35.0): the move goes a square at a time, so a Now! stops it in the square it was entering. Not under the ground. */
  /* a Now! stops it in the square it was entering, waits for the readied action, then it goes on unless it can't (as after a reaction) */
  const watchReady = !dig && readiedNow(combat).length > 0;
  const goAll = async wps => { if (!watchReady) { add(await go(wps)); return null; }
    for (const w of wps) { add(await go([w]));
      if (request(combat, id)?.readied) { const r = await waitReadied(combat, id, true); if (r !== "ok") return r; if (stopped()) return "stopped"; } }
    return null; };
  for (const g of gates.filter(g => g.k > 0)) {
    const ga = await goAll(waypoints.slice(from, g.k)); if (ga === "manual" || ga === "gone") { await finish({ moved: { to: squareOf(tok, scene), cost: charged?.cost ?? null } }); return ga === "gone" ? "gone" : "next"; } if (ga) { held = true; break; } from = g.k;
    const res = await askReactions(combat, id, i, `move:${g.k}`, "move", tok, g.list);
    if (res === "manual" || res === "gone") { await finish({ moved: { to: squareOf(tok, scene), cost: charged?.cost ?? null } }); return res === "gone" ? "gone" : "next"; }
    if (stopped()) { held = true; break; }   /* it can't go on: it stops where it is */
  }
  if (!held && from < waypoints.length) { const ga = await goAll(waypoints.slice(from)); if (ga === "gone") { await finish({ moved: { to: squareOf(tok, scene), cost: charged?.cost ?? null } }); return "gone"; } }
  await finish({ moved: { to: squareOf(tok, scene), cost: charged?.cost ?? null } });
  if (dig && surfaceTaken) await addNote(combat, id, `${tok.name} couldn't come up at square ${step.to[0]}, ${step.to[1]}: something is there. {They} {stays|stay} below ground.`);
  if (fly && tok.getFlag(ID, "climbing")) await setClimbing(tok, null).catch(e => console.warn(`${ID} | climbing`, e));   /* it flew off its tree: not holding on any more */
  return "next";
}
/* ---------- climbing (0.15.0) ---------- */
/** Up a tree, or back down: its flag (which tree, how tall) and, without a climb Speed, the Off-Guard the rules give a climber (Player Core Climb: "You're
    off-guard while climbing unless you have a climb Speed"). The module removes only the Off-Guard it added itself (its id is on the flag): one from
    another cause stays. */
async function setClimbing(tok, tree, guard) {
  const actor = tok.actor, f = tok.getFlag(ID, "climbing");
  if (!tree) { if (f?.guard && actor) await watched(() => actor.items.get(f.guard)?.delete() ?? null); if (f) await watched(() => tok.unsetFlag(ID, "climbing")); return; }
  if (!actor) return;
  let id = f?.guard && actor.items.get(f.guard) ? f.guard : null;   /* the GM may have deleted it by hand: add it again */
  if (guard && !id) id = (await watched(() => actor.increaseCondition?.("off-guard")))?.id ?? null;   /* null when it was already off-guard from something else */
  if (!guard && id) { await watched(() => actor.items.get(id)?.delete() ?? null); id = null; }
  await watched(() => tok.setFlag(ID, "climbing", { at: [...tree.at], top: tree.top, guard: id }));
}
/** At each turn change: a token whose climbing flag no longer holds (the GM moved it off the tree or down, or it is dead) loses the flag and the
    module's Off-Guard, so a monster on the ground isn't left off-guard. */
async function settleClimbers(combat) {
  for (const tok of sceneOf(combat)?.tokens ?? []) {
    if (!tok.getFlag(ID, "climbing")) continue;
    try {
      const up = treeUp(tok, sceneOf(combat));
      if (!up || !tok.actor || tok.actor.isDead) { if (up && tok.actor?.isDead) await watched(() => tok.update({ elevation: 0 })); await setClimbing(tok, null); continue; }   /* a dead climber's body drops, as a dead flier's does */
      /* still up without a climb Speed and no longer off-guard (another cause it shared ended, or the GM removed it): off-guard again */
      if (!(climbSpeedOf(tok.actor) > 0) && !tok.actor.hasCondition?.("off-guard")) await setClimbing(tok, up, true);
    } catch (e) { console.warn(`${ID} | climbing`, e); }
  }
}
/** A Climb (Rhea, 2026-11-08; Player Core Climb, Actions ID 2374; climb Speed, Rules ID 2349): straight up or down the tree beside it, on its own
    square. With a climb Speed no check; without one PF2e's own Climb (an Athletics check, its card in chat) at the step's DC, rolled once (marked
    before the roll, so a reload asks instead of rolling again): below a success no progress, and a critical failure falls from the height it had,
    landing prone if it started on the ground (Player Core Climb) or took damage (Falling). Afterwards the flag and Off-Guard follow where it ends, and
    the look-before baseline takes in the Off-Guard its own Climb added or removed, so it doesn't re-plan for that. */
async function runClimb(combat, id, i, step, tok) {
  const scene = sceneOf(combat), record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {}, actor = tok.actor;
  const finish = async (rec, before) => { const seen = request(combat, id).seen, change = { log: { [i]: rec } };
    if (seen?.me && before) change.seen = { me: { conditions: absorbOwn(seen.me.conditions ?? [], before, situationOf({ me: { conditions: conditionWords(actor) } }).me.conditions, ["off-guard"]) } };
    if (rec.moved && rec.moved.elev !== step.height) change.note = joinNote(combat, id, `${tok.name} is ${rec.moved.elev} ft up instead of ${step.height} ft.`);
    await save(combat, id, change); };
  for (let guard = 0; guard < 4; guard++) {
    const now = nextClimb(get(), step, heightUp(tok));
    if (now === "next") return "next";
    if (now === "arrived") { const before = situationOf({ me: { conditions: conditionWords(actor) } }).me.conditions.filter(c => c !== "off-guard" || !(step.height > 0 && !step.climbSpeed));   /* after a reload its own Off-Guard may already be on */ await setClimbing(tok, step.height > 0 ? { at: step.tree, top: step.top } : null, !step.climbSpeed); await finish({ ...get(), moved: { elev: heightUp(tok) } }, before); return "next"; }
    if (now === "ask") { const f = get().falling; await addNote(combat, id, f ? `${tok.name} critically failed {their} Climb and was falling ${f.from} ft when the page reloaded: put {them} on the ground, and apply ${f.from > 5 ? `${Math.floor(f.from / 2)} bludgeoning damage and Prone` : f.from ? "no damage" : "Prone"} if that didn't happen.` : `${tok.name}'s Climb was under way when the page reloaded: check its card and height, then move {them} or press Next step.`); return "ask"; }
    if (!stepGate(now === "roll" ? "climb-roll" : "climb", id)) return "stopped";
    if (!(await ensureScene(combat) && tok.object)) throw new Error(cantOpen());
    if (now === "roll") {
      await record({ climbStarted: true });
      const res = await watched(() => game.pf2e.actions.get("climb").use({ actors: [actor], difficultyClass: { value: step.dc }, event: clickWith("showCheckDialogs") }));
      const got = (Array.isArray(res) ? res : []).find(x => x?.outcome in DEGREE); if (!got) { await addNote(combat, id, `${tok.name}'s Climb check gave no result: check the chat.`); return "ask"; }
      const climb = { dc: step.dc, degree: DEGREE[got.outcome], message: got.message?.id ?? null };
      if (climb.degree === 1) { await save(combat, id, { log: { [i]: { climb } }, note: joinNote(combat, id, `${tok.name} failed {their} Athletics check to Climb (DC ${climb.dc}) and made no progress.`) }); return "next"; }
      if (climb.degree === 0) {
        /* a critical failure: it falls from the height it had; from the ground it lands prone (Player Core Climb), from higher by the falling rules */
        const from = heightUp(tok); await record({ climb, falling: { from } });
        if (from > 0) await watched(() => tok.update({ elevation: 0 }));
        const dmg = await fallDamage(tok, from), prone = !actor.isDead && (dmg > 0 || from === 0);
        if (prone && !actor.hasCondition?.("prone")) await watched(() => actor.increaseCondition?.("prone"));
        await setClimbing(tok, null);
        await save(combat, id, { log: { [i]: { climb, fell: { from, damage: dmg, prone } } }, note: joinNote(combat, id, `${tok.name} critically failed {their} Athletics check to Climb (DC ${climb.dc}) and fell${from ? ` ${from} ft${dmg ? `, taking ${dmg} bludgeoning damage` : " (no damage from 5 ft or less)"}` : ""}${prone ? " and landed prone" : ""}.`) });
        return "next";
      }
      await record({ climb }); continue;
    }
    /* move: straight up or down on its own square, with Foundry's climb action */
    const before = situationOf({ me: { conditions: conditionWords(actor) } }).me.conditions;
    await record({ started: true });
    await watched(async () => {
      await tok.move([{ x: tok.x, y: tok.y, elevation: step.height, action: "climb" }]);
      for (let t = 0; t < STEP_MS && tok.elevation !== step.height; t += 100) await new Promise(res => setTimeout(res, 100));
      await within(tok.object?.movementAnimationPromise ?? Promise.resolve(), 10000, "The climb's animation didn't finish.").catch(() => {});
    });
    await setClimbing(tok, heightUp(tok) > 0 ? { at: step.tree, top: step.top } : null, !step.climbSpeed);
    await finish({ ...get(), moved: { elev: heightUp(tok) } }, before);
    return "next";
  }
  return "ask";
}
/** A Release (Player Core, Actions ID 2300): a free action that drops what it holds on its square, through PF2e's own carry type ("dropped"), with a
    short public card so everyone sees it let go. Grabbed: a DC 5 flat check first, as for Interact (the same stages, `nextInteract`). It doesn't
    trigger reactions. Picking the item up again is an Interact, which the GM applies. */
/** Draw (0.33.2): the weapon from worn or stowed into its hands, by PF2e's own carry change, with a public card "Interact: draws its …". Never done twice: a
    reload after it finds the weapon held and goes on. Grabbed asks the DC 5 flat check first, as Release does. */
async function runDraw(combat, id, i, step, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {}, actor = tok.actor;
  const item = () => actor.items.get(step.weaponItem), held = () => item()?.system?.equipped?.carryType === "held";
  for (let guard = 0; guard < 4; guard++) {
    const rec = get();
    if (rec.drawn || (rec.started && held())) { if (!rec.drawn) await record({ drawn: true }); return "next"; }
    if (rec.flat && !rec.flat.ok) return "next";
    if (step.flat && !rec.flat) {
      if (!stepGate("flat", id)) return "stopped";
      if (rec.flatStarted) { await addNote(combat, id, `${tok.name}'s flat check to draw was under way when the page reloaded: check the chat, then draw {their} ${step.itemName} by hand if it passed.`); return "ask"; }
      await record({ flatStarted: true });
      const roll = await watched(async () => { const r = await new Roll("1d20").evaluate(); await r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Flat check, DC ${step.flat} (grabbed, a manipulate action)` }); return r; });
      await record({ flat: { dc: step.flat, total: roll.total, ok: roll.total >= step.flat } });
      if (roll.total < step.flat) { await addNote(combat, id, `{Their} draw failed {their} DC ${step.flat} flat check (${roll.total}): {they} {is|are} grabbed. The action is spent.`); return "next"; }
      continue;
    }
    if (!stepGate("draw", id)) return "stopped";
    const w = item(); if (!w) { await addNote(combat, id, `${tok.name} no longer carries {their} ${step.itemName}.`); return "next"; }
    await record({ started: true });
    await watched(() => actor.changeCarryType(w, { carryType: "held", handsHeld: step.hands ?? handsFor(w) }));
    const message = await watched(() => ChatMessage.implementation.create({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), content: `<p><strong>Interact</strong> <span class="action-glyph">1</span>: draws ${pro("{their}", P(tok, combat))} ${foundry.utils.escapeHTML(w.name)}.</p>` }));
    await record({ drawn: true, posted: { message: message?.id ?? null } });
    return "next";
  }
  return "ask";
}
async function runRelease(combat, id, i, step, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {}, actor = tok.actor;
  for (let guard = 0; guard < 4; guard++) {
    const now = nextInteract(get(), { flat: step.flat ?? 0 });
    if (now === "gm") return "next";   /* dropped */
    if (now === "next") return "next";
    if (now === "ask") { const item = heldItems(actor).find(h => h.id === step.item); if (!item) { await record({ dropped: true, posted: { message: null } }); return "next"; } await addNote(combat, id, `${tok.name}'s Release was under way when the page reloaded: check whether {they} still {holds|hold} {their} ${step.itemName}.`); return "ask"; }
    if (!stepGate(now === "flat" ? "flat" : "release", id)) return "stopped";
    if (now === "flat") {
      await record({ flatStarted: true });
      const roll = await watched(async () => { const r = await new Roll("1d20").evaluate(); await r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Flat check, DC ${step.flat} (grabbed, a manipulate action)` }); return r; });
      await record({ flat: { dc: step.flat, total: roll.total, ok: roll.total >= step.flat } });
      if (roll.total < step.flat) await addNote(combat, id, `{Their} Release failed {their} DC ${step.flat} flat check (${roll.total}): {they} {is|are} grabbed, and still {holds|hold} {their} ${step.itemName}.`);
      continue;
    }
    await record({ started: true });
    const h = heldItems(actor).find(x => x.id === step.item), item = h ? actor.items.get(h.itemId) : null;
    if (!item) { await save(combat, id, { log: { [i]: { dropped: true, posted: { message: null } } }, note: joinNote(combat, id, `${tok.name} no longer holds {their} ${step.itemName}.`) }); return "next"; }
    await watched(() => actor.changeCarryType(item, { carryType: "dropped", handsHeld: 0 }));
    const message = await watched(() => ChatMessage.implementation.create({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), content: `<p><strong>Release</strong> <span class="action-glyph">F</span>: drops ${pro("{their}", P(tok, combat))} ${foundry.utils.escapeHTML(item.name)}.</p>` }));
    await record({ dropped: true, posted: { message: message?.id ?? null } });
    return "next";
  }
  return "ask";
}
/** Stand or Drop Prone: PF2e's own action (`StandActionVariant`, `DropProneActionVariant` in PF2e 8.7.0), which posts its card and then removes or adds
    Prone, with no dialog. Never sent twice: one begun before a reload counts as done if the monster is already as the step leaves it, and the GM looks
    otherwise; one not begun with the monster already like that posts nothing. Afterwards the look-before baseline takes in what the action itself changed
    (`absorbOwn`: Prone and the Off-Guard it brings), so it doesn't re-plan for its own doing, while anything a reaction added still counts. Not built:
    Reactive Strike and the like, which these move actions can trigger at the end of the action (Rules ID 446). */
const PRONE_SET = ["prone", "off-guard"];
async function runPosture(combat, id, i, kind, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {}, actor = tok.actor, wantProne = POSTURES[kind];
  const already = () => !!actor.hasCondition?.("prone") === wantProne, words = kind === "stand" ? "Stand" : "Drop Prone";
  /* the step's record and the baseline go in one save, so a reload can't leave the step done with the old conditions */
  const finish = async (rec, before) => { const seen = request(combat, id).seen, change = { log: { [i]: rec } };
    if (seen?.me) change.seen = { me: { conditions: absorbOwn(seen.me.conditions ?? [], before, situationOf({ me: { conditions: conditionWords(actor) } }).me.conditions, PRONE_SET) } };
    await save(combat, id, change); };
  const now = nextPosture(get(), already());
  if (now === "next") return "next";
  if (now === "already") { await finish({ changed: { message: null } }, request(combat, id).seen?.me?.conditions ?? []); return "next"; }
  if (now === "ask") { await save(combat, id, { note: `${tok.name} started to ${words} and is ${wantProne ? "not" : "still"} prone.` }); return "ask"; }
  if (!stepGate(kind, id)) return "stopped";
  const before = situationOf({ me: { conditions: conditionWords(actor) } }).me.conditions;
  await record({ started: true });
  const out = await watched(() => game.pf2e.actions.get(kind).use({ actors: [actor] }));
  for (let t = 0; t < 2000 && !already(); t += 100) await new Promise(res => setTimeout(res, 100));   /* PF2e awaits its toggle, but give the update a moment */
  if (!already()) { await save(combat, id, { note: `${tok.name} used ${words} but is ${wantProne ? "not" : "still"} prone.` }); return "ask"; }
  if (!wantProne) await dropOwnCover(tok, true);   /* the greater cover against ranged attacks a prone Take Cover gave lasts only while prone (Visioner removes its own) */
  await finish({ changed: { message: out?.[0]?.message?.id ?? null } }, before);
  return "next";
}
/* ---------- Take Cover ---------- */
/* Rhea, 2026-11-07: rule B for when it's allowed (prone, a wall or thick trunk next to it, or standard cover from a creature it sees), and Visioner's own
   per-creature cover for what it does, because that is how the rules work: standard cover from someone becomes greater, anything less becomes standard.
   PF2e's own "Effect: Cover" gives one bonus against everyone, takes the higher of it and Visioner's wall cover rather than adding (tested: AC 15 behind a
   thick trunk was 17 with it at standard), and never ends by itself. Visioner's public setCover with its takeCover option is what its own Take Cover
   calls. Ending it, and its prone effect, aren't in its API, so those come from its own files; if an update moves them the module falls back: the GM
   clicks Visioner's "Take Cover Should End" card, and a prone monster gets PF2e's effect. With Visioner off, PF2e's effect is used throughout. */
const SEES = ["observed", "concealed"], STANDARD = ["standard", "greater"];
const COVER_EFFECT = "Compendium.pf2e.other-effects.I9lfZUiCwMiGogVi", COVER_BONUS = { standard: 2, greater: 4, "greater-prone": 4 };
const visionerApi = () => game.modules.get(VISIONER)?.active ? game.modules.get(VISIONER).api ?? null : null;
const coverOf = (vis, observer, target) => { try { return vis.getAutoCoverState(observer.id, target.id) ?? "none"; } catch { return "none"; } };
/* the same address Foundry loaded Visioner's own files from, so the import gets its very copies (their state is shared), with any route prefix */
async function visionerFile(name) { if (!visionerApi()) return null; try { return await import(foundry.utils.getRoute(`modules/${VISIONER}/scripts/${name}`)); } catch (e) { console.warn(`${ID} | Visioner's ${name}`, e); return null; } }
const TAKE_COVER_SOURCES = ["take_cover_action"];
/** The PF2e cover effects this module added, flagged with their level; `proneOnly` picks the greater-prone kind, which counts only while prone. */
const ownCover = (tok, proneOnly = false) => (tok.actor?.itemTypes?.effect ?? []).filter(e => { const l = e.getFlag?.(ID, "takeCover"); return l && (!proneOnly || l === "greater-prone"); });
async function dropOwnCover(tok, proneOnly = false) { const ids = ownCover(tok, proneOnly).map(e => e.id); if (ids.length) await tok.actor.deleteEmbeddedDocuments("Item", ids); }
/** Whether it is Taking Cover now: Visioner's record of a Take Cover against anyone (as Visioner's own check reads it, a pending end included), Visioner's
    prone effect, or the PF2e effect this module adds. */
function takingCover(tok) {
  const flags = tok.flags?.[VISIONER] ?? {};
  if (Object.entries(flags).some(([k, f]) => k.startsWith("avs-override-from-") && (f?.coverOnly === true || TAKE_COVER_SOURCES.includes(f?.coverOverrideSource) || (TAKE_COVER_SOURCES.includes(f?.source) && f?.expectedCover)))) return true;
  const prone = !!tok.actor?.hasCondition?.("prone");   /* the prone-only kind gives nothing once it stands (Visioner removes its own then) */
  return (tok.actor?.itemTypes?.effect ?? []).some(e => e.flags?.[VISIONER]?.takeCoverProneRangedOnly === true) || ownCover(tok).some(e => prone || e.getFlag(ID, "takeCover") !== "greater-prone");
}
/** nearCover(square, size) for checkPlan: the scene's walls a creature could take cover behind, as segments in squares: the walls Visioner gives cover
    from (CoverDetector, 8.14.17: one that blocks sight, or one set to give standard or greater cover). An open door doesn't count; neither does a wall set
    to give lesser cover or none, or no cover at all (Survey Sheet's thin trunks: Rhea's rule, under 3 ft across is lesser cover, too thin to hide behind).
    Known gap: an invisible wall round a map's edge blocks sight, so it counts too. */
function coverSegs(scene) {
  const px = scene.grid.size, d = scene.dimensions, NONE = 0, open = CONST.WALL_DOOR_STATES?.OPEN ?? 1;
  return scene.walls.contents.filter(w => { const f = w.flags?.[VISIONER] ?? {}; if (w.door && w.ds === open) return false;
      return STANDARD.includes(f.coverOverride) || (w.sight !== NONE && !["lesser", "none"].includes(f.coverOverride) && f.provideCover !== false); })
    .map(w => [(w.c[0] - d.sceneX) / px, (w.c[1] - d.sceneY) / px, (w.c[2] - d.sceneX) / px, (w.c[3] - d.sceneY) / px]);
}
function nearCoverFor(scene) {
  let segs = null;
  return (square, size = 1) => { segs ??= coverSegs(scene); return !!square && featureNear(square, size, segs); };
}
/** For the packet's ground map: the squares holding a wall Take Cover can use (a thick trunk, a solid wall), as takeCoverAt(x, y). A segment counts for a
    square it passes through the inside of (sampled every tenth of a square, within its middle 70%, the same margin as the map's own blocking), so a trunk ring marks the square it stands in. */
function takeCoverSquares(scene) {
  const at = new Set();
  for (const [x1, y1, x2, y2] of coverSegs(scene)) { const n = Math.max(1, Math.ceil(Math.hypot(x2 - x1, y2 - y1) * 10));
    for (let k = 0; k <= n; k++) { const x = x1 + (x2 - x1) * k / n, y = y1 + (y2 - y1) * k / n, fx = x - Math.floor(x), fy = y - Math.floor(y); if (fx > 0.15 && fx < 0.85 && fy > 0.15 && fy < 0.85) at.add(`${Math.floor(x)},${Math.floor(y)}`); } }
  return (x, y) => at.has(`${x},${y}`);
}
/** PF2e's own "Effect: Cover" with its level already chosen, so its prompt doesn't open where nobody can click it (a rule's `selection` skips it). */
async function addCoverEffect(actor, level) {
  const src = (await fromUuid(COVER_EFFECT))?.toObject(); if (!src) throw new Error("PF2e's Effect: Cover isn't in its compendium.");
  const choice = src.system.rules.find(r => r.key === "ChoiceSet"); if (!choice) throw new Error("PF2e's Effect: Cover has no choice to set.");
  delete src._id; choice.selection = { bonus: COVER_BONUS[level], level }; foundry.utils.setProperty(src, `flags.${ID}.takeCover`, level);
  await actor.createEmbeddedDocuments("Item", [src]);
}
/** The creatures Take Cover counts against: every creature on the map that isn't its ally, whether it knows of them or not (cover is where it is), except
    tokens the GM has hidden: Visioner keeps no Take Cover record for those, so their cover would never end (Visioner skips them in its own Take Cover). */
const coverSubjects = (scene, tok) => scene.tokens.contents.filter(t => t.id !== tok.id && !t.hidden && t.object && t.actor?.isOfType?.("creature") && !t.actor.isAllyOf?.(tok.actor));
async function takeCover(combat, tok) {
  const actor = tok.actor, prone = !!actor.hasCondition?.("prone"), vis = visionerApi();
  const out = await game.pf2e.actions.get("take-cover").use({ actors: [actor], effect: false });   /* its card, without PF2e's effect */
  const message = out?.[0]?.message?.id ?? null;
  if (!vis) { const level = prone ? "greater-prone" : "standard"; await addCoverEffect(actor, level); return { message, by: "pf2e", level }; }
  const levels = {}; let proneRanged = false, failed = 0;
  const subjects = coverSubjects(sceneOf(combat), tok);
  for (const t of subjects) {
    const level = coverAfterTaking(coverOf(vis, t, tok), prone);
    if (level === "prone-ranged") { proneRanged = true; continue; }
    if (await vis.setCover(t.id, tok.id, level, { takeCover: true, skipEphemeralUpdate: false })) levels[t.id] = level; else failed++;
  }
  if (prone && !subjects.length) proneRanged = true;
  let pf2e = false;
  if (proneRanged) { const batch = await visionerFile("cover/batch.js"); if (batch?.applyTakeCoverProneRangedOnlyEffect) await batch.applyTakeCoverProneRangedOnlyEffect(tok.object); else { await addCoverEffect(actor, "greater-prone"); pf2e = true; } }
  return { message, by: "visioner", levels, proneRanged, ...(pf2e ? { pf2eProne: true } : {}), ...(failed ? { failed } : {}), ...(!subjects.length && !prone ? { nobody: true } : {}) };
}
/** Take Cover. Never sent twice: one begun before a reload goes to the GM. Afterwards it checks the cover took (Visioner's setCover reports a failure
    only by returning false); with nobody on the map to take cover from there is nothing to check. */
/* ---------- Interact and Delay (0.12.0) ---------- */
/** Interact: the module can't know what a monster does with its hands, so it posts a card saying what (the thinker's words, labels only) and the GM
    applies it, as for an ability the module can't run. Grabbed: a DC 5 flat check first; a failure spends the action on nothing (Rules: Grabbed). */
async function runInteract(combat, id, i, step, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {};
  for (let guard = 0; guard < 4; guard++) {
    const rec = get();
    const now = nextInteract(rec, { flat: step.flat ?? 0 });
    if (now === "next" || now === "gm" || now === "ask") return now;
    if (!stepGate(now, id)) return "stopped";
    pending = { tokenId: tok.id, waiters: new Map() };
    try {
      if (now === "flat") {
        await record({ flatStarted: true });
        const roll = await watched(async () => { const r = await new Roll("1d20").evaluate(); await r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Flat check, DC ${step.flat} (grabbed, a manipulate action)` }); return r; });
        await record({ flat: { dc: step.flat, total: roll.total, ok: roll.total >= step.flat } });
        if (roll.total < step.flat) await addNote(combat, id, `{Their} Interact failed {their} DC ${step.flat} flat check (${roll.total}): {they} {is|are} grabbed. The action is spent.`);
      } else if (now === "post") {
        stopAiming(); await record({ started: true });
        /* the thinker writes labels; the card is read by people, so labels become token names (only names the fight already shows in its tracker) */
        /* as players may read them (0.33.1, review): a hidden creature is "someone", a name kept from players "a creature" */
        const what = foundry.utils.escapeHTML(playerNamer(combat).named(String(step.what ?? "")));
        const message = await watched(() => ChatMessage.implementation.create({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), content: `<p><strong>Interact</strong> <span class="action-glyph">1</span>: ${what}</p>` }));
        /* the record and the GM's instruction in one save, so a reload can't keep one without the other */
        await save(combat, id, { log: { [i]: { posted: { message: message?.id ?? null } } }, note: joinNote(combat, id, `Apply what {they} {does|do} from the Interact card.`) });
      }
    } finally { pending = null; }
  }
  return "ask";
}
/** Delay: the turn ends now, as usual (start- and end-of-turn effects happen at once, as the rules say), then the monster's initiative moves to the named
    creature's with a tie-break that puts it right after, so its next turn comes when that creature's ends. The runner keeps the current turn through
    the initiative change (`keepTurn`). If its place can't be moved the turn has still ended, and the note says so. */
async function runDelay(combat, id, i, step, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), rec = request(combat, id).log?.[i] ?? {};
  if (rec.moved) return "delayed";
  if (rec.ended) return "ask";   /* the turn ended but the move wasn't recorded: a reload between the two; the GM checks the tracker */
  const me = combat.combatants.find(c => c.tokenId === tok.id), afterId = tokenIdOf(combat, request(combat, id), step.after), other = afterId ? combat.combatants.find(c => c.tokenId === afterId) : null;
  /* nothing has happened yet in these refusals, so the turn stops for the GM with the reason (not "ask", whose words say the turn should have ended) */
  if (!me || !other || other.initiative == null || other.isDefeated) { await addNote(combat, id, `${step.after} isn't in the fight any more${other?.isDefeated ? " (defeated)" : ""}, so it can't delay until after its turn. Play the turn yourself.`); return "stopped"; }
  const order = combat.turns, mineAt = order.findIndex(c => c.id === me.id), otherAt = order.findIndex(c => c.id === other.id);
  if (!(otherAt > mineAt)) { await addNote(combat, id, `${step.after}'s turn this round has passed, so delaying until after it would only lose this turn. Play the turn yourself.`); return "stopped"; }
  if (!stepGate("delay", id)) return "stopped";
  if (combat.combatant?.id !== me.id) { await addNote(combat, id, "It isn't this monster's turn any more. Play the turn yourself."); return "stopped"; }
  /* Rules: start- and end-of-turn effects happen when it Delays, and not again when it comes back. PF2e does the same: it runs a creature's turn start
     and turn end once a round (the combatant's `roundOfLastTurn` and `roundOfLastTurnEnd` flags), so the returned turn fires neither (seen live
     2026-11-10 with persistent damage on the monster). Until 0.23.0 a note here told the GM to undo a second application that never comes. */
  /* right after `other` among ties: a priority just above its own (lower goes first) */
  const priority = (other.overridePriority?.(other.initiative) ?? other.actor?.initiative?.tiebreakPriority ?? 3) + 0.5;
  await record({ ended: true, after: { id: other.id, initiative: other.initiative, priority } });
  await combat.nextTurn();
  const nextId = combat.combatant?.id ?? null;   /* whose turn it is now: the pointer must still name them after the re-sort */
  await combat.setMultipleInitiatives([{ id: me.id, value: other.initiative, statistic: me.actor?.system?.initiative?.statistic ?? "perception", overridePriority: priority }]);
  /* seen live (0.12.0 test build): the server's turn number stayed where nextTurn put it, which after the re-sort named the monster again (core keeps
     the current creature in each page's copy only, and PF2e's own fix sends nothing when the copy already agrees), so save the pointer ourselves */
  const keep = combat.turns.findIndex(c => c.id === nextId);
  if (nextId && keep >= 0) await combat.update({ turn: keep }, { diff: false, turnEvents: false });
  /* PF2e HUD's tracker marks a delayed creature with its own flag (its hourglass button sets it, and a second press brings the creature back right after
     the current one): the module sets the same flag so the tracker shows the monster delayed, and clears it when its turn comes back (onTurnChange) */
  if (game.modules.get(HUD)?.active) await me.setFlag(HUD, "delayed", true).catch(e => console.warn(`${ID} | HUD delayed flag`, e));
  await record({ moved: true, turn: keep });
  return "delayed";
}
async function runTakeCover(combat, id, i, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {};
  const now = nextCover(get(), takingCover(tok));
  if (now === "next") return "next";
  if (now === "already") { await record({ covered: { already: true } }); return "next"; }
  if (now === "ask") { await save(combat, id, { note: `${tok.name} started to Take Cover before the page reloaded, so {their} cover may not have reached every creature${takingCover(tok) ? "" : " ({they} {isn't|aren't} Taking Cover now)"}.` }); return "ask"; }
  if (!stepGate("take-cover", id)) return "stopped";
  if (!(await ensureScene(combat) && tok.object)) throw new Error(cantOpen());
  await record({ started: true });
  const got = await watched(() => takeCover(combat, tok));
  if (got.failed || (!got.nobody && !takingCover(tok))) { await save(combat, id, { log: { [i]: { tried: got } }, note: `${tok.name} used Take Cover, but ${got.failed ? `Visioner didn't set {their} cover against ${got.failed === 1 ? "one creature" : `${got.failed} creatures`}` : "{they} {isn't|aren't} Taking Cover"}.` }); return "ask"; }
  await record({ covered: got });
  return "next";
}
const pendingCoverCard = tok => game.messages.contents.filter(m => { const f = m.flags?.[VISIONER]?.takeCoverExpiration; return f?.tokenId === tok.id && f.status === "pending"; }).at(-1) ?? null;
/** End a Take Cover its own attack or move just ended (the rules: until it moves from its space or makes an attack). Visioner posts its own "Take Cover
    Should End" card for that moment; this waits briefly for it and accepts it, so the card reads as done, or ends it directly if no card comes. Returns a
    note for the GM when it couldn't. */
async function endTakeCover(tok, reason) {
  await dropOwnCover(tok);   /* first: a greater-prone one left after a Stand doesn't count as Taking Cover, but is still there */
  if (!takingCover(tok)) return null;
  const did = reason === "attack" ? "attacked" : "moved";
  const svc = await visionerFile("chat/services/take-cover-expiration-service.js");
  if (!svc?.expireTakeCoverForToken || !svc?.acceptTakeCoverExpirationMessage) return `${tok.name} ${did}, which ends {their} Take Cover: remove it in Visioner (Remove Take Cover on its card, if one came).`;
  let card = null; for (let t = 0; t < 1500 && !(card = pendingCoverCard(tok)); t += 100) await new Promise(res => setTimeout(res, 100));
  if (card) await svc.acceptTakeCoverExpirationMessage(card); else await svc.expireTakeCoverForToken(tok.object, reason);
  /* another GM's browser can post a second card for the same move; left pending, a later click would end a newer Take Cover */
  for (let left = pendingCoverCard(tok); left; left = pendingCoverCard(tok)) if (!(await svc.acceptTakeCoverExpirationMessage(left))) break;
  return takingCover(tok) ? `${tok.name}'s Take Cover should have ended ({they} ${did}), and it hasn't: check Visioner's card.` : null;
}
/** After a step: if this request's steps from `from` to `upto` ended its Take Cover, end it, and keep any note for the GM. `coverSettled` (saved with `pos`,
    and with the note) marks the steps already settled, so a Take Cover the GM gives it between steps isn't ended for an earlier Strike, and a reload doesn't
    add the note twice. Run like a stage: a time limit, and a window it opens is closed. */
async function settleCover(combat, id, upto, tok, from = request(combat, id)?.coverSettled ?? 0) {
  const r = request(combat, id); if (!r?.steps || !endsCover(r.steps, r.log, upto, from) || !(takingCover(tok) || ownCover(tok).length)) return;
  let last = null; for (let k = upto - 1; k >= 0 && !last; k--) if (r.steps[k]?.do === "strike" || (["ability", "spell"].includes(r.steps[k]?.do) && r.steps[k].attack) || isMove(r.steps[k]) || r.steps[k]?.do === "climb") last = r.steps[k];   /* a Climb leaves its space too (0.33.1, review) */
  let note; try { note = await watched(() => endTakeCover(tok, isMove(last) || last?.do === "climb" ? "movement" : "attack")); } catch (e) { console.error(`${ID} | take cover`, e); note = `I couldn't end ${tok.name}'s Take Cover (${e.message}): check Visioner's card.`; }
  await save(combat, id, { coverSettled: upto, ...(note ? { note: [request(combat, id).note, note].filter(Boolean).join(" ") } : {}) });
}
/* ---------- abilities ---------- */
/* Rhea, 2026-11-07: the Strike follow-ups (Grab, Knockdown, Push, Pull, and their Improved free-action forms) run for real: PF2e's own Grapple, Trip, Shove or
   Reposition rolls the Athletics check against the target's DC with no dialog, and with no multiple attack penalty passed, as the rules say; PF2e applies
   nothing, so the module applies Grabbed, Restrained or Prone and a critical Trip's 1d6, and leaves moving a pushed or pulled creature, and a target's
   choice on a critical failure, to the GM. Any other ability goes through PF2e's own use (its card, a frequency use, a self-effect button) and the GM applies
   it from the card: the turn waits for Next step. Grab can also keep hold of a creature it has grabbed or restrained: its card, nothing to roll. */
const DEGREE = { criticalFailure: 0, failure: 1, success: 2, criticalSuccess: 3 };
const joinNote = (combat, id, words) => [request(combat, id).note, words].filter(Boolean).join(" ");
const addNote = (combat, id, words) => save(combat, id, { note: joinNote(combat, id, words) });
async function runAbility(combat, id, i, step, tok, target) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {}, actor = tok.actor;
  const ab = abilityList(actor).find(a => a.id === step.item); if (!ab) throw new Error(`${tok.name} has no ${step.itemName} now.`);
  for (let guard = 0; guard < 10; guard++) {
    const now = nextAbility(get(), { mode: step.mode, flat: step.flat ?? 0, apply: applySetting() });
    if (now === "next" || now === "gm" || now === "ask") return now;
    if (!stepGate(now, id)) return "stopped";
    if (!["effects", "apply"].includes(now) && !(await ensureScene(combat) && tok.object && (!target || target.object))) throw new Error(cantOpen());   /* conditions and applying need no canvas */
    pending = { tokenId: tok.id, waiters: new Map() };
    try {
      if (now === "post") {
        if (target) aimAt(target); else stopAiming();
        await record({ started: true });
        /* PF2e's own use: its card, a frequency use, a self-effect button. A Grab with no item of its own (a Strike's attack effect) gets a plain card. */
        const message = await watched(() => ab.item ? game.pf2e.rollItemMacro(ab.item.uuid, null) : ChatMessage.implementation.create({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), content: `<p><strong>${esc(ab.name)}</strong>: keeps hold of ${esc(target?.name ?? "the creature held")}.</p>` }));   /* names escaped (0.33.1, review) */
        /* the record and the GM's instruction in one save, so a reload can't keep one without the other */
        await save(combat, id, { log: { [i]: { posted: { message: message?.id ?? null } } }, ...(step.mode === "card" ? { note: joinNote(combat, id, `Apply ${step.itemName}${step.target ? ` at ${step.target}` : ""} from its card.`) } : {}) });
      } else if (now === "flat") {
        await record({ flatStarted: true });
        const roll = await watched(async () => { const r = await new Roll("1d20").evaluate(); await r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Flat check, DC ${step.flat}` }); return r; });
        await record({ flat: { dc: step.flat, total: roll.total, ok: roll.total >= step.flat } });
        if (roll.total < step.flat) await addNote(combat, id, `${step.itemName} at ${step.target} failed its DC ${step.flat} flat check (${roll.total}). The action is spent.`);
      } else if (now === "check") {
        /* the Strike before it must have hit: the look before this step checks that too, but never roll a follow-up without it */
        if (step.needsHit) { const r = request(combat, id), prev = i > 0 ? lastAction({ step: r.steps[i - 1], rec: r.log?.[i - 1] ?? {} }) : lastAction({ done: r.done?.at(-1) ?? null });
          if (prev?.do !== "strike" || prev.hit !== true) { await addNote(combat, id, `${step.itemName} needs the Strike before it to hit, and it didn't.`); return "ask"; } }
        aimAt(target); await record({ started: true, held: isHeld(target.actor) });
        const res = await watched(() => game.pf2e.actions.get(step.check).use({ actors: [actor], target: target.object, event: clickWith("showCheckDialogs") }));
        const got = (Array.isArray(res) ? res : []).find(x => x?.outcome in DEGREE); if (!got) return "ask";
        await record({ check: { message: got.message?.id ?? null, degree: DEGREE[got.outcome] } });
      } else if (now === "effects") {
        const rec = get(), o = followUpOutcome(step.check, rec.check.degree, { held: !!rec.held, who: step.target, me: tok.name, forms: P(tok, combat) });
        for (const c of o.target) if (!target.actor.hasCondition(c)) await target.actor.increaseCondition(c);
        for (const c of o.self) if (!actor.hasCondition(c)) await actor.increaseCondition(c);
        /* one save: the record, the GM's instruction, and the grip its own Grab made (only those can be kept hold of later) */
        await saveTurns(combat, { [`requests.${id}.log.${i}.effects`]: { target: o.target, self: o.self, damage: o.damage, gm: o.gm }, ...(o.gm ? { [`requests.${id}.note`]: joinNote(combat, id, o.gm) } : {}),
          ...(step.check === "grapple" && o.target.length ? { [`grips.${tok.id}.${target.id}`]: { round: combat.round } } : {}) });
      } else if (now === "damage") {
        aimAt(target); await record({ damageStarted: true });
        const DamageRoll = CONFIG.Dice.rolls.find(r => r.name === "DamageRoll"), formula = get().effects.damage;
        const message = await watched(async () => { const roll = await new DamageRoll(formula).evaluate(); return roll.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `${step.itemName}: critical success, ${formula.replace(/\[(\w+)\]/, " $1")}` }); });
        await record({ damage: { message: message?.id ?? null } });
        if (applySetting() && message) await markApplied(message);
        else if (message) { const hb = await harmByHand(combat, id, i, tok, [{ target, hit: Math.floor(message.rolls?.[0]?.total ?? 0) }]); if (hb === "manual") return "next"; if (hb === "held" || hb === "gone") return hb; }
      } else if (now === "apply") {
        const message = game.messages.get(get().damage.message), roll = message?.rolls?.[0]; if (!roll) return "ask";
        const hit = Math.floor(roll.total), hg = await harmGate(combat, id, i, tok, [{ target, hit }]);   /* Glimpse of Redemption (0.27.0) */
        if (hg === "manual") return "next"; if (hg === "held" || hg === "gone") return hg;
        const hm = harmFor(combat, id, i, target, hit);
        await record({ applying: true }); const was = hpNow(target);
        if (!hm.repent) await watched(() => (hm.resist ? target.actor.getContextualClone([], [resistEffect(hm.resist)]) : target.actor).applyDamage({ damage: roll, token: target, item: null, shieldBlockRequest: false }));
        await record({ applied: true, hp: [was, hpNow(target)] });
        await afterHarm(combat, id, i, tok, target, { hit, was });
        if (target.actor?.isOfType?.("character") && target.actor.hitPoints?.value === 0) await addNote(combat, id, `${target.name} is at 0 HP. If you undo this, PF2e restores the HP but you still need to remove Wounded and Prone and put their initiative back.`);
      }
    } finally { pending = null; }
  }
  return "ask";
}
/* ---------- spells ---------- */
/* Rhea, 2026-11-07. The module casts with the entry's own cast (the slot or use is spent and the card posted, as a sheet's Cast does), then: a spell attack
   rolls like a Strike (the attack penalty, the flat check, real targets) and a damaging one's damage is applied, doubled on a critical hit (PF2e rolls a
   spell attack's damage as a hit; its DOUBLE button is the critical); a save spell waits for the target's save on Toolbelt's row on the spell card: a
   player rolls their own and the turn waits with no timer, while a creature no player owns, or one whose player is offline, is rolled by the module
   through Toolbelt's own buttons. A basic save's damage is applied by degree. Anything else a spell does is the GM's, from its card. */
const ownerOnline = actor => game.users.some(u => !u.isGM && u.active && actor?.testUserPermission?.(u, "OWNER"));
/** The degree of a creature's save on a spell's card, from Toolbelt's row (its flag, which Workbench reads too), or null. */
/* ---------- Hide, Sneak and Seek ---------- */
/* Rhea, 2026-11-07: PF2e's own action posts the secret card, and the module presses Visioner's own buttons on it on this page (Apply Changes; Start Sneak
   before a Sneak's move), so Visioner alone decides who the monster is hidden from or finds, what each creature's cover and concealment allow, and the
   off-guard; the GM can Revert from the card. The card's buttons are Visioner's markup (`data-action` apply-now-hide, apply-now-seek, start-sneak,
   apply-now-sneak, apply-now-consequences in 8.14.17): if they aren't there (Visioner off, or an update changed its card), the step goes to the GM.
   Visioner checks every creature on the map for a Seek unless its card names an area, so the module writes the Seek's area into Visioner's own flag on
   the card (`seekTemplate`: a circle by straight distance, or a cone by angle, tested on each token's centre). Visioner's Start Sneak records every
   creature's start as hidden when its automatic system is off (it calls TokenDocument#canObserve, which Foundry 14 doesn't have, found 2026-11-07), so the
   module puts Visioner's own stored states back on the card before the move. */
const HIDDEN = ["hidden", "undetected", "unnoticed"], STEALTH_WORD = { hide: "Hide", sneak: "Sneak", seek: "Seek" };
const sleep = ms => new Promise(res => setTimeout(res, ms));
const cardEl = id => ui.chat?.element?.querySelector?.(`[data-message-id="${id}"]`) ?? null;
async function cardButton(id, action, ms = 3000) { for (let t = 0; t <= ms; t += 100) { const b = cardEl(id)?.querySelector?.(`[data-action="${action}"]`); if (b) return b; await sleep(100); } return null; }
/** Visioner draws its panel with the card and binds its click handler a moment later, with what the page's canvas shows then: a card drawn while this
    page viewed another scene (after a reload, before the fight's map opened) has a panel that finds no token and changes nothing, and a press before the
    handler is bound does nothing at all (both seen live, 2026-11-07). So the card is drawn again with the fight's map open, the handler waited for, and
    the press counted only if Visioner took it (it marks the button "processing" at once); a press it didn't take changed nothing and is tried again. */
const boundPanel = b => { const p = b?.closest?.(".pf2e-visioner-automation-panel"); return !!p && !!window.jQuery?._data?.(p, "events")?.click?.length; };
async function freshButton(id, action) {
  const m = game.messages.get(id); if (!m) return null;
  await redrawn(id, () => ui.chat.updateMessage(m));
  for (let t = 0; t <= 3000; t += 100) { const b = cardEl(id)?.querySelector?.(`[data-action="${action}"]`); if (b && boundPanel(b)) return b; await sleep(100); }
  return cardEl(id)?.querySelector?.(`[data-action="${action}"]`) ?? null;
}
async function press(id, action) {
  for (let k = 0; k < 10; k++) {
    const b = k ? cardEl(id)?.querySelector?.(`[data-action="${action}"]`) : await freshButton(id, action); if (!b) return null;
    b.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    if (b.classList.contains("processing")) return b;
    await sleep(300);
  }
  throw new Error(`Visioner didn't take the press on its ${action} button.`);
}
/** Press Visioner's Apply Changes on a card and wait for its answer: "applied" (Visioner turned the pressed button into Revert), "none" (it found nothing
    to change), or null if the button isn't there. Visioner marks the button "processing" while it works (synchronously, so a press can't run twice) and
    takes that off when done, on the pressed button itself even if the card has been redrawn meanwhile; a redrawn card always shows Apply again, because
    Visioner's panels never draw Revert, so only the pressed button tells. */
async function applyOnCard(id, kind) {
  const b = await press(id, `apply-now-${kind}`); if (!b) return null;
  for (let t = 0; t < STEP_MS; t += 100) {
    if (!b.classList.contains("processing")) return b.dataset.action === `revert-now-${kind}` ? "applied" : "none";
    await sleep(100);
  }
  throw new Error(`Visioner's ${kind} result didn't come within ${STEP_MS / 1000} seconds.`);
}
/** Run a change to a card and wait until the chat log has drawn it again, so a button found after it is the new one. */
async function redrawn(id, change) {
  const old = cardEl(id); await change();
  for (let t = 0; t < 3000 && cardEl(id) === old; t += 100) await sleep(100);
}
/** A Seek's area in Visioner's own terms: a circle at a grid corner, or a cone from the monster's centre toward a square's centre. */
function seekArea(aim, tok, scene) {
  const px = scene.grid.size, d = scene.dimensions, at = sq => ({ x: d.sceneX + sq[0] * px, y: d.sceneY + sq[1] * px });
  if (aim.type === "burst") return { center: at(aim.corner), radiusFeet: aim.size, templateType: "circle", hasTargets: true };
  const c = tok.object.center, to = at([aim.toward[0] + .5, aim.toward[1] + .5]);
  return { center: { x: c.x, y: c.y }, radiusFeet: aim.size, templateType: "cone", geometry: { direction: Math.atan2(to.y - c.y, to.x - c.x) * 180 / Math.PI, angle: 90 }, hasTargets: true };
}
/** Put Visioner's own stored states back as a Sneak's start, where its Start Sneak recorded something else. */
async function fixSneakStart(message, tok) {
  const vis = visionerApi(), f = message.flags?.[VISIONER] ?? {}, change = {};
  for (const [oid, st] of Object.entries(f.sneakStartStates ?? {})) {
    let real; try { real = vis.getVisibility(oid, tok.id) ?? "observed"; } catch { real = "observed"; }
    if (st?.visibility === real) continue;
    change[`flags.${VISIONER}.sneakStartStates.${oid}.visibility`] = real;
    if (f.startStates?.[oid]) change[`flags.${VISIONER}.startStates.${oid}.visibility`] = real;
  }
  if (Object.keys(change).length) await message.update(change);
  return Object.keys(change).length;
}
async function runStealth(combat, id, i, step, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {}, kind = step.do, word = STEALTH_WORD[kind];
  const toGm = async (why) => { await record({ gm: true }); await addNote(combat, id, `${why} ${kind === "sneak" ? `Press Start Sneak on its card, move ${tok.name} to square ${step.to[0]}, ${step.to[1]}, then apply its results` : `Apply its results from its card${kind === "seek" ? ` (only creatures in the ${step.aim.size}-foot ${step.aim.type} it searched)` : ""}`}.`); return "gm"; };
  for (let guard = 0; guard < 10; guard++) {
    const now = nextStealth(get(), kind);
    if (now === "next") return "next";
    if (now === "gm") return "gm";
    if (now === "ask") { await addNote(combat, id, `${tok.name}'s ${word} card may not have been posted.`); return "ask"; }
    if (now === "move") { const moved = await runStride(combat, id, i, step, tok); if (moved !== "next") return moved; continue; }
    if (!stepGate(`${kind}-${now}`, id)) return "stopped";
    if (!(await ensureScene(combat) && tok.object)) throw new Error(cantOpen());
    const msgId = get().card?.message, message = msgId ? game.messages.get(msgId) : null;
    if (now === "roll") {
      await record({ rollStarted: true });
      pending = { tokenId: tok.id, waiters: new Map() };
      stopAiming();   /* PF2e would take a target left over from an earlier step into the check's roll options */
      let card; try { card = await watched(async () => { const c = waitForAny(["skill-check", "perception-check"]); await game.pf2e.actions.get(kind).use({ actors: [tok.actor], event: clickWith("showCheckDialogs") }); return c; }); }
      finally { pending = null; }
      await record({ card: { message: card.id } });
      if (!visionerApi()) return toGm(`Visioner is off, so the module can't apply ${tok.name}'s ${word}.`);
    } else if (now === "start" || now === "check-start") {
      if (!message) return toGm(`${tok.name}'s ${word} card is gone.`);
      if (now === "start") {
        if (!message.flags?.[VISIONER]?.sneakStartStates) {
          if (!(await freshButton(msgId, "start-sneak"))) return toGm(`Visioner's Start Sneak isn't on ${tok.name}'s Sneak card.`);
          await record({ startStarted: true });
          if (!(await press(msgId, "start-sneak"))) { await addNote(combat, id, `Visioner's Start Sneak went from ${tok.name}'s Sneak card before it was pressed.`); return "ask"; }
        } else await record({ startStarted: true });
      }
      /* Start Sneak writes sneakStartStates, sneakStartPosition, then startStates (which its results window reads): wait for all three before correcting */
      const started = () => { const f = game.messages.get(msgId)?.flags?.[VISIONER] ?? {}; return !!(f.sneakStartStates && f.sneakStartPosition && f.startStates); };
      for (let t = 0; t < STEP_MS && !started(); t += 100) await sleep(100);
      if (!started()) { await addNote(combat, id, `Visioner's Start Sneak didn't record ${tok.name}'s start.`); return "ask"; }
      await sleep(300);   /* its last write, then the panel's redraw */
      await fixSneakStart(game.messages.get(msgId), tok);
      await record({ startDone: true });
    } else if (now === "apply" || now === "check") {
      if (!message) return toGm(`${tok.name}'s ${word} card is gone.`);
      if (now === "check") {   /* begun before a reload: a Revert button survives only if the card wasn't redrawn, so usually the GM looks */
        if (await cardButton(msgId, `revert-now-${kind}`, 1500)) { await record({ applied: "applied" }); await rememberStealth(combat, tok, kind); continue; }
        await addNote(combat, id, `I can't tell whether Visioner applied ${tok.name}'s ${word}: look at its card (Open ${word} Results shows it).`); return "ask";
      }
      if (kind === "seek") await redrawn(msgId, () => message.update({ [`flags.${VISIONER}.seekTemplate`]: seekArea(step.aim, tok, sceneOf(combat)) }));   /* before the button, which must be the redrawn one: Visioner reads the flag when pressed */
      if (!(await freshButton(msgId, `apply-now-${kind}`))) return toGm(`Visioner's Apply Changes isn't on ${tok.name}'s ${word} card.`);
      await record({ applyStarted: true });
      const got = await watched(() => applyOnCard(msgId, kind));
      if (!got) { await addNote(combat, id, `Visioner's Apply Changes went from ${tok.name}'s ${word} card before it was pressed.`); return "ask"; }
      await record({ applied: got });
      await rememberStealth(combat, tok, kind);
    }
  }
  return "ask";
}
/** What the monster knows it last did to hide, for its packet; forgotten once it comes out of hiding. A Seek isn't hiding. */
async function rememberStealth(combat, tok, kind) { if (kind !== "seek") await saveTurns(combat, { [`stealth.${tok.id}`]: { did: kind, round: combat.round } }); }
/** Who it is hidden from or undetected by in Visioner now: every other creature not hidden by the GM, allies too (Visioner's own Hide can hide it from
    them when its "ignore allies" setting is off, seen live 2026-11-07). */
function hiddenFromWho(tok) {
  const vis = visionerApi(); if (!vis) return [];
  return tok.parent.tokens.contents.filter(t => { if (t.id === tok.id || t.hidden || !t.object || !t.actor?.isOfType?.("creature")) return false;
    try { return HIDDEN.includes(vis.getVisibility(t.id, tok.id)); } catch { return false; } });
}
/** Out of hiding (Rhea, 2026-11-07, A): a hidden or undetected monster becomes observed by those creatures just before an action other than Hide, Sneak
    or Step, and after an attack (which keeps its off-guard for that attack). After an attack Visioner's own Attack Consequences on its card goes first;
    otherwise Visioner's public setVisibility. The GM can hide it again in Visioner's manager. With Visioner's automatic system on, Visioner decides. */
async function comeOut(combat, id, tok, why, cardId = null) {
  /* what it knows it tried is forgotten at any revealing action, whether or not anyone had it hidden: keeping it only when a Hide failed would tell the
     thinker the secret result */
  if (turns(combat).stealth?.[tok.id]) await saveTurns(combat, { [`stealth.${tok.id}`]: foundry.data.operators.ForcedDeletion.create() });
  const who = hiddenFromWho(tok); if (!who.length) return;
  if (game.settings.get(VISIONER, "autoVisibilityEnabled")) return addNote(combat, id, `${tok.name} was hidden before ${why}; Visioner's automatic visibility decides whether {they} still {is|are}.`);
  let left = who;
  if (cardId) { try { if (await applyOnCard(cardId, "consequences")) left = hiddenFromWho(tok); } catch (e) { console.warn(`${ID} | consequences`, e); } }
  const vis = visionerApi(); for (const t of left) await vis.setVisibility(t.id, tok.id, "observed");
  await addNote(combat, id, `${tok.name} was hidden from ${listWords(who.map(t => t.name))}, and ${why} makes {them} observed by them (hide {them} again in Visioner's manager to allow a quiet action).`);
}
/** A creature the brief starts hidden (B-7, 0.33.2). The build hides it from everyone (Foundry's own hidden), which nothing in a fight reads as hiding:
    no off-guard for its attacks, and nothing ends it. At the fight's start (once, on the runner) it is hidden in Visioner instead, from each creature on
    the other side, by its Stealth initiative against that creature's Perception DC, as Visioner's own stealth-initiative rule reads Avoid Notice: at or
    above the DC undetected, above DC − 10 hidden, otherwise observed. With no initiative yet it is hidden from them. Then Foundry's hidden comes off, so
    each player sees what Visioner shows them and its first revealing action brings it out (`comeOut`, Rhea's rule A). With Visioner off nothing
    changes. The build rolls these creatures' initiative on Stealth (`system.initiative.statistic`). */
async function hiddenAtStart(combat) {
  if (!combat.started || turns(combat).hidStart || startingHidden.has(combat.id)) return;
  const vis = visionerApi(), scene = sceneOf(combat); if (!vis || !scene) return;
  const toks = combat.combatants.contents.map(c => ({ c, t: scene.tokens.get(c.tokenId) })).filter(x => x.t?.hidden && x.t.getFlag(ID, "startHidden"));
  startingHidden.add(combat.id);
  if (!toks.length) return saveTurns(combat, { hidStart: true }).finally(() => startingHidden.delete(combat.id));
  try {
    if (!await ensureScene(combat)) return;
    const said = [];
    for (const { c, t } of toks) {
      const init = Number.isFinite(c.initiative) ? c.initiative : null, from = [];
      /* the d20 of its initiative roll, for the natural 20 and 1 (a degree up or down, as for any check) */
      const die = game.messages.contents.findLast(m => m.flags?.core?.initiativeRoll && m.speaker?.token === t.id)?.rolls?.[0]?.dice?.[0]?.total ?? null;
      for (const o of scene.tokens.contents) { if (o.id === t.id || o.hidden || !o.actor?.isOfType?.("creature") || o.actor.isAllyOf?.(t.actor)) continue;
        const dc = o.actor.perception?.dc?.value ?? o.actor.system?.perception?.dc ?? null;
        let deg = init == null || !Number.isFinite(dc) ? 1 : init >= dc + 10 ? 3 : init >= dc ? 2 : init > dc - 10 ? 1 : 0;
        if (init != null && die === 20) deg = Math.min(3, deg + 1); else if (init != null && die === 1) deg = Math.max(0, deg - 1);
        const state = deg >= 2 ? "undetected" : deg === 1 ? "hidden" : "observed";
        if (state !== "observed") await vis.setVisibility(o.id, t.id, state);
        from.push(`${o.name} ${state}`); }
      await t.update({ hidden: false });
      said.push(`${t.name} (Stealth ${init ?? "not rolled"}): ${from.join(", ") || "nobody to hide from"}`); }
    await saveTurns(combat, { hidStart: true, hidStartWords: said.join("; ") });
  } finally { startingHidden.delete(combat.id); }
}
const startingHidden = new Set();
/** A card made by a creature the party can't see (B-8, 0.33.2): marked on the page that makes it (`preCreateChatMessage`), and in a player's browser its
    sender is "An unseen creature" with no portrait, as its spoken lines are "A voice". Only for a creature in a fight that no player owns. */
export function markUnseen(message) {
  const sp = message.speaker ?? {}, tok = sp.token ? game.scenes.get(sp.scene)?.tokens.get(sp.token) : null;
  if (!tok || tok.actor?.hasPlayerOwner || !fightOf(tok)) return;
  try { if (unseenByParty(tok)) message.updateSource({ [`flags.${ID}.unseen`]: true }); } catch (e) { console.warn(`${ID} | unseen`, e); }
}
export function maskUnseen(message, html) {
  if (game.user.isGM || !message.getFlag?.(ID, "unseen")) return;
  for (const el of html.querySelectorAll?.(".message-sender") ?? []) el.textContent = "An unseen creature";
  /* the header's portrait, whose picture and alt text are the creature's. PF2e 8.7.0 adds it in its own renderHTML after Foundry's render hooks
     have run (seen live 2026-11-15: gone at this hook, back once the card was drawn), so it is taken out again just after */
  const strip = () => { for (const el of html.querySelectorAll?.(".message-header .portrait, .message-header > img") ?? []) el.remove(); html.querySelector?.(".message-header")?.classList.remove("with-image"); };
  strip(); setTimeout(strip, 0);
}
const actWords = step => step.do === "draw" ? `drawing {their} ${step.itemName ?? "weapon"}` : step.do === "say" ? "giving {themself} up" : step.do === "command-animal" ? "commanding an animal" : step.do === "point-out" ? "pointing a creature out" : step.do === "stride" ? "{their} Stride" : step.do === "crawl" ? "{their} Crawl" : step.do === "stand" ? "standing up" : step.do === "drop-prone" ? "dropping prone" : step.do === "take-cover" ? "Taking Cover" : step.do === "interact" ? "{their} Interact" : step.do === "climb" ? "{their} Climb" : step.do === "burrow" ? "burrowing" : step.do === "release" ? "letting go of what {they} {holds|hold}" : step.do === "seek" ? "{their} Seek" : step.do === "spell" ? `casting ${step.itemName}` : step.do === "ability" ? `using ${step.itemName}` : step.do === "strike" ? `{their} ${step.itemName}` : "acting";
function savedDegree(message, tokenId) {
  for (const v of Object.values(message?.flags?.[TOOLBELT]?.targetHelper?.saveVariants ?? {})) { const s = v?.saves?.[tokenId]; if (s?.success in DEGREE) return DEGREE[s.success]; }
  return null;
}
/** Toolbelt's button that rolls this creature's save on the card in this page's chat log: the d20 for creatures no player owns, otherwise its row's own.
    Rows carry no token id, so they're matched in Toolbelt's own order for a GM (no player owner first, then by name; its createTargetsRows) and the name
    is checked. Null if it can't be found. */
async function saveButton(message, target, npc) {
  let el = null; for (let t = 0; t < 3000 && !(el = ui.chat?.element?.querySelector?.(`[data-message-id="${message.id}"]`)); t += 200) await new Promise(r => setTimeout(r, 200));
  if (!el) return null;
  if (npc) { const b = el.querySelector(".pf2e-toolbelt-target-rollSaves"); if (b) return b; }
  const toks = (message.flags?.[TOOLBELT]?.targetHelper?.targets ?? []).map(u => fromUuidSync(u)).filter(Boolean);
  const order = toks.map((t, k) => ({ t, k })).sort((a, b) => (a.t.hasPlayerOwner - b.t.hasPlayerOwner) || (a.t.name < b.t.name ? -1 : a.t.name > b.t.name ? 1 : a.k - b.k)).map(x => x.t);
  const rows = [...el.querySelectorAll(".pf2e-toolbelt-target-targetRows .target-row")], nameOf = r => r.querySelector(".name")?.textContent.trim() ?? "";
  let row = rows[order.findIndex(t => t.id === target.id)];
  if (!row || nameOf(row) !== target.name) { const same = rows.filter(r => nameOf(r) === target.name); row = same.length === 1 ? same[0] : null; }
  return row?.querySelector("[data-action=roll-save]") ?? null;
}
/** Roll a creature's save on the card through Toolbelt's own button, with the user's dialog rule (Shift flips it, as for Strikes), and wait for the result. */
async function rollSaveOnCard(message, target) {
  const npc = !target.actor?.hasPlayerOwner, button = await saveButton(message, target, npc);
  if (!button) throw new Error(`I couldn't find Toolbelt's save button for ${target.name} on the spell's card.`);
  button.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, shiftKey: !!game.user.settings?.showCheckDialogs }));
  for (let t = 0; t < 12000; t += 250) { await new Promise(r => setTimeout(r, 250)); const d = savedDegree(game.messages.get(message.id), target.id); if (d != null) return d; }
  return null;
}
const SAVE_WORD = s => s[0].toUpperCase() + s.slice(1);
/** The save stage: the target's save from its row, rolled by the module for a creature no player owns, one whose player is offline, or when the GM pressed
    Roll it for them; otherwise "wait" for the player. "saved" once it's in. */
async function awaitSave(combat, id, i, step, tok, target) {
  const get = () => request(combat, id).log?.[i] ?? {}, card = game.messages.get(get().cast?.message);
  if (!card) { await addNote(combat, id, `${step.itemName}'s card is gone, so I can't read ${step.target}'s save.`); return "ask"; }
  if (!card.flags?.[TOOLBELT]?.targetHelper) { await save(combat, id, { log: { [i]: { noRows: true } }, note: joinNote(combat, id, `${step.itemName}'s card has no target rows (is Toolbelt's Target Helper on?): roll ${step.target}'s save and apply it yourself.`) }); return "gm"; }
  let degree = savedDegree(card, target.id);
  if (degree == null) {
    const asked = !!request(combat, id).rollFor?.[target.id], npc = !target.actor?.hasPlayerOwner, rolled = get().rollStarted ?? 0;
    if (asked || (!rolled && (npc || !ownerOnline(target.actor)))) {
      if (!stepGate("save", id)) return "stopped";
      if (!(await ensureScene(combat) && tok.object)) throw new Error(cantOpen());
      await saveTurns(combat, { [`requests.${id}.log.${i}.rollStarted`]: rolled + 1, [`requests.${id}.log.${i}.waiting`]: [target.id], ...(asked ? { [`requests.${id}.rollFor.${target.id}`]: null } : {}) });
      degree = await watched(() => rollSaveOnCard(card, target));
    }
  }
  if (degree == null) { if (!get().waiting) await save(combat, id, { log: { [i]: { waiting: [target.id] } } }); return "wait"; }
  const gm = !step.damaging || !step.basic ? `Apply ${step.itemName} for ${step.target}'s ${CHECK_OUTCOMES[degree]} ${SAVE_WORD(step.save)} save from its card.`
    : step.critText ? `Anything ${step.itemName}'s text gives for ${step.target}'s ${CHECK_OUTCOMES[degree]} beyond its damage is yours to apply from its card.` : null;
  /* the result, a Roll it for them it made unnecessary, and the GM's note in one save */
  await saveTurns(combat, { [`requests.${id}.log.${i}.save`]: { degree }, [`requests.${id}.log.${i}.waiting`]: null, [`requests.${id}.rollFor.${target.id}`]: null, ...(gm ? { [`requests.${id}.note`]: joinNote(combat, id, gm) } : {}) });
  return "saved";
}
const cardWords = (step) => `Apply ${step.itemName}${step.area ? `: place its ${step.area.size}-foot ${step.area.type}${step.target ? ` aimed at ${step.target}` : ""} from its card and resolve it` : `${step.target ? ` at ${step.target}` : ""} from its card`}.`;
async function runSpell(combat, id, i, step, tok, target) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {};
  const found = spellFor(tok.actor, step); if (!found) throw new Error(`${tok.name} has no ${step.itemName} now.`);
  const { entry, spell } = found;
  for (let guard = 0; guard < 12; guard++) {
    const now = nextSpell(get(), { mode: step.mode, flat: step.flat ?? 0, apply: applySetting(), damaging: step.damaging, basic: step.basic });
    if (now === "next" || now === "gm" || now === "ask") return now;
    if (now === "save") { const s = await awaitSave(combat, id, i, step, tok, target); if (s === "saved") continue; return s; }
    if (!stepGate(now, id)) return "stopped";
    if (now !== "apply" && !(await ensureScene(combat) && tok.object && (!target || target.object))) throw new Error(cantOpen());   /* applying needs no canvas */
    pending = { tokenId: tok.id, waiters: new Map(), all: true };
    try {
      if (now === "cast") {
        if (target) aimAt(target); else stopAiming();   /* Toolbelt puts a row on the card for each of the runner's targets */
        await record({ castStarted: true });
        const message = await watched(async () => { const card = waitFor("spell-cast"); await entry.cast(spell, { rank: step.rank, consume: true }); return card; });
        /* the record and the GM's instruction in one save, so a reload can't keep one without the other */
        await save(combat, id, { log: { [i]: { cast: { message: message.id } } }, ...(step.mode === "card" ? { note: joinNote(combat, id, cardWords(step)) } : {}) });
      } else if (now === "flat") {
        await record({ flatStarted: true });
        const roll = await watched(async () => { const r = await new Roll("1d20").evaluate(); await r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Flat check, DC ${step.flat}` }); return r; });
        await record({ flat: { dc: step.flat, total: roll.total, ok: roll.total >= step.flat } });
        if (roll.total < step.flat) await addNote(combat, id, `${step.itemName} at ${step.target} failed its DC ${step.flat} flat check (${roll.total}): it doesn't affect them.`);
      } else if (now === "attack") {
        aimAt(target); await record({ started: true });
        const { message, roll } = await watched(async () => { const card = waitForAny(["spell-attack-roll", "attack-roll"]), roll = await spell.rollAttack(clickWith("showCheckDialogs"), (step.variant ?? 0) + 1); return { message: await card, roll }; });
        const degree = roll?.degreeOfSuccess ?? message.rolls?.[0]?.degreeOfSuccess ?? null;
        if (degree == null) { await addNote(combat, id, `${step.itemName}'s attack card has no result (did it have a target?).`); return "ask"; }   /* never a silent critical miss */
        const gm = degree >= 2 && !step.damaging ? `Apply ${step.itemName}'s ${OUTCOMES[degree]} at ${step.target} from its card.`
          : degree >= 2 && step.critText ? `${step.itemName} ${degree === 3 ? "critically hit" : "hit"} ${step.target}${degree === 3 && applySetting() ? ": its damage is doubled" : ""}; anything else its ${degree === 3 ? "critical success" : "success"} gives is yours to apply from its card.` : null;
        /* PF2e rolls a spell attack's damage as a hit: with automatic damage off, the GM doubles it */
        const double = degree === 3 && step.damaging && !applySetting() ? `It was a critical hit: use Double on ${step.itemName}'s damage card.` : null;
        const words = [gm, double].filter(Boolean).join(" ");
        await save(combat, id, { log: { [i]: { attack: { message: message.id, degree } } }, ...(words ? { note: joinNote(combat, id, words) } : {}) });
      } else if (now === "damage") {
        /* a spell attack's hit (0.27.0): Shield Block against its physical damage, asked before the damage as for a Strike */
        if (step.mode === "attack") { let hr; try { hr = await hitGate(combat, id, i, step, tok, target, { melee: false, damageTypes: Object.values(spell.system.damage ?? {}).map(d => d?.type).filter(Boolean), kind: step.itemName }, get); } catch (e) { console.error(`${ID} | reactions`, e); hr = null; await addNote(combat, id, `I couldn't ask the reactions to ${step.itemName}'s hit (${e.message}); damage went ahead.`); }
          if (hr === "manual") return "next"; if (hr === "held" || hr === "gone") return hr; }
        aimAt(target); await record({ damageStarted: true });
        /* the damage at the rank it was cast at (PF2e reads that from the card's button, which a script has none of) */
        const message = await watched(async () => { const card = waitFor("damage-roll"); const v = (step.rank !== spell.rank ? spell.loadVariant?.({ castRank: step.rank }) : null) ?? spell; await v.rollDamage(clickWith("showDamageDialogs"), step.mode === "attack" ? step.variant ?? 0 : undefined); return card; });
        await record({ damage: { message: message.id } });
        if (applySetting()) await markApplied(message);
        else { const hb = await harmByHand(combat, id, i, tok, [{ target, hit: Math.floor((message.rolls?.[0]?.total ?? 0) * spellMultiplier(step, get())), block: !!get().shieldBlock }]); if (hb === "manual") return "next"; if (hb === "held" || hb === "gone") return hb; }
      } else if (now === "apply") {
        const message = game.messages.get(get().damage.message), roll = message?.rolls?.[0]; if (!roll) return "ask";
        const mult = spellMultiplier(step, get()), hit = Math.floor(roll.total * mult), hg = await harmGate(combat, id, i, tok, [{ target, hit }]);   /* Glimpse of Redemption (0.27.0) */
        if (hg === "manual") return "next"; if (hg === "held" || hg === "gone") return hg;
        const hm = harmFor(combat, id, i, target, hit);
        await record({ applying: true }); const was = hpNow(target);
        if (!hm.repent) await watched(() => applyFromCard(message, roll, target, mult, !!get().shieldBlock, hm));
        await record({ applied: true, hp: [was, hpNow(target)] });
        await afterHarm(combat, id, i, tok, target, { hit, was, block: !!get().shieldBlock });
        if (target.actor?.isOfType?.("character") && target.actor.hitPoints?.value === 0) await addNote(combat, id, `${target.name} is at 0 HP. If you undo this, PF2e restores the HP but you still need to remove Wounded and Prone and put their initiative back.`);
      }
    } finally { pending = null; }
  }
  return "ask";
}
/* ---------- areas (Rhea, 2026-11-07) ----------
   The module places PF2e's own area for a monster's area spell: the Region PF2e's Place button makes (placeRegionFromItem in 8.7.0: a circle for a burst,
   a 90° cone, a line one square wide, an emanation round the caster's token, "coverage" highlighting, PF2e's messageId, origin and areaShape flags, which
   Visioner reads to give each creature its cover on the Reflex save from the area's origin). Who it catches is decided by Foundry's own test of each
   square's centre (what the highlighted squares show), and line of effect is stopped only by solid walls, never trunks. */
const SOLID_SIGHT = (CONST.EDGE_SENSE_TYPES ?? CONST.WALL_SENSE_TYPES).NORMAL, SOLID_MOVE = CONST.WALL_MOVEMENT_TYPES.NORMAL;
/** Solid walls, in squares: ones that block both movement and sight. Never Survey Sheet's trunks (they give cover to the save instead), never an open door. */
function solidWalls(scene) {
  const g = scene.grid.size, X = scene.dimensions.sceneX, Y = scene.dimensions.sceneY;
  return scene.walls.contents.filter(w => w.move === SOLID_MOVE && w.sight === SOLID_SIGHT && w.flags?.["lythara-survey-sheet"]?.enc !== "trunk" && !(w.door && w.ds === CONST.WALL_DOOR_STATES.OPEN))
    .map(w => [[(w.c[0] - X) / g, (w.c[1] - Y) / g], [(w.c[2] - X) / g, (w.c[3] - Y) / g]]);
}
/** A shape in squares (area.mjs's shapeOf) as a Region shape in pixels. A token shape's width and height stay in squares. */
function shapePx(shape, scene, tok) {
  const g = scene.grid.size, X = scene.dimensions.sceneX, Y = scene.dimensions.sceneY, out = { ...shape };
  if ("x" in shape) { out.x = X + shape.x * g; out.y = Y + shape.y * g; }
  for (const k of ["radius", "length"]) if (k in shape) out[k] = shape[k] * g;
  if (shape.type === "line") out.width = shape.width * g;
  if (shape.type === "emanation") { delete out.x; delete out.y; out.base = { ...shape.base, x: X + shape.base.x * g, y: Y + shape.base.y * g, shape: tok.shape }; }
  return out;
}
/** What an aim covers and catches on the scene as it stands, writing nothing: a Region made in memory only, Foundry's own test on each square's centre.
    from: { square, size } where the caster stands (after a move earlier in the plan). */
function coverage(scene, tok, aim, from) {
  const shape = shapePx(shapeOf(aim, from), scene, tok), doc = new foundry.documents.RegionDocument({ name: "area", shapes: [shape], levels: [] }, { parent: scene });
  const g = scene.grid.size, X = scene.dimensions.sceneX, Y = scene.dimensions.sceneY, covered = new Set();
  /* the same test as core's highlighted squares (Region#_getCoveredGridSpaceOffsets): a square's centre inside the shape, with its 0.75 px tolerance */
  for (const [x, y] of squaresNear(aim, from)) if (doc.polygonTree.testPoint({ x: X + (x + 0.5) * g, y: Y + (y + 0.5) * g }, 0.75)) covered.add(`${x},${y}`);
  /* a creature off the grid is tested where it really is, as Foundry tests a token against a placed Region (its containment test points), so the check
     and the area on the map agree; one on the grid by its squares, as before */
  const points = t => t.getContainmentTestPoints({ x: t.x, y: t.y, elevation: t.elevation, width: t.width, height: t.height, depth: t.depth, shape: t.shape }).map(p => [(p.x - X) / g, (p.y - Y) / g]);
  const creatures = scene.tokens.contents.filter(t => t.actor?.isOfType?.("creature") && !t.actor.isDead && !isBelow(t)).map(t => ({ id: t.id, square: t.id === tok.id ? from.square : squareOf(t, scene), size: sizeOf(t), ...spanOf(t, t.id === tok.id ? from.elev : null), ...(t.id !== tok.id && offGrid(t, scene) ? { points: points(t) } : {}) }));
  const walls = solidWalls(scene), insideAt = ([x, y]) => doc.polygonTree.testPoint({ x: X + x * g, y: Y + y * g }, 0.75);
  /* height (0.13.0): a burst starts on the ground at its corner; a cone, line or emanation at the caster's height */
  const casterElev = Number(from.elev ?? tok.elevation) || 0, originElev = aim.type === "burst" ? 0 : aim.type === "emanation" ? spanOf(tok, casterElev) : casterElev;
  return { shape, covered, reachable: burstReachable(aim, walls), ids: caughtBy(aim, covered, creatures, walls, tok.id, insideAt, originElev) };
}
/** The plan check's view of an area: who it catches, as labels the monster may know. Allies the GM hid, and creatures it doesn't perceive, are caught but
    never named to the thinker; their token ids go on the step for the GM's card only. now: what `sense` gave. */
function areaCheck(combat, tok, req, now) {
  const allyLabel = new Map(Object.entries(alliesByLabel(combat, tok)).map(([l]) => [tokenIdOf(combat, req, l), l]));
  const enemyLabel = new Map(Object.entries(req.labels ?? {}).filter(([, id]) => canTarget(now.get(id)?.state)).map(([l, id]) => [id, l]));
  return (sp, aimStep, from, target) => {
    const r = aimArea(sp.area, aimStep, from, target); if (!r.ok) return r;
    const { ids, reachable } = coverage(sceneOf(combat), tok, r.aim, from);
    if (!reachable) return { ok: false, reason: `a solid wall stands between it and the corner [${r.aim.corner[0]}, ${r.aim.corner[1]}], so the burst can't start there.` };
    return { ok: true, aim: r.aim, ids, allies: alliesCaught(ids, id => allyLabel.get(id) ?? null), self: allyLabel.get(tok.id) ?? null, known: ids.map(id => enemyLabel.get(id)).filter(Boolean) };
  };
}
/** Target every creature in a list on the runner's own account, so Toolbelt gives each a row on the card. */
function aimAll(tokens) {
  stopAiming();
  for (const t of tokens.filter(Boolean)) t.object?.setTarget(true, { user: game.user, releaseOthers: false, groupSelection: true });
}
const areaFlag = (combat, id, i) => r => { const a = r.flags?.[ID]?.area; return a?.combat === combat.id && a.request === id && a.step === i; };
/** PF2e's own Region for the cast, found again if it already exists (safe after a reload). */
async function placeArea(combat, id, i, step, tok, spell, message) {
  const scene = sceneOf(combat), had = scene.regions.find(areaFlag(combat, id, i)); if (had) return had;
  const from = { square: squareOf(tok, scene), size: sizeOf(tok) }, shape = shapePx(shapeOf(step.area.aim, from), scene, tok);
  const origin = { name: spell.name, slug: spell.slug, traits: foundry.utils.deepClone(spell.system.traits?.value ?? []), ...(spell.getOriginData?.() ?? {}) };
  const [made] = await scene.createEmbeddedDocuments("Region", [{ name: spell.name, shapes: [shape], levels: canvas.level ? [canvas.level.id] : [], color: game.user.color.toString(),
    highlightMode: "coverage", displayMeasurements: false, visibility: CONST.REGION_VISIBILITY.ALWAYS,
    /* Toolbelt's Template Helper opens its "target the tokens in this area?" dialog for any spell area its own user creates; on the runner's page nobody can
       click it (found live 2026-11-07), and the module targets the creatures itself, so it's told to skip (its own flag, read in its createRegion hook) */
    flags: { pf2e: { messageId: message?.id ?? null, origin, areaShape: spell.system.area?.type ?? step.area.type }, [TOOLBELT]: { targetHelper: { skip: true } }, [ID]: { area: { combat: combat.id, request: id, step: i, mode: step.mode, lasting: !!step.lasting } } } }]);
  return made;
}
/** Instant areas go once they're done (Rhea, 2026-11-07); lasting ones stay for the GM. This drops instant card-mode areas, which the GM resolves from
    the card, once the turn goes on (keep: the request and step from which areas still matter). An area the module resolves removes itself when it's done;
    one left unresolved (the turn moved on during its saves) stays for the GM. */
async function dropInstantAreas(combat, keep = null) {
  const ids = sceneOf(combat)?.regions.filter(r => { const a = r.flags?.[ID]?.area; return a?.combat === combat.id && !a.lasting && a.mode !== "area" && !(keep && a.request === keep.id && a.step >= (keep.pos ?? 0)); }).map(r => r.id) ?? [];
  if (ids.length) await sceneOf(combat).deleteEmbeddedDocuments("Region", ids);
}
/** Roll several creatures' saves on a card through Toolbelt's own buttons: the d20 once for those no player owns, then each player's row. Waits for all. */
async function rollSavesOnCard(message, targets) {
  const shift = !!game.user.settings?.showCheckDialogs, click = b => b.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, shiftKey: shift }));
  const settled = async list => { for (let t = 0; t < 12000; t += 250) { await new Promise(r => setTimeout(r, 250)); const m = game.messages.get(message.id); if (list.every(x => savedDegree(m, x.id) != null)) return true; } return false; };
  const npcs = targets.filter(t => !t.actor?.hasPlayerOwner), rows = targets.filter(t => t.actor?.hasPlayerOwner);
  /* Toolbelt's d20 rolls every creature no player owns that hasn't saved yet; without it, each one's own row */
  if (npcs.length) { const b = await saveButton(message, npcs[0], true); if (!b) throw new Error(`I couldn't find Toolbelt's save button on the spell's card.`);
    if (b.classList.contains("pf2e-toolbelt-target-rollSaves")) { click(b); await settled(npcs); } else rows.unshift(...npcs); }
  for (const t of rows) { const b = await saveButton(message, t, false); if (!b) throw new Error(`I couldn't find ${t.name}'s row on the spell's card.`); click(b); await settled([t]); }
}
/** Everyone's saves on an area's card: rolled by the module for creatures no player owns, offline players, and any the GM asked it to roll; a player online
    rolls their own and the turn waits ("wait"), with no timer. "saved" once all are in. */
async function awaitAreaSaves(combat, id, i, step, tok) {
  const get = () => request(combat, id).log?.[i] ?? {}, scene = sceneOf(combat), card = game.messages.get(get().cast?.message);
  if (!card) { await addNote(combat, id, `${step.itemName}'s card is gone, so I can't read the saves.`); return "ask"; }
  if (!card.flags?.[TOOLBELT]?.targetHelper) { await save(combat, id, { log: { [i]: { noRows: true } }, note: joinNote(combat, id, `${step.itemName}'s card has no target rows (is Toolbelt's Target Helper on?): roll the saves and apply it yourself.`) }); return "gm"; }
  const rows = get().rows ?? [], missing = () => rows.filter(t => savedDegree(game.messages.get(card.id), t) == null);
  const asked = request(combat, id).rollFor ?? {}, rolled = get().rollStarted ?? 0;
  const mine = missing().map(t => scene.tokens.get(t)).filter(t => t && (asked[t.id] || (!rolled && (!t.actor?.hasPlayerOwner || !ownerOnline(t.actor)))));
  if (mine.length) {
    if (!stepGate("save", id)) return "stopped";
    if (!(await ensureScene(combat) && tok.object)) throw new Error(cantOpen());
    /* a Roll it for them for a creature whose save already landed is cleared too, so it doesn't restart the run again and again */
    await saveTurns(combat, { [`requests.${id}.log.${i}.rollStarted`]: rolled + 1, [`requests.${id}.log.${i}.waiting`]: missing(), ...Object.fromEntries(Object.keys(asked).filter(t => asked[t] && (mine.some(x => x.id === t) || !missing().includes(t))).map(t => [`requests.${id}.rollFor.${t}`, null])) });
    await watched(() => rollSavesOnCard(card, mine));
  }
  const left = missing().filter(t => scene.tokens.get(t));   /* a creature removed from the map while waiting has nothing left to save */
  if (left.length) { await save(combat, id, { log: { [i]: { waiting: left } } }); return "wait"; }
  const r = request(combat, id), m = game.messages.get(card.id), saves = Object.fromEntries(rows.filter(t => scene.tokens.get(t)).map(t => [t, savedDegree(m, t)]));
  /* what the monster learns: the saves of creatures it knows of, by label */
  const known = new Map([...Object.entries(r.labels ?? {}).map(([l, t]) => [t, l]), ...Object.entries(alliesByLabel(combat, tok)).map(([l]) => [tokenIdOf(combat, r, l), l])]);
  const results = Object.entries(saves).filter(([t]) => known.has(t)).map(([t, d]) => `${known.get(t)} ${CHECK_OUTCOMES[d]}`).join(", ");
  let gm = step.critText ? `Anything ${step.itemName}'s text gives beyond its damage for each degree is yours to apply from its card.` : null;
  /* Interposing Earth's barrier outlives a save that takes no damage: since 0.35.0 it stands on the map (Rhea, q-36), between the caster and the monster */
  const stands = (r.gates?.[i]?.before?.list ?? []).filter(x => x.answer === "done" && x.slug === "interposing-earth" && !(SAVE_MULT[saves[x.token]] > 0));
  for (const x of stands) { const caster = scene.tokens.get(x.token); if (caster) await raiseBarrier(combat, id, i, caster, tok, x.spell?.rank).catch(e => { console.error(`${ID} | barrier`, e); gm = [gm, `${x.name}'s earth barrier should stand for 3 rounds, but I couldn't put it on the map (${e.message}): yours to rule on.`].filter(Boolean).join(" "); }); }
  await saveTurns(combat, { [`requests.${id}.log.${i}.saves`]: saves, [`requests.${id}.log.${i}.rows`]: Object.keys(saves), [`requests.${id}.log.${i}.waiting`]: null, [`requests.${id}.log.${i}.results`]: results,
    ...Object.fromEntries(rows.map(t => [`requests.${id}.rollFor.${t}`, null])), ...(gm ? { [`requests.${id}.note`]: joinNote(combat, id, gm) } : {}) });
  return "saved";
}
/** An area spell (Rhea, 2026-11-07): cast with every caught creature targeted, PF2e's area placed, then for a damaging basic save everyone's save and the
    damage by degree; anything else is the GM's from the card. Stages from nextArea; nothing repeats. */
async function runArea(combat, id, i, step, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {}, scene = sceneOf(combat);
  const found = spellFor(tok.actor, step); if (!found) throw new Error(`${tok.name} has no ${step.itemName} now.`);
  const { entry, spell } = found;
  for (let guard = 0; guard < 40; guard++) {
    const now = nextArea(get(), { mode: step.mode, apply: applySetting(), lasting: !!step.lasting });
    if (now === "next" || now === "gm" || now === "ask") return now;
    if (now === "save") { const s = await awaitAreaSaves(combat, id, i, step, tok); if (s === "saved") continue; return s; }
    if (!stepGate(now, id)) return "stopped";
    if (now !== "apply" && now !== "remove" && !(await ensureScene(combat) && tok.object)) throw new Error(cantOpen());   /* applying and removing need no canvas */
    pending = { tokenId: tok.id, waiters: new Map(), all: true };
    try {
      if (now === "cast") {
        /* who it catches from where it stands now; GM-hidden creatures get no row on a public card, so the GM resolves them */
        const { ids } = coverage(scene, tok, step.area.aim, { square: squareOf(tok, scene), size: sizeOf(tok), elev: Number(tok.elevation) || 0 });
        const rows = ids.filter(t => !scene.tokens.get(t)?.hidden), hidden = ids.filter(t => scene.tokens.get(t)?.hidden);
        aimAll(rows.map(t => scene.tokens.get(t)));
        await record({ castStarted: true, caught: ids, rows, ...(rows.length ? {} : { results: "" }) });
        const message = await watched(async () => { const card = waitFor("spell-cast"); await entry.cast(spell, { rank: step.rank, consume: true }); return card; });
        const names = list => listWords(list.map(t => scene.tokens.get(t)?.name ?? "someone"));
        const words = [step.mode === "card" ? `Apply ${step.itemName} from its card${rows.length ? ` to ${names(rows)}` : ""}: its area is on the map.` : null,
          hidden.length ? `It also caught ${names(hidden)}, hidden from the players, so they have no row: ${spell.system.defense?.save?.statistic ? `roll ${hidden.length === 1 ? "that save" : "those saves"} and apply` : "apply"} ${step.itemName} to ${hidden.length === 1 ? "them" : "those"} yourself.` : null].filter(Boolean).join(" ");
        await save(combat, id, { log: { [i]: { cast: { message: message.id } } }, ...(words ? { note: joinNote(combat, id, words) } : {}) });
      } else if (now === "place") {
        const made = await watched(() => placeArea(combat, id, i, step, tok, spell, game.messages.get(get().cast.message)));
        await record({ placed: { region: made.id } });
      } else if (now === "damage") {
        const hurt = areaHurt(get()); aimAll(Object.keys(hurt).map(t => scene.tokens.get(t)));
        await record({ damageStarted: true });
        const message = await watched(async () => { const card = waitFor("damage-roll"); const v = (step.rank !== spell.rank ? spell.loadVariant?.({ castRank: step.rank }) : null) ?? spell; await v.rollDamage(clickWith("showDamageDialogs")); return card; });
        /* with automatic damage off the GM applies it: say each creature's share, since the damage card isn't tied to the saves */
        const off = applySetting() ? null : `Apply ${step.itemName}'s damage from its card: ${listWords(Object.entries(hurt).map(([t, m]) => `${scene.tokens.get(t)?.name ?? "someone"} ${m === 2 ? "double" : m === 0.5 ? "half" : m === 0.25 ? "a quarter" : "full"}`))}.`;
        await save(combat, id, { log: { [i]: { damage: { message: message.id } } }, ...(off ? { note: joinNote(combat, id, off) } : {}) });
        if (applySetting()) await markApplied(message);
        else { const hb = await harmByHand(combat, id, i, tok, Object.entries(hurt).map(([x, m]) => ({ target: scene.tokens.get(x), hit: Math.floor((message.rolls?.[0]?.total ?? 0) * m) })).filter(h => h.target)); if (hb === "manual") return "next"; if (hb === "held" || hb === "gone") return hb; }
      } else if (now === "apply") {
        const rec = get(), hurt = areaHurt(rec), t = Object.keys(hurt).find(x => !rec.applied?.[x]), target = scene.tokens.get(t);
        const message = game.messages.get(rec.damage.message), roll = message?.rolls?.[0]; if (!roll) return "ask";
        if (!target) { await record({ applied: { [t]: true } }); continue; }   /* removed from the map: nothing to apply to */
        /* the party's reactions to the damage (0.27.0): one question for everyone it hurts, before any of it is applied (a champion picks which ally) */
        const hg = await harmGate(combat, id, i, tok, Object.entries(hurt).map(([x, m]) => ({ target: scene.tokens.get(x), hit: Math.floor(roll.total * m) })).filter(h => h.target));
        if (hg === "manual") return "next"; if (hg === "held" || hg === "gone") return hg;
        const hit = Math.floor(roll.total * hurt[t]), hm = harmFor(combat, id, i, target, hit);
        await record({ applying: { [t]: true } }); const was = hpNow(target);
        if (!hm.repent) await watched(() => applyFromCard(message, roll, target, hurt[t], false, hm));
        await afterHarm(combat, id, i, tok, target, { hit, was });
        /* its own area hurting itself (a deliberate burst it stands in) isn't news to the look before its next action: the record and the baseline in one save */
        const own = t === tok.id && request(combat, id).seen ? { [`requests.${id}.seen.me.hp`]: (tok.actor.hitPoints?.value ?? 0) + (tok.actor.hitPoints?.temp ?? 0) } : {};
        await saveTurns(combat, { [`requests.${id}.log.${i}.applied.${t}`]: true, [`requests.${id}.log.${i}.hp.${t}`]: [was, hpNow(target)], ...own });
        if (target.actor?.isOfType?.("character") && target.actor.hitPoints?.value === 0) await addNote(combat, id, `${target.name} is at 0 HP. If you undo this, PF2e restores the HP but you still need to remove Wounded and Prone and put their initiative back.`);
      } else if (now === "remove") {
        const r = scene.regions.find(areaFlag(combat, id, i)); if (r) await r.delete();
        await record({ removed: true });
      }
    } finally { pending = null; }
  }
  return "ask";
}
/** Roll it for them (the card's button for a save still waiting): from any GM's browser; the runner rolls it on the card through Toolbelt. */
export async function rollFor(combat, requestId, tokenId) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId); if (r?.state !== "saves") throw new Error("That turn isn't waiting for a save.");
  await save(combat, requestId, { rollFor: { [tokenId]: true } });   /* no "go": the runner acts on this only while the turn still waits for that save */
  if (isRunner()) return doIt(combat, requestId);
}
/** Whether a turn waiting on a save has it now (the save landed while the step was still deciding to wait). */
function saveArrived(combat, r) {
  const rec = r?.log?.[r.pos ?? 0], card = game.messages.get(rec?.cast?.message);
  return !!card && (rec.waiting ?? []).some(t => savedDegree(card, t) != null);
}
/** A spell's card changed: a save on its Toolbelt row may be what a waiting turn needs. Runner only. */
export function onMessageUpdate(message, change) {
  if (!isRunner() || !foundry.utils.hasProperty(change, `flags.${TOOLBELT}`)) return;
  for (const combat of game.combats.filter(c => c.started)) {
    const r = currentRequest(combat);
    if (r?.state === "saves" && Object.values(r.log ?? {}).some(l => l?.cast?.message === message.id)) doIt(combat, r.id).catch(e => console.error(`${ID} | turn`, e));
  }
}
/* what PF2e's own Damage, Half and Double buttons do (applyDamageFromMessage, 8.7.0), for a named target rather than the selected tokens: the roll
   altered by the multiplier, and the target told whether the damage comes from an ally or an enemy. Effects that only count for this one hit aren't read. */
async function applyFromCard(message, roll, target, multiplier = 1, shieldBlock = false, { resist = 0, less = 0 } = {}) {
  /* a reaction's part (0.27.0): Glimpse of Redemption's resistance is on the copy of the creature this one application is worked out on (PF2e does
     the arithmetic by damage type and its card shows it), and Interposing Earth's flat reduction comes off the roll once, after doubling or halving */
  const context = message.flags.pf2e?.context ?? {}, { origin, keep } = damageOptions(context.options ?? []), actor = target.actor.getContextualClone(origin, resist > 0 ? [resistEffect(resist)] : []);
  less = Math.max(0, Math.min(less, Math.floor(roll.total * multiplier)));
  const side = target.actor.alliance && message.actor ? [`origin:${target.actor.alliance === message.actor.alliance ? "ally" : "enemy"}`] : [];
  const rollOptions = new Set([...keep, ...side, ...origin, ...actor.getSelfRollOptions()]);
  await actor.applyDamage({ damage: multiplier === 1 && !less ? roll : roll.alter(multiplier, -less), token: target, item: message.item, rollOptions, shieldBlockRequest: !!shieldBlock, outcome: context.outcome });
}
/** Glimpse of Redemption, refused: resistance to all damage for one application, as an effect on the copy the damage is worked out on. */
const resistEffect = n => ({ type: "effect", name: "Glimpse of Redemption (refused)", img: "icons/svg/shield.svg", system: { rules: [{ key: "Resistance", type: "all-damage", value: n }], duration: { value: -1, unit: "unlimited" } } });
/** Do it (and Next step): on the runner, carry the plan on from where it stands. Without Auto it does one action and waits for Next step; with Auto it
    goes on by itself, with a pause between actions. Safe to call again after a reload: finished work is never repeated. From anyone else's browser it
    asks the runner, through the flag; a turn never runs quietly in the wrong browser. */
export async function doIt(combat, requestId) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  if (!isRunner()) { const why = runnerProblem(); if (why) throw new Error(why); return save(combat, requestId, { go: true }); }
  if (running.has(requestId)) return;
  await reactionsClear(requestId);   /* a monster's reaction mid-Strike (0.21.0) finishes first: one roller at a time */
  if (running.has(requestId)) return;
  running.add(requestId); try { await runTurn(combat, requestId); } finally { running.delete(requestId); stopAiming(); }
  /* a save that landed between reading the card and writing "saves" fired no hook this page would act on: look once more */
  const n = request(combat, requestId); if (n?.state === "saves" && saveArrived(combat, n)) setTimeout(() => doIt(combat, requestId).catch(e => console.error(`${ID} | turn`, e)), 0);
}
const autoPause = () => Math.max(0, Number(game.settings.get(ID, "autoPause")) || 0);
/* Auto ends the monster's turn itself (Rhea, 2026-11-07: "If it's on auto then yes"), END_MS after its last action, so the last roll can be seen. Only
   when the turn finished by itself: a card for the GM to apply, a stop, Play it myself or a turn handed to the GM leave it to the GM. Nothing ends a
   turn that has moved on, or one with another request still going (a re-plan). */
const END_MS = 2000, ending = new Set();
function endAfter(combat, requestId) {
  const r = request(combat, requestId), tok = sceneOf(combat)?.tokens.get(r?.tokenId), key = `${combat.id}.${r?.round}.${r?.combatantId}`;
  if (!r || !tok?.getFlag(ID, "auto") || ending.has(key)) return;
  ending.add(key);
  /* marked so the runner's 10 s check ends only a turn Auto was ending (0.33.1, review): never one finished by Next step and ticked Auto later,
     nor one handed to the GM after too many re-plans */
  if (!r.autoEnd) save(combat, requestId, { autoEnd: true }).catch(() => {});
  setTimeout(async () => {
    try {
      while (game.paused) await new Promise(r => setTimeout(r, 300));   /* paused: the turn ends once the GM unpauses, if it is still this monster's */
      const n = request(combat, requestId);
      if (n?.state !== "done" || !combat.started || combat.round !== r.round || combat.combatant?.id !== r.combatantId || currentRequest(combat) || !tok.getFlag(ID, "auto")) return;   /* Auto read again: unticked in the 2 s, the GM ends it */
      await combat.nextTurn();
    } catch (e) { console.error(`${ID} | ending the turn`, e); } finally { ending.delete(key); }
  }, END_MS);
}
/* The game's pause pauses Auto (Rhea, 2026-11-08: "Pause would pause all actions"): while `game.paused`, Auto starts no action and ends no turn, and
   goes on when the GM unpauses. A GM's own press (Do it, Next step) still acts while paused: she asked for it. Returns true when the turn should
   stop instead (Hold, Play it myself, or the turn moved on while waiting). */
async function pausedAuto(combat, requestId, tok) {
  if (!tok?.getFlag(ID, "auto") || !game.paused) return false;
  while (game.paused) {
    await new Promise(r => setTimeout(r, 300));
    const n = request(combat, requestId);
    if (!n || n.hold || n.state === "manual" || n.state === "done" || !combat.started || combat.combatant?.id !== n.combatantId) return true;
  }
  return false;
}
/* Auto's pause between actions, so each roll can be followed. Hold and Play it myself end it at once. */
async function pauseBetween(combat, id) {
  const end = Date.now() + autoPause() * 1000;
  while (Date.now() < end) { await new Promise(r => setTimeout(r, Math.min(200, end - Date.now()))); const n = request(combat, id); if (n?.hold || n?.state === "manual" || turnMovedOn(combat, n)) return; }
}
/** The turn a request belongs to is no longer the one running (the GM pressed next turn, or the fight ended): a monster's reaction belongs to the
    turn it was made on. */
function turnMovedOn(combat, r) {
  if (!r) return true;
  return !game.combats.has(combat.id) || !combat.started || combat.round !== r.round || combat.combatant?.id !== (r.reaction ? r.turnOf : r.combatantId);
}
async function runTurn(combat, requestId) {
  const r = request(combat, requestId); if (!RESUMABLE.includes(r?.state)) throw new Error("That turn isn't ready.");
  const took = r.tookAt ?? null;   /* her last Play it myself as this run read the turn: a newer one stops the run (found live in 0.33.1's test builds) */
  if (!await ensureScene(combat)) return save(combat, requestId, { state: "stopped", go: false, note: cantOpen() });
  { const n = request(combat, requestId); if ((n?.state === "manual" && r.state !== "manual") || (n?.tookAt ?? null) !== took) return; }   /* pressed while the map opened: hers */
  /* pressing Do it means go, whatever was held. A note about why it stopped goes; one from an earlier step (a PC at 0 HP) stays with the turn. */
  await save(combat, requestId, { state: "running", go: false, hold: false, gmWait: false, changeVerdict: null, ...(r.state === "held" || r.state === "stopped" ? { note: null } : r.note && withoutAsks(r.note) !== r.note ? { note: withoutAsks(r.note) } : {}) });   /* her instructions for the step before go once the next runs (B-9) */
  const tok = sceneOf(combat).tokens.get(r.tokenId);
  await dropInstantAreas(combat, { id: requestId, pos: r.pos ?? 0 }).catch(e => console.warn(`${ID} | areas`, e));   /* an instant area the GM resolved from its card */
  await settleCover(combat, requestId, r.pos ?? 0, tok);   /* a reload between a step and ending its Take Cover */
  for (let i = r.pos ?? 0; i < r.steps.length; i++) {
    if (i > (r.pos ?? 0) && await pausedAuto(combat, requestId, tok)) return;   /* the game's pause pauses Auto too (Rhea, 2026-11-08): the step the GM pressed for still runs */
    const now = { ...request(combat, requestId), id: requestId };   /* a stored request doesn't carry its own id; replan needs it */
    let step = r.steps[i];
    if (now.state === "manual") return;
    if ((now.tookAt ?? null) !== took) return save(combat, requestId, { state: "manual" });   /* Play it myself pressed since this run read the turn */
    if (now.hold) return save(combat, requestId, { state: "held", hold: false, note: "Held before the next step." });
    /* the turn moved on while Auto waited between steps (0.33.1, review): nothing more is done on another creature's turn */
    if (i > (r.pos ?? 0) && turnMovedOn(combat, now)) return save(combat, requestId, { state: "stopped", pos: i, note: joinNote(combat, requestId, `The turn moved on before step ${i + 1}, so the rest of the plan wasn't done.`) });
    /* look again before an action that hasn't begun. One begun before a reload carries on, never re-planned halfway. */
    if (!Object.keys(now.log?.[i] ?? {}).length) {
      let look; try { look = await lookAgain(combat, now, i, tok); } catch (e) { console.error(`${ID} | look again`, e); return save(combat, requestId, { state: "stopped", note: `I couldn't check step ${i + 1} before doing it (${e.message}). Play the rest yourself.` }); }
      if (look.gm) { await save(combat, requestId, { nbEdit: null }); return rethinkGm(combat, requestId, i, tok); }
      if (look.changes.length) return replan(combat, now, i, look.changes, tok);
      /* a Stride goes by the route just checked: the ground can change under a plan (a wall, someone it can't perceive) without the monster noticing */
      if (isMove(step) && look.next?.do === step.do && JSON.stringify(look.next.route) !== JSON.stringify(step.route)) {
        step = { ...step, route: look.next.route, cost: look.next.cost }; r.steps[i] = step; await save(combat, requestId, { steps: r.steps });
      }
      /* an ability as it checks out now: a Grab whose Strike missed may still keep hold of a creature it has grabbed */
      if (step.do === "ability" && look.next?.do === "ability" && (look.next.mode !== step.mode || look.next.target !== step.target)) { step = look.next; r.steps[i] = step; await save(combat, requestId, { steps: r.steps }); }
      /* an area as it checks out now: where it stands and who it catches */
      if (step.do === "spell" && step.area?.aim && look.next?.do === "spell" && JSON.stringify(look.next.area) !== JSON.stringify(step.area)) { step = look.next; r.steps[i] = step; await save(combat, requestId, { steps: r.steps }); }
      /* someone readied (0.35.0): the step waits a moment for a Now!, then for the readied action; after one, the look runs again */
      { const rw = await readyWindow(combat, requestId); if (await readyEnd(combat, requestId, i, rw.w)) return; if (rw.took) { i--; continue; } }
      /* out of hiding just before anything but Hide, Sneak, Step or an attack (Rhea, 2026-11-07, A) */
      if (revealsBefore(step)) await comeOut(combat, requestId, tok, actWords(step)).catch(e => console.warn(`${ID} | out of hiding`, e));
    }
    let work = null, blind = false;
    const slab = step.do === "strike" ? barrierByLabel(combat, step.target) : null;
    if (slab || (step.do === "strike" && request(combat, requestId).log?.[i]?.slab)) work = () => runSlabStrike(combat, requestId, i, step, tok, slab);   /* a Strike at an earth barrier (0.35.0); one done before a reload counts as done */
    else if (step.do === "strike" && step.target?.startsWith?.("B") && !r.labels?.[step.target]) return save(combat, requestId, { state: "stopped", note: `The earth barrier ${tok.name} meant to strike is gone.` });
    else if (step.do === "strike") {
      const target = sceneOf(combat).tokens.get(r.labels[step.target]); if (!target) return save(combat, requestId, { state: "stopped", note: `${step.targetName} is gone.` });
      /* a creature it knows only from a pointed-out square that is wrong (0.30.0): the blow goes at the empty square */
      blind = wrongBelief(combat, tok, target); work = blind ? () => runBlindMiss(combat, requestId, i, step, tok, target) : () => runStrike(combat, requestId, i, step, tok, target);
    } else if (step.do in STEALTH_WORD) work = () => runStealth(combat, requestId, i, step, tok);   /* before moves: a Sneak is a move too */
    else if (isMove(step)) work = () => runStride(combat, requestId, i, step, tok);
    else if (step.do in POSTURES) work = () => runPosture(combat, requestId, i, step.do, tok);
    else if (step.do === "take-cover") work = () => runTakeCover(combat, requestId, i, tok);
    else if (step.do === "interact") work = () => runInteract(combat, requestId, i, step, tok);
    else if (step.do === "order") work = () => runOrder(combat, requestId, i, step, tok);
    else if (step.do === "say") work = () => runSay(combat, requestId, i, step, tok);
    else if (step.do === "command-animal") work = () => runCommand(combat, requestId, i, step, tok);
    else if (step.do === "point-out") work = () => runPointOut(combat, requestId, i, step, tok);
    else if (step.do === "climb") work = () => runClimb(combat, requestId, i, step, tok);
    else if (step.do === "release") work = () => runRelease(combat, requestId, i, step, tok);
    else if (step.do === "draw") work = () => runDraw(combat, requestId, i, step, tok);
    else if (step.do === "delay") work = () => runDelay(combat, requestId, i, step, tok);
    else if (step.do === "ability") {
      const target = step.target ? sceneOf(combat).tokens.get(tokenIdOf(combat, r, step.target)) : null; if (step.target && !target) return save(combat, requestId, { state: "stopped", note: `${step.targetName} is gone.` });   /* 0.30.0 (B-5): an ally's label too */
      if (target && wrongBelief(combat, tok, target)) return save(combat, requestId, { state: "stopped", note: joinNote(combat, requestId, `${tok.name} believes ${target.name} is at a square an ally pointed out, and that square is wrong: ${step.itemName} goes at nothing there. Its action is yours to rule on: play the rest yourself.`) });
      work = () => runAbility(combat, requestId, i, step, tok, target);
    } else if (step.do === "spell") {
      const tid = step.target ? tokenIdOf(combat, r, step.target) : null, target = tid ? sceneOf(combat).tokens.get(tid) : null; if (step.target && !target) return save(combat, requestId, { state: "stopped", note: `${step.targetName} is gone.` });
      if (target && !step.area?.aim && wrongBelief(combat, tok, target)) return save(combat, requestId, { state: "stopped", note: joinNote(combat, requestId, `${tok.name} believes ${target.name} is at a square an ally pointed out, and that square is wrong: ${step.itemName ?? "its spell"} goes at nothing there. Its action is yours to rule on: play the rest yourself.`) });
      work = step.area?.aim ? () => runArea(combat, requestId, i, step, tok) : () => runSpell(combat, requestId, i, step, tok, target);
    }
    if (request(combat, requestId).log?.[i]?.disrupted || request(combat, requestId).log?.[i]?.countered) work = null;   /* countered (0.36.0) as disrupted */   /* disrupted before a reload: the action is spent, never done after all */
    /* player reactions before the action (0.20.0): a manipulate action, a ranged attack, an attack at a character; once per step, before it begins */
    if (work && !blind && !Object.keys(request(combat, requestId).log?.[i] ?? {}).length && ["strike", "interact", "draw", "release", "ability", "spell", "point-out"].includes(step.do)) {
      const tid = step.target ? tokenIdOf(combat, r, step.target) : null;
      let pre; try { pre = await beforeAction(combat, requestId, i, step, tok, tid ? sceneOf(combat).tokens.get(tid) : null); } catch (e) { console.error(`${ID} | reactions`, e); return save(combat, requestId, { state: "stopped", note: `I couldn't ask the reactions before step ${i + 1} (${e.message}). Press Do it to try again, or play it yourself.` }); }   /* review finding 8 */
      if (pre === "manual") return;
      if (pre === "gone") return save(combat, requestId, { state: "stopped", note: "The turn moved on while reactions were being asked." });
      if (pre === "held") return save(combat, requestId, { state: "held", hold: false, note: `Held before step ${i + 1}, after the reactions to it.` });
      if (pre === "ask") return save(combat, requestId, { state: "stopped", note: `${request(combat, requestId).note ?? ""} Step ${i + 1} hasn't been done. Check the reactions in chat, then press Do it to carry on or play the rest yourself.`.trim() });
      if (pre === "down") { await save(combat, requestId, { pos: i, state: "done", note: joinNote(combat, requestId, `${tok.name} went down to a reaction before {they} could act.`) }); return endAfter(combat, requestId); }
      if (pre === "countered") { await dropEarthCover(combat).catch(e => console.warn(`${ID} | cover`, e));   /* the step is over: its +1 and cover go (review 3) */
        await save(combat, requestId, { log: { [i]: { countered: true } }, note: joinNote(combat, requestId, `${tok.name}'s ${step.itemName ?? "spell"} was countered: the actions are spent and nothing was cast.`) }); work = null; }
      if (pre === "paused") return save(combat, requestId, { state: "stopped" });
      if (pre === "disrupted") { await save(combat, requestId, { log: { [i]: { disrupted: true } }, note: joinNote(combat, requestId, `A critical Reactive Strike disrupted ${tok.name}'s ${actWords(step).replace(/^\{their\} /, "")}: the action is spent (any spell slot or use it costs is your call).`) }); work = null; }
    }
    const stayFrom = ["stand", "drop-prone", "climb"].includes(step.do) && tok.object ? { at: placeOf(tok, sceneOf(combat)).pos, elev: heightUp(tok) } : null;   /* a Climb is asked from where it was (review finding 16) */
    if (work) {
      let result; try { result = await work(); } catch (e) { console.error(e); result = "ask"; await save(combat, requestId, { note: e.message }); }
      if (!["wait", "held", "stopped", "gm"].includes(result)) await dropEarthCover(combat).catch(e => console.warn(`${ID} | cover`, e));
      else if (result === "gm") await dropEarthCover(combat, { recognizeOnly: true }).catch(e => console.warn(`${ID} | recognize`, e));   /* the save is rolled: Recognize Spell's +1 goes (seen live in test build 1: it stayed to the turn's end) */   /* Interposing Earth's cover lasts for the step it answered */
      if (result === "stopped") return save(combat, requestId, { state: "stopped" });
      if (result === "held") return save(combat, requestId, { state: "held", hold: false, note: "Held after the reactions, before the damage." });   /* a Hold during the reactions to a hit (0.20.0) */
      if (result === "gone") return save(combat, requestId, { state: "stopped", note: "The turn moved on while reactions were being asked." });
      /* a Delay ended the turn itself (the rest of the turn doesn't happen): the request is done, and its new turn comes after the named creature's */
      if (result === "delayed") return save(combat, requestId, { pos: i + 1, coverSettled: i + 1, state: "done", delayed: true });
      /* a shot it couldn't make (no ammunition left, or Ranged Combat refused): nothing was rolled, so ask again with the action unspent */
      if (result === "noShot" || result === "noShotSpent") {
        const b = turns(combat).noShot?.[tok.id], items = b?.round === combat.round ? [...new Set([...(b.items ?? []), step.item])] : [step.item];
        await saveTurns(combat, { [`noShot.${tok.id}`]: whole({ round: combat.round, items }) });   /* no shots with it for the rest of this turn */
        const spent = result === "noShotSpent";   /* after a flat check the action is spent: no free reroll */
        return replan(combat, { ...request(combat, requestId), id: requestId }, spent ? i + 1 : i, [{ who: "me", what: "noShot", item: step.itemName, why: "no ammunition it can use", spent }], tok);
      }
      /* a save the player rolls: the turn waits, with no timer, until their row on the spell's card has it (or the GM presses Roll it for them) */
      if (result === "wait") return save(combat, requestId, { state: request(combat, requestId).state === "manual" ? "manual" : "saves" });
      if (result === "ask") return save(combat, requestId, { state: "stopped", note: `${request(combat, requestId).note ?? ""} Step ${i + 1} may not have finished. ${isMove(step) ? "Put the monster where {they} should be" : step.do in POSTURES ? "Check whether {they} {is|are} prone" : step.do === "take-cover" ? "Check whether {they} {is|are} Taking Cover" : step.do === "interact" ? "Check the chat for {their} Interact card" : step.do === "order" ? "Check the chat for {their} order" : step.do === "say" ? "Check the chat for what {they} said, and {their} row for a yield" : step.do === "command-animal" ? "Check the chat for {their} Nature check, and the animal's row for the command" : step.do === "point-out" ? "Check {their} card: {their} allies may not have been told" : step.do === "delay" ? "Check the tracker: {their} turn should have ended and {their} place moved to just after the creature {they} {waits|wait} for" : step.do === "ability" ? "Check the chat, HP and conditions" : step.do === "spell" ? "Check the chat, the spell's slot or use, HP and conditions" : step.do in STEALTH_WORD ? `Check {their} ${STEALTH_WORD[step.do]} card and apply Visioner's results if they aren't${step.do === "sneak" ? ", and where {they} {stands|stand}" : ""}` : step.do === "strike" && tok.actor?.type === "npc" && rangedOn() && strikesWithIds(tok.actor).find(x => x.id === step.item)?.strike?.item?.isRanged ? "Check the chat, HP and {their} ammunition (the module takes a monster's ammunition after the roll)" : "Check the chat and HP"}, then play the rest yourself.`.trim() });
      noteDeed(combat, tok, step, request(combat, requestId)?.log?.[i], r);   /* fight memory (0.25.0): what its allies saw it do */
      /* it yielded (0.29.0): it stands down, so the turn is over and passes by itself, Auto or not */
      if (result === "yielded") { await save(combat, requestId, { pos: i + 1, coverSettled: i + 1, state: "done", yielded: true }); return passAfter(combat, requestId); }
      /* a move action that leaves no square: reactions such as Reactive Strike at its end (0.20.0) */
      if (["stand", "drop-prone", "climb"].includes(step.do) && result === "next") {
        let g; try { g = await stayGate(combat, requestId, i, step, tok, stayFrom); } catch (e) { console.error(`${ID} | reactions`, e); g = "ask"; }
        if (g === "manual") return;
        if (g === "gone") return save(combat, requestId, { state: "stopped", pos: i + 1, coverSettled: i + 1, note: "The turn moved on while reactions were being asked." });
        if (g === "ask") return save(combat, requestId, { state: "stopped", note: `${request(combat, requestId).note ?? ""} Step ${i + 1} is done. Check the reactions in chat, then press Do it to carry on or play the rest yourself.`.trim(), pos: i + 1, coverSettled: i + 1 });
      }
      /* the monster went down to a reaction (0.20.0): nothing more this turn */
      if (downNow(tok) && request(combat, requestId).state !== "manual") { await save(combat, requestId, { pos: i + 1, coverSettled: i + 1, state: "done", note: joinNote(combat, requestId, `${tok.name} went down during {their} turn.`) }); return endAfter(combat, requestId); }
      /* an attack from hiding: the target was off-guard to it, and now it is observed (Visioner's Attack Consequences on its card, or the module) */
      if (revealsAfter(step)) await comeOut(combat, requestId, tok, actWords(step), request(combat, requestId).log?.[i]?.attack?.message ?? null).catch(e => console.warn(`${ID} | out of hiding`, e));
      await settleCover(combat, requestId, i + 1, tok, i);   /* its own attack or move ends a Take Cover */
      /* a Seek ends the plan: ask again with what it found, while it has actions left (replan ends the turn otherwise) */
      if (step.do === "burrow" && !step.below && (step.fromBelow || isBelow(tok)) && result !== "gm" && request(combat, requestId).state !== "manual") return replan(combat, { ...request(combat, requestId), id: requestId }, i + 1, [isBelow(tok) ? { who: "me", what: "stopped", at: squareOf(tok, sceneOf(combat)) } : { who: "me", what: "surfaced" }], tok, step.fromBelow ? { counted: false } : {});   /* a reload before this repeats nothing: the Seek's record says it's done, and this is reached again */   /* up out of the ground (0.16.0): asked again at the surface, as after a Seek; and (0.18.0) one meant to come up that was stopped short below, even from the surface and as the last step, so it isn't left underground with actions unspent */
      if (step.do === "seek" && result !== "gm" && request(combat, requestId).state !== "manual") return replan(combat, { ...request(combat, requestId), id: requestId }, i + 1, [{ who: "me", what: "sought" }], tok, { counted: false });   /* a reload before this repeats nothing: the Seek's record says it's done, and this is reached again */
      /* a Stride, Step or Crawl that ended short of its square: the rest was planned from there, so ask again (the reason names the square, never what stopped it) */
      const at = squareOf(tok, sceneOf(combat));
      if (isMove(step) && result !== "gm" && !same(at, step.to) && (i + 1 < r.steps.length || step.do === "flee") && request(combat, requestId).state !== "manual") return replan(combat, { ...request(combat, requestId), id: requestId }, i + 1, [{ who: "me", what: "stopped", at }], tok);
      /* a Climb that made no progress (a failed check): the rest was planned from higher up, so ask again, as for a Stride stopped short */
      if (step.do === "climb" && result !== "gm" && request(combat, requestId).log?.[i]?.climb?.degree === 1 && i + 1 < r.steps.length && request(combat, requestId).state !== "manual") return replan(combat, { ...request(combat, requestId), id: requestId }, i + 1, [{ who: "me", what: "noClimb", height: heightUp(tok) }], tok);
      /* at the map's edge (Rhea, 2026-11-08): the turn stops, Auto or not, and the GM chooses Extend map or Let it get away on the card */
      if (step.do === "flee" && result !== "gm" && request(combat, requestId).state !== "manual") { const out = await save(combat, requestId, { pos: i + 1, coverSettled: i + 1, state: "fled", fled: { sides: edgeSides(at, sizeOf(tok), ...mapSquares(sceneOf(combat))), at } });
        /* its band was let go as a whole (Rhea, R3-13): it leaves without stopping */
        await leaveWithBand(combat, requestId, tok).catch(e => console.error(`${ID} | band leaves`, e)); return out; }
      /* an ability whose effects are the GM's to apply: the turn waits for Next step, Auto or not (the look before the next action then sees what changed) */
      if (result === "gm" && request(combat, requestId).state !== "manual") { const end = i + 1 >= r.steps.length;
        if (!end) await addNote(combat, requestId, "Then press Next step.");
        return save(combat, requestId, { pos: i + 1, coverSettled: i + 1, state: end ? "done" : "ready", ...(end ? { gmEnded: true } : { gmWait: true }) }); }   /* gmWait: ticking Auto doesn't run past it (0.17.0 review) */
    }
    if (request(combat, requestId).state === "manual") return;
    if (i + 1 >= r.steps.length) {
      { const rw = await readyWindow(combat, requestId); if (await readyEnd(combat, requestId, i + 1, rw.w)) return; }   /* a readied action set off by its last step (0.35.0) */
      await save(combat, requestId, { pos: i + 1, coverSettled: i + 1, state: "done" }); return endAfter(combat, requestId); }
    /* an order is speech, not an action: it costs no Next step press and no pause (0.28.0, design review 6) */
    if (step.do === "order" || step.do === "say") { await save(combat, requestId, { pos: i + 1, coverSettled: i + 1 }); continue; }
    if (!tok.getFlag(ID, "auto")) return save(combat, requestId, { pos: i + 1, coverSettled: i + 1, state: "ready" });   /* Next step */
    await save(combat, requestId, { pos: i + 1, coverSettled: i + 1 });
    await pauseBetween(combat, requestId);
  }
  if (request(combat, requestId).state !== "manual") { await save(combat, requestId, { state: "done" }); return endAfter(combat, requestId); }
}
/** What changed since the plan was made, or why the next step no longer works (`changes`, empty when it can go on), and the next step as it checks out now (`next`). */
async function lookAgain(combat, r, i, tok) {
  if (!r.seen || !tok.object) return { changes: [] };   /* a request from before 0.4.0 has no baseline */
  if (r.nbEdit && canRethink(combat, r, i, tok)) return { changes: [{ who: "gm", what: "notebook" }], gm: true };   /* the GM crossed out or added a notebook line while a step ran (0.25.0) */
  const changes = changesSince(r.seen, situationNow(combat, tok, r.labels));
  if (changes.length) return { changes };
  /* an earth barrier rose or fell since the plan was made (0.35.0): it sees a new wall, or one gone */
  if (r.packet && !tok.actor?.hasCondition?.("blinded")) { const was = (r.packet.barriers ?? []).map(b => b.label).sort().join(), now = barriersOf(combat, sceneOf(combat).id).map(b => b.label).sort().join(); if (was !== now) return { changes: [{ who: "me", what: "barrier" }] }; }
  /* a heal or a casting by someone else that it perceived since this plan was asked for (0.25.0, review 4: never a line that follows from its own step) */
  const saw = rethinkFor(books(combat)[tok.id], { rung: rungOf(r.packet?.mind?.pick?.mind), after: r.nbAt ?? r.at ?? 0 }); if (saw.length) return { changes: [...new Map(saw.map(x => [`${x.who}|${x.what}`, { who: x.who, what: x.what }])).values()] };
  const left = (r.plan?.steps ?? []).slice(i), rest = checkPlan({ steps: left }, await gather(combat, r, spentBy(r.steps.slice(0, i)), { moves: hasMove(left), spells: hasSpell(left), before: i > 0 ? { step: r.steps[i - 1], rec: r.log?.[i - 1] ?? {} } : null }));
  return rest.ok ? { changes: [], next: rest.steps[0] } : { changes: [{ who: "plan", what: "illegal", reason: rest.reason }] };
}
/** Drop the rest of the plan and ask again, for the same turn: a new request with a fresh packet, what's done so far, and why. The old one ends there. */
async function replan(combat, r, i, changes, tok, { counted = true } = {}) {
  if (request(combat, r.id)?.state === "manual") return;   /* Play it myself pressed while it looked again (0.33.1) */
  /* counted: false for the re-ask after a Seek, which is part of the plan, not something that went wrong, so it doesn't use up MAX_REPLANS */
  const used = spentBy(r.steps.slice(0, i)), spent = (r.spent ?? 0) + used.actions, attacks = (r.attacks ?? 0) + used.attacks, replans = (r.replans ?? 0) + (counted ? 1 : 0);
  const done = [...(r.done ?? []), ...r.steps.slice(0, i).map((s, k) => doneStep(s, r.log?.[k], P(tok, combat)))], why = describeChanges(changes, undefined, undefined, P(tok, combat)), at = `requests.${r.id}`;
  /* with no actions left the turn ends, unless an Improved Grab or the like can still follow the Strike that just hit (a free action) */
  const freeNext = () => { const l = lastAction({ done: done.at(-1) ?? null, strikes: strikesWithIds(tok.actor).map(({ id, strike: a }) => ({ id, effects: [...(a.item?.system?.attackEffects?.value ?? [])] })) });
    return l?.do === "strike" && l.hit === true && abilityList(tok.actor).some(a => a.followUp && a.kind === "free" && l.effects.includes(a.effect)); };
  if (actionsOf(tok.actor, combat) - spent <= 0 && !freeNext()) { await saveTurns(combat, { [`${at}.state`]: "done", [`${at}.since`]: clock(), [`${at}.pos`]: i, [`${at}.why`]: changes, [`${at}.note`]: [r.note, `${why} No actions left, so the turn ends here.`].filter(Boolean).join(" ") }); return endAfter(combat, r.id); }   /* keep a note from its steps (out of hiding, 0 HP) */
  if (replans > MAX_REPLANS) return saveTurns(combat, { [`${at}.state`]: "done", [`${at}.pos`]: i, [`${at}.why`]: changes, [`${at}.note`]: [r.note, `${why} That would be re-plan ${replans} this turn, so play the rest yourself.`].filter(Boolean).join(" ") });
  /* one packet at a time with the fight-start look's (0.33.0 review 2): two built at once could give one label to two creatures */
  return withPackets(async () => {
  let built; try { built = await buildPacket(combat, tok, { spent, attacks, done, note: `Asked again mid-turn: ${why}` }); }
  catch (e) { console.error(`${ID} | packet`, e); return save(combat, r.id, { state: "stopped", note: `Something changed (${why}) and I couldn't work out what ${tok.name} perceives now (${e.message}). Play the rest yourself.` }); }
  if (request(combat, r.id)?.state === "manual") return;   /* Play it myself pressed while the packet was built (0.33.1, review): no new ask */
  const id = foundry.utils.randomID(8);
  await saveTurns(combat, { [`${at}.state`]: "done", [`${at}.pos`]: i, [`${at}.replanned`]: id,
    [`requests.${id}`]: { state: "requested", combatantId: r.combatantId, tokenId: r.tokenId, round: r.round, turn: r.turn, at: Date.now(), since: clock(), log: {}, labels: built.labels, packet: built.packet, ...(built.mindHeld.length ? { mindHeld: built.mindHeld } : {}), seen: situationNow(combat, tok, built.labels, built.others), nbAt: Date.now(), note: null, tries: 0, pos: 0, spent, attacks, done, replans, why: changes, parent: r.id },
    ...eventChange("replan", id, 0), ...packetExtras(combat, tok, built) });
  });
}
/* ---------- fleeing off the map (Rhea, 2026-11-08) ---------- */
const SURVEY = "lythara-survey-sheet", EXTEND_SQUARES = 10, EXTEND_MAX = 120, EXTEND_MS = 180000, EXTEND_LATE = "The map took too long to extend.";
/** The map's size in squares as the scene stands now. */
const mapSquares = scene => [Math.round(scene.dimensions.sceneWidth / scene.grid.size), Math.round(scene.dimensions.sceneHeight / scene.grid.size)];
const surveyApi = () => game.modules.get(SURVEY)?.active ? game.modules.get(SURVEY).api ?? null : null;
/** Why the map can't be extended that way, or null. The Survey Sheet grows an encounter map by EXTEND_SQUARES squares and stops at EXTEND_MAX a side. */
export function extendProblem(scene, side) {
  if (!SIDES.includes(side)) return "Pick an edge: north, east, south or west.";
  if (!surveyApi()?.extendEncounter) return "Lythara Survey Sheet isn't on, so the map can't be extended.";
  if (!scene?.getFlag(SURVEY, "encounter")) return "This scene isn't an encounter map, so it can't be extended.";
  const [cols, rows] = mapSquares(scene), horiz = side === "east" || side === "west";
  if ((horiz ? cols : rows) + EXTEND_SQUARES > EXTEND_MAX) return `The map is at its limit (${EXTEND_MAX} squares a side) that way.`;
  return null;
}
/** The XP the party would have earned for this monster: PF2e's own calculation for one creature of its level against the party's level and size. null when it can't be worked out. */
export function escapeXP(tok) {
  try { const level = tok.actor?.level; if (!Number.isFinite(level)) return null; return game.pf2e.gm.calculateXP(suggestedLevel(), partySize(), [level], [], {}).totalXP ?? null; } catch { return null; }
}
const escapedOf = combat => turns(combat).escaped ?? {};   /* keyed by the request that fled, so a monster that escapes twice keeps both records */
const escapeRecord = (combat, tokenId) => Object.entries(escapedOf(combat)).filter(([, e]) => e?.tokenId === tokenId && !e.returned).sort((a, b) => (b[1].at ?? 0) - (a[1].at ?? 0))[0] ?? null;
/** Let it get away (Rhea, 2026-11-08): the monster leaves the fight. Its token stays on the scene, hidden and flagged, HP and conditions kept; nothing is
    deleted but its combatant. The threat stays as built; the XP not earned is noted on the card and in the history. No chat message. Any GM may press it. */
export async function letGo(combat, requestId, { withBand = false } = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId); if (r?.state !== "fled") throw new Error("That monster isn't at the map's edge.");
  const tok = sceneOf(combat)?.tokens.get(r.tokenId), combatant = combat.combatants.get(r.combatantId); if (!tok) throw new Error("Its token is gone.");
  if (escapedOf(combat)[requestId]) throw new Error("Already done.");   /* two GMs pressing together: the record is written first, so the second press stops here */
  const xp = escapeXP(tok), name = tok.name, at = Date.now(), xpWords = xp != null ? ` (${xp} XP not earned)` : "";
  await saveTurns(combat, { [`escaped.${requestId}`]: whole({ tokenId: tok.id, name, xp, round: combat.round, at, combatantId: r.combatantId }) });
  await save(combat, requestId, { state: "done", extend: null, escaped: { name, xp, at }, note: [r.note, `${name} got away${withBand ? " with {their} band (you let the whole band go)" : ""}${xpWords}.`].filter(Boolean).join(" ") });
  await tok.update({ hidden: true, [`flags.${ID}.escaped`]: { round: combat.round, at, xp, combat: combat.id } });
  /* deleting the current combatant is enough: core's Combatant._preDeleteOperation hands the turn to the next survivor with turn events
     (14.370). Calling nextTurn first and then deleting skipped the next creature's turn (seen live 2026-11-08: round 1 → 2, Test Hero's turn lost). */
  if (combatant) await combat.deleteEmbeddedDocuments("Combatant", [combatant.id]);
  return { name, xp };
}
/** How many others of its band are still in the fight (in the tracker, not defeated or dead): the flee card offers "Let the whole band go" when
    there is at least one (Rhea, 2026-11-11, R3-13). */
export function bandStillFighting(combat, tokenId) {
  const scene = sceneOf(combat), tok = scene?.tokens.get(tokenId), key = tok ? bandKeyOf(scene, tok) : ""; if (!key) return 0;
  return membersOf(scene, key).filter(t => t.id !== tok.id && combat.combatants.some(c => c.tokenId === t.id && !c.defeated) && !isDeadNow(t.actor)).length;
}
/** Let the whole band go (R3-13): this one leaves now, and every other member of its band leaves without stopping when it reaches the map's edge.
    Nothing makes them run: each still flees by its own mind. Bringing one of them back takes the leave away again. */
export async function letBandGo(combat, requestId) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId); if (r?.state !== "fled") throw new Error("That monster isn't at the map's edge.");
  const tok = sceneOf(combat)?.tokens.get(r.tokenId), key = tok ? bandKeyOf(sceneOf(combat), tok) : ""; if (!key) throw new Error("It isn't in a band.");
  await saveTurns(combat, { [`bandGo.${key}`]: { at: Date.now(), round: combat.round } });
  return letGo(combat, requestId, { withBand: true });
}
async function leaveWithBand(combat, requestId, tok) {
  const key = bandKeyOf(sceneOf(combat), tok); if (!key || !turns(combat).bandGo?.[key] || !game.user.isGM) return;
  if (request(combat, requestId)?.state === "fled") await letGo(combat, requestId, { withBand: true });
}
/** Extend map (Rhea, 2026-11-08): the GM's press asks the runner, which grows the map and then asks the thinker again from a fresh packet; the monster keeps its turn. */
export async function extendMap(combat, requestId, side) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId); if (r?.state !== "fled") throw new Error("That monster isn't at the map's edge.");
  if (!(r.fled?.sides ?? []).includes(side)) throw new Error(`It isn't at the ${side} edge.`);
  const why = extendProblem(sceneOf(combat), side); if (why) throw new Error(why);
  return save(combat, requestId, { extend: side });
}
async function runExtend(combat, requestId) {
  if (!isRunner()) return; if (running.has(requestId)) return;
  running.add(requestId);
  try {
    const r = request(combat, requestId), side = r?.extend;
    if (r?.state !== "fled" || !side) { if (r?.extend) await save(combat, requestId, { extend: null }); return; }   /* the state changed under the press (Play it myself): drop it */
    const tok = sceneOf(combat).tokens.get(r.tokenId); if (!tok) return save(combat, requestId, { state: "stopped", extend: null, note: "Its token is gone." });
    await save(combat, requestId, { state: "extending", extend: null, extending: side, extendFrom: mapSquares(sceneOf(combat)) });
    const history = tok.movementHistory?.length ?? 0; let shifted = null;
    try {
      const why = extendProblem(sceneOf(combat), side); if (why) throw new Error(why);
      /* the Survey Sheet keeps drawing after a timeout, so a timeout never offers the buttons again (a second press would grow the map twice): it carries on as if it finished */
      try { shifted = (await within(surveyApi().extendEncounter(sceneOf(combat), side, EXTEND_SQUARES), EXTEND_MS, EXTEND_LATE))?.shifted ?? null; }
      catch (e) { if (e.message !== EXTEND_LATE) throw e; console.warn(`${ID} | extend`, e.message); }
      /* the redraw: every client rebuilds its canvas; the packet needs this page's canvas back on the fight scene with the token drawn */
      for (let t = 0; t < EXTEND_MS && !(await ensureScene(combat) && tok.object && !tok.object.destroyed); t += 500) await sleep(500);
      await sleep(SETTLE_MS);
    } catch (e) { console.error(`${ID} | extend`, e); return save(combat, requestId, { state: "fled", extending: null, note: `The map couldn't be extended (${e.message}).` }); }
    await afterExtend(combat, requestId, side, tok, { shifted: shifted ?? shiftFor(side), history });
  } finally { running.delete(requestId); }
}
/** The pixel shift an extension on that side gives everything on the map (the Survey Sheet grows north and west by moving the content). */
const shiftFor = side => [side === "west" ? EXTEND_SQUARES * 100 : 0, side === "north" ? EXTEND_SQUARES * 100 : 0];
/** The map has grown: the monster keeps its turn and the thinker is asked again from a fresh packet (not counted as a re-plan). The request stays
    `extending` (busy, no buttons) until `replan` closes it, so a Let it get away can't slip in between. Squares this module remembers (where a
    monster last saw someone) move with the content; the token's movement history is cleared if the shift was recorded as movement, so the next
    Stride isn't charged for it. */
async function afterExtend(combat, requestId, side, tok, { shifted = shiftFor(side), history = 0 } = {}) {
  /* how far the squares' numbers moved: the new strip only, and only when the map grew west or north. The Survey Sheet's `shifted` is in pixels
     and includes the change of the scene's padding, which moves every token but no square's number (seen live in 0.26.0: a 40-column map grown
     west gave 1,100 px, and the old pixel sum moved remembered squares and a rally spot by 11 where the tokens moved 10; grown east or south it
     moved them by 1 where nothing moved). The size before is on the request since 0.25.0. */
  const scene = sceneOf(combat), from = request(combat, requestId)?.extendFrom, [cols, rows] = mapSquares(scene);
  const dx = side === "west" ? (Array.isArray(from) ? Math.max(0, cols - from[0]) : EXTEND_SQUARES) : 0, dy = side === "north" ? (Array.isArray(from) ? Math.max(0, rows - from[1]) : EXTEND_SQUARES) : 0, change = { [`requests.${requestId}.extended`]: side, [`requests.${requestId}.extending`]: null };
  if (dx || dy) for (const [who, mem] of Object.entries(turns(combat).memory ?? {})) for (const [id, m] of Object.entries(mem ?? {})) if (Array.isArray(m?.square)) change[`memory.${who}.${id}.square`] = [m.square[0] + dx, m.square[1] + dy];
  /* a held order's square moves with the ground too (0.29.1, found with bug B-1). A pending order from the GM's box is left as it is: it may have
     been picked on the grown map, and it is given within seconds (review 5) */
  if (dx || dy) for (const [id, st] of Object.entries(ordersOf(combat).heard ?? {})) { const moved = shiftHeard(st, dx, dy); if (moved) change[`orders.heard.${id}`] = whole(moved); }
  /* a climber's tree is a square on its token (bug B-1, 0.29.1): unshifted, the next turn change found it "no longer up its tree" and took its flag and
     Off-Guard away. Shifted before the request stops being `extending`, so a reload in between resumes here; marked with the request, so a resume
     never shifts it twice (review 4) */
  if (dx || dy) for (const t of scene.tokens) { const f = t.getFlag(ID, "climbing"); if (Array.isArray(f?.at) && f.at.length === 2 && f.shifted !== requestId)
    await watched(() => t.setFlag(ID, "climbing", { ...f, at: [f.at[0] + dx, f.at[1] + dy], shifted: requestId })).catch(e => console.error(`${ID} | climbing`, e)); }
  await saveTurns(combat, change);
  await shiftBandSpots(scene, dx, dy).catch(e => console.error(`${ID} | rally spots`, e));   /* a band's rally spot is a square too */
  if ((tok.movementHistory?.length ?? 0) > history && tok.clearMovementHistory) await tok.clearMovementHistory();
  const r = request(combat, requestId);
  await replan(combat, { ...r, id: requestId }, r.pos ?? r.steps.length, [{ who: "me", what: "extended", side }], tok, { counted: false });
}
/** Escaped monsters still on this fight's scene: their hidden, flagged tokens, newest first. */
export function escapedList(combat) {
  const scene = sceneOf(combat); if (!scene) return [];
  return scene.tokens.contents.filter(t => t.getFlag(ID, "escaped")?.combat === combat.id && !combat.combatants.some(c => c.tokenId === t.id)).map(t => { const e = t.getFlag(ID, "escaped"), rec = escapeRecord(combat, t.id)?.[1]; return { id: t.id, name: t.name, round: e.round, xp: e.xp ?? rec?.xp ?? null, at: e.at }; }).sort((a, b) => b.at - a.at);
}
/** Bring back (Rhea, 2026-11-08): the token is shown again, joins the fight where it stands now (the GM may move it first) and rolls initiative as any monster joining a fight. The history keeps the escape line and adds a returned line. */
export async function bringBack(combat, tokenId) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const tok = sceneOf(combat)?.tokens.get(tokenId); if (!tok?.getFlag(ID, "escaped")) throw new Error("That monster hasn't escaped.");
  if (combat.combatants.some(c => c.tokenId === tok.id)) throw new Error("It is already in the fight.");
  await tok.update({ hidden: false, [`flags.${ID}.-=escaped`]: null });
  const [c] = await combat.createEmbeddedDocuments("Combatant", [{ tokenId: tok.id, actorId: tok.actorId, sceneId: sceneOf(combat).id }]);
  if (c) await combat.rollInitiative([c.id], { skipDialog: true });   /* PF2e's roll dialog would wait for ever on a page nobody watches (seen live 2026-11-08) */
  const rec = escapeRecord(combat, tok.id); if (rec) await saveTurns(combat, { [`escaped.${rec[0]}.returned`]: { round: combat.round, at: Date.now() } });
  /* one of a band that was let go as a whole is back: the others stop at the edge and ask again */
  const band = bandKeyOf(sceneOf(combat), tok); if (band && turns(combat).bandGo?.[band]) await saveTurns(combat, { [`bandGo.${band}`]: null });
  return { name: tok.name, initiative: c?.initiative ?? null };
}
/** Is this page working on a turn, or about to? For tools that share the runner's page. The in-memory sets cover the start of a turn, before any request
    exists, so only the runner's own page has the full answer; on any other page it's the flag alone. */
/** Keep the current turn through an initiative change made on this page. Workbench moves a PC at 0 HP to just ahead of whoever's turn it is, from the
    page that applied the damage: the runner's. PF2e then tries to keep the turn, but that page's copy has already shifted, so its turn update often
    finds nothing to send, and the turn passed to the PC mid-turn, with turn events. Seen with the runner as active GM too (3 in 3), so this runs either way. Two steps on the runner's page:
    `keepTurn` gives the change core's `combatTurn` and `turnEvents: false`, as core's own initiative roll does, so every page keeps the same creature
    current with no turn event; core applies that in each page's copy only, so `saveTurn` then saves the turn for real, forced through (`diff: false`). */
export function keepTurn(combatant, change, options) {
  const combat = combatant.parent;
  if (!isRunner() || !combat?.started || combat.turn == null || typeof options.combatTurn === "number" || !("initiative" in change)) return;
  const current = combat.combatant; if (!current) return;
  const updates = Array.isArray(options.updates) && options.updates.length ? options.updates : [{ ...change, _id: combatant.id }];
  const after = combat.combatants.contents.map(c => { const u = updates.find(x => x._id === c.id); return u ? c.clone(u, { keepId: true, parent: combat }) : c; });
  const keep = after.sort((a, b) => combat._sortCombatants(a, b)).findIndex(c => c.id === current.id);
  if (keep < 0) return;
  options.combatTurn = keep; options.turnEvents = false; options[ID] = { ...(options[ID] ?? {}), keepTurn: keep };
}
export function saveTurn(combatant, options, userId) {
  const keep = options[ID]?.keepTurn; if (typeof keep !== "number" || userId !== game.user.id || !isRunner()) return;
  combatant.parent?.update({ turn: keep }, { diff: false, turnEvents: false }).catch(e => console.error(`${ID} | keeping the turn`, e));
}
export const busy = () => starting.size > 0 || judging.size > 0 || running.size > 0 || game.combats.filter(c => c.started).some(c => requestBusy(currentRequest(c)));
export const hold = (combat, id) => save(combat, id, { hold: true });
/* `tookAt` (0.33.1, found live): a run that read the turn just before her press would write it back to "running"; no run writes this stamp, so a
   run that finds it changed since it read the turn stops before its next step */
export const playMyself = (combat, id) => save(combat, id, { state: "manual", tookAt: clock() });
/* ---------- the Change button (Rhea, 2026-11-09: "Note and step edits") ---------- */
/** Who a GM's note can name, for noteForThinker: every token on the scene by its token and actor names (and, for a character, each long word of
    them: a first name or a surname alone), with its label when the monster perceives it or knows it as an ally and its own label for itself; every
    other character in the world and every user, with no label. Run on whichever GM page converts the note: the labels are on the Combat flag. */
export function notePeople(combat, r, labels = turns(combat).labels ?? {}) {   /* labels: the fight's own, or as they would stand (an order from the GM's box, 0.28.0 review 2) */
  const known = new Set([...Object.keys(r?.labels ?? {}), ...(r?.packet?.allies ?? []).map(a => a?.label)].filter(Boolean)), me = r?.packet?.you?.label ?? "it";
  const namesOf = (...ns) => [...new Set(ns.flatMap(n => n ? [n] : []))], out = [], onScene = new Set();
  for (const t of sceneOf(combat)?.tokens.contents ?? []) { const a = t.actor, isChar = !!a?.isOfType?.("character");
    if (a) onScene.add(a.id);
    out.push({ names: namesOf(t.name, a?.name, ...(isChar ? [...nameWords(t.name), ...nameWords(a?.name)] : [])), label: t.id === r?.tokenId ? me : known.has(labels[t.id]) ? labels[t.id] : null }); }
  for (const a of game.actors.filter(x => x.isOfType?.("character") && !onScene.has(x.id))) out.push({ names: namesOf(a.name, ...nameWords(a.name)), label: null });
  for (const u of game.users) out.push({ names: [u.name], label: null });
  return out;
}
/** The note as Angel would get it, for the card to show before sending: { text, unknown, ambiguous } (noteForThinker). */
export const previewNote = (combat, requestId, note) => noteForThinker(note, notePeople(combat, request(combat, requestId)));
const noteRefusal = ({ unknown, ambiguous }, tokName, what = "note") => [unknown.length ? `${listWords(unknown)} ${unknown.length === 1 ? "isn't someone" : "aren't creatures"} ${tokName} perceives: take ${unknown.length === 1 ? "that name" : "those names"} out, or the ${what} would tell it they're there.` : "", ambiguous.length ? `${listWords(ambiguous)} could mean more than one creature: use the label shown beside the name in the target lists (E2, M3…).` : ""].filter(Boolean).join(" ");
/** A note to Angel from the card: the rest of the turn is planned again with the GM's words, names turned into labels here and checked again on the
    runner. Refused with words when a name is one the monster doesn't perceive or fits several. Never counts as one of the turn's re-plans, and the
    new plan waits for Do it even on Auto: the GM asked, so she sees it first. fp: the plan's fingerprint when she started (planPrint). */
export async function askAngel(combat, requestId, note, fp) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId), why = changeProblem(r, P(sceneOf(combat).tokens.get(r?.tokenId), combat)) ?? runnerProblem(); if (why) throw new Error(why);
  if (fp && fp !== planPrint(r)) throw new Error("The plan changed while you wrote: look at it again.");
  const conv = previewNote(combat, requestId, note); if (!conv.text) throw new Error("Write what you want Angel to do first.");
  const bad = noteRefusal(conv, sceneOf(combat).tokens.get(r.tokenId)?.name ?? "it"); if (bad) throw new Error(bad);
  await save(combat, requestId, { ask: whole({ text: conv.text, user: game.user.name, at: Date.now(), fp: planPrint(r) }), changeVerdict: null });
  if (isRunner()) await runChange(combat, requestId);
}
/** The GM's own edits from the card: `steps` is the plan from the current step on, written as the thinker writes steps (the card makes it with
    applyEdits), fp the fingerprint of the plan they were made from. Checked on the runner by the same rules as any plan; refused, the old plan stays
    and the card says why. An empty list ends the plan. */
export async function changePlan(combat, requestId, steps, fp) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId), why = changeProblem(r, P(sceneOf(combat).tokens.get(r?.tokenId), combat)) ?? runnerProblem(); if (why) throw new Error(why);
  if (fp && fp !== planPrint(r)) throw new Error("The plan changed while you edited it: look at it again.");
  if (!Array.isArray(steps) || JSON.stringify(steps).length > 8000) throw new Error("That isn't a list of steps.");
  await save(combat, requestId, { edit: whole({ steps, user: game.user.name, at: Date.now(), fp: planPrint(r) }), changeVerdict: null });
  if (isRunner()) await runChange(combat, requestId);
}
/** A change waiting for the runner (offline, or not answering) can be taken back from the card. */
export async function cancelChange(combat, requestId) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId); if (r?.ask || r?.edit) await save(combat, requestId, { ask: null, edit: null });
}
/* A change and a run share one guard (`running`): a change never starts while a step runs, and nothing (Do it, Auto's start, ticking Auto) runs
   the turn while a change is being made. */
async function runChange(combat, requestId) {
  if (!isRunner() || running.has(requestId)) return;
  running.add(requestId);
  try {
    const r = request(combat, requestId); if (!r?.ask && !r?.edit) return;
    const what = r.ask ? "note" : "change", c = r.ask ?? r.edit;
    const refuse = reason => save(combat, requestId, { ask: null, edit: null, go: false, changeVerdict: `Your ${what} wasn't used: ${reason}`, edits: { [Date.now()]: { user: c.user, pos: r.pos ?? 0, what, refused: String(reason ?? "") } } });   /* the history says why */   /* a Do it pressed meanwhile doesn't run the old plan */
    const why = changeProblem({ ...r, ask: null, edit: null, go: false }, P(sceneOf(combat).tokens.get(r.tokenId), combat)); if (why) return refuse(why);
    if (c.fp !== planPrint(r)) return refuse("the plan changed after you started. Look at it again.");
    if (!await ensureScene(combat)) return refuse(cantOpen());
    const tok = sceneOf(combat).tokens.get(r.tokenId); if (!tok) return refuse("its token is gone.");
    return r.ask ? await sendNote(combat, requestId, r, tok, refuse) : await useEdit(combat, requestId, r, tok, refuse);
  } finally { running.delete(requestId); }
}
async function sendNote(combat, requestId, r, tok, refuse) {
  /* checked again here: a name that means something now (a token added since) must not go through as typed */
  const again = noteForThinker(r.ask.text, notePeople(combat, r));
  if (again.text !== r.ask.text || again.unknown.length || again.ambiguous.length) return refuse(noteRefusal(again, tok.name) || "a name in it now means a creature: write it again.");
  await save(combat, requestId, { ask: null, go: false });
  await replan(combat, { ...request(combat, requestId), id: requestId }, r.pos ?? 0, [{ who: "gm", what: "note", text: r.ask.text, user: r.ask.user }], tok, { counted: false });
  const next = request(combat, requestId)?.replanned; if (next) await save(combat, next, { gmWait: true });   /* the new plan waits for Do it, Auto or not */
}
async function useEdit(combat, requestId, r, tok, refuse) {
  const i = r.pos ?? 0, steps = r.edit.steps ?? [], user = r.edit.user, mine = P(sceneOf(combat).tokens.get(r.tokenId), combat), before = r.steps.slice(i).map(s => describeStep(s, mine)), at = Date.now();
  const still = () => { const n = request(combat, requestId); return n && CHANGEABLE.includes(n.state) && planPrint(n) === r.edit.fp; };
  if (!steps.length) {   /* the rest taken out: the plan ends here, and ending the turn is the GM's (Auto doesn't end a turn the GM cut short) */
    if (!still()) return refuse("the turn moved on meanwhile.");
    await save(combat, requestId, { ask: null, edit: null, go: false, changeVerdict: null, state: "done", gmEnded: true, plan: whole({ ...(r.plan ?? {}), steps: (r.plan?.steps ?? []).slice(0, i) }), steps: r.steps.slice(0, i), edits: { [at]: { user, pos: i, before, after: [] } } });
    return addNote(combat, requestId, "You took out the rest of the plan: end the turn when you're ready.");
  }
  /* a refusal's "Step N" counts from the card's first step, not from the edited list's */
  const card = reason => String(reason ?? "").replace(/^Step (\d+)/, (m, n) => `Step ${Number(n) + i}`);
  const clean = cleanPlan({ steps, reason: r.plan?.reason }); if (!clean.ok) return refuse(card(clean.reason));
  const left = clean.plan.steps, rest = checkPlan({ steps: left }, await gather(combat, r, spentBy(r.steps.slice(0, i)), { moves: hasMove(left), spells: hasSpell(left), before: i > 0 ? { step: r.steps[i - 1], rec: r.log?.[i - 1] ?? {} } : null }));
  if (!rest.ok) return refuse(card(rest.reason));
  if (!still()) return refuse("the turn moved on while it was being checked.");
  await save(combat, requestId, { ask: null, edit: null, go: false, changeVerdict: null, verdict: null, since: clock(), plan: whole({ ...(r.plan ?? {}), steps: [...(r.plan?.steps ?? []).slice(0, i), ...left] }), steps: [...r.steps.slice(0, i), ...rest.steps], edits: { [at]: { user, pos: i, before, after: rest.steps.map(s => describeStep(s, mine)) } } });
}
/** A GM's press on the card (Do it, Next step, Hold, Play it myself, Roll it for them), for the history window. Keyed by time so two browsers never
    write over each other. Only real presses: Auto's own runs don't come here. */
export const notePress = (combat, id, what, extra = {}) => save(combat, id, { presses: { [Date.now()]: { do: what, user: game.user.name, pos: request(combat, id)?.pos ?? 0, ...extra } } }).catch(e => console.warn(`${ID} | history`, e));

/** A party member's Angel and Auto ticks last one fight (Rhea: "always have the default be unticked"): cleared when the fight is deleted, on the runner
    only, so a ticked party member doesn't come up ticked in the next fight (0.18.0 review). */
export async function untickParty(combat) {
  if (!isRunner()) return;
  for (const c of combat.combatants) { const tok = c.token; if (!tok || !partyMember(tok.actor)) continue;
    for (const k of ["run", "auto"]) if (tok.getFlag(ID, k) != null) await tok.unsetFlag(ID, k).catch(e => console.warn(`${ID} | untick`, e)); }
}

/* ---------- player reactions during a monster's turn (0.20.0) ---------- */
/* Rhea's design (2026-11-05/06) and her answers of 2026-11-09: a prompt in the player's browser, React or Pass, with a countdown (world setting
   reactionTimer: 5 to 60 s, default 20, 0 = none), only for a player whose character has a reaction that fits; the GM's card always has Continue; a
   reaction with no player online (or a party member the GM plays) is the GM's, on the card. Since 0.27.0 the party's reactions are tracked (below):
   a character whose reaction is used isn't asked. Gates and rules: docs/features/reactions.md. */
const REACT_POLL = 250, SOCKET = `module.${ID}`, NEED_SIGHT = ["reactive-strike", "attack-of-opportunity", "nimble-dodge"];
export const reactionTimer = () => { const v = Math.round(Number(game.settings.get(ID, "reactionTimer")) || 0); return v <= 0 ? 0 : Math.max(5, Math.min(60, v)); };
/** A creature's reactions as react.mjs reads them: its actions and feats (a character's are mostly feats); Shield Block from a held shield that
    grants it without the feat (0.27.0: the module reads what the character can do); and its reaction spells, each with the rank it can be cast at
    now (null when no slot or use is left: its row then fits nothing). */
export function reactionsFor(actor) {
  const items = (actor?.items ?? []).filter(i => ["action", "feat"].includes(i.type)).map(i => ({ slug: i.slug ?? game.pf2e.system.sluggify(i.name), name: i.name, actionType: i.system.actionType?.value, description: i.system.description?.value ?? "" }));
  if (!items.some(i => i.slug === "shield-block" && i.actionType === "reaction")) { const id = actor?.attributes?.shield?.itemId, sh = id ? actor.items.get(id) : null;
    if (sh && shieldGrantsBlock({ slug: sh.slug, text: String(sh.system?.description?.value ?? "").replace(/@UUID\[[^\]]*\]\{([^}]*)\}/g, "$1").replace(/<[^>]+>/g, " ") })) items.push({ slug: "shield-block", name: "Shield Block", actionType: "reaction", description: "" }); }
  return reactionsOf([...items, ...reactionSpells(actor)]);
}
/** A creature's reaction spells as items for reactionsOf, each with where it is cast from and the lowest rank it can be cast at now. */
function reactionSpells(actor) {
  const out = [], focus = Number(actor?.system?.resources?.focus?.value) || 0;
  for (const e of actor?.spellcasting?.regular ?? []) { if (e.isRitual || !CASTERS.includes(e.category)) continue;
    for (const sp of e.spells?.contents ?? []) { if (sp.system?.time?.value !== "reaction") continue;
      out.push({ slug: sp.slug ?? game.pf2e.system.sluggify(sp.name), name: sp.name, actionType: "reaction", description: sp.system.description?.value ?? "", spell: { entryId: e.id, spellId: sp.id, rank: rankLeft(e, sp, focus) } }); } }
  return out;
}
/* the lowest rank a spell can be cast at now, read straight from the entry (no sheet data: this runs at every gate), or null */
function rankLeft(e, sp, focus) {
  const base = sp.rank ?? 1, slots = e.system?.slots ?? {}, ranks = Array.from({ length: 10 }, (_, k) => k + 1);
  if (sp.isCantrip) return base;
  if (e.isFocusPool) return focus > 0 ? base : null;
  if (e.isInnate) { const u = sp.system?.location?.uses; return !(u?.max > 0) || (Number(u.value) || 0) > 0 ? base : null; }
  if (e.isPrepared && !e.isFlexible) return castRank(base, ranks.map(r => ({ rank: r, left: (Array.isArray(slots[`slot${r}`]?.prepared) ? slots[`slot${r}`].prepared : Object.values(slots[`slot${r}`]?.prepared ?? {})).filter(x => x?.id === sp.id && !x.expended).length })));
  /* spontaneous or flexible: its own rank, and any higher one only when it is a signature spell */
  return castRank(base, ranks.filter(r => r === base || sp.system?.location?.signature).map(r => ({ rank: r, left: Number(slots[`slot${r}`]?.value) || 0 })));
}
/** What a reactor has for a monster's cast (0.36.0, Moment E): who (for `fits`) and the row's own fields (its numbers, its words). cast: { slug,
    name, rank, tradition, rarity, dc, damaging, teleport, monster (as players see it), gmMonster }. dist: feet from the caster. */
function castFacts(actor, x, cast, dist) {
  const entries = (actor?.spellcasting?.regular ?? []).filter(e => !e.isRitual && CASTERS.includes(e.category)), copies = [];
  let knowsIt = false;
  for (const e of entries) { const slots = e.system?.slots ?? {}, same = (e.spells?.contents ?? []).filter(sp => (sp.slug ?? "") === cast.slug); if (!same.length) continue;
    if (e.isPrepared && !e.isFlexible) { for (let r = 0; r <= 10; r++) { const list = Array.isArray(slots[`slot${r}`]?.prepared) ? slots[`slot${r}`].prepared : Object.values(slots[`slot${r}`]?.prepared ?? {});
        list.forEach((p, n) => { const sp = same.find(y => y.id === p?.id); if (!sp) return; knowsIt = true; if (!p.expended || sp.isCantrip) copies.push({ entryId: e.id, spellId: sp.id, rank: sp.isCantrip ? Math.max(1, Math.ceil((actor.level || 1) / 2)) : r, slot: n, kind: "prepared" }); }); } }
    else if (["spontaneous", "prepared"].includes(e.category)) { knowsIt = true;   /* a repertoire, or a flexible caster's collection (review 7) */
      const spont = e.category === "spontaneous";
      for (const sp of same) for (let r = sp.rank ?? 1; r <= 10; r++) if ((r === sp.rank || sp.system?.location?.signature) && (Number(slots[`slot${r}`]?.value) || 0) > 0) copies.push({ entryId: e.id, spellId: sp.id, rank: r, kind: spont ? "spontaneous" : "flexible", spontaneous: true }); } }
  const row = KNOWN[x.slug] ?? {}, who = { dist, knowsIt, tradition: x.spell ? actor.spellcasting?.get(x.spell.entryId)?.tradition ?? null : null, spellRank: x.spell?.rank ?? null };
  const counterMod = e => (e?.statistic?.check?.modifiers ?? []).filter(m => m.enabled && ["ability", "proficiency"].includes(m.type)).reduce((n, m) => n + m.modifier, 0);   /* Player Core pg. 431: attribute + proficiency */
  const out = { cast: { slug: cast.slug, name: cast.name, rank: cast.rank, monster: cast.monster } };
  const dcOk = Number.isFinite(Number(cast.dc)) && cast.dc != null;   /* no spell DC to roll against: never a counter (review 1) */
  if (row.counter === "same") { const usable = copies.filter(c => actor.spellcasting?.get(c.entryId)?.category === (row.entries === "spontaneous" ? "spontaneous" : "prepared"));
    const copy = dcOk ? counterCopy(usable, cast.rank) : null; who.hasSame = !!copy; if (copy) Object.assign(out, { copy, mod: counterMod(actor.spellcasting.get(copy.entryId)), dc: cast.dc }); }
  else if (row.counter === "siphon" && !dcOk) who.dist = Infinity;   /* out of its range: not asked */
  else if (row.counter === "siphon") Object.assign(out, { mod: counterMod(actor.spellcasting?.get(x.spell?.entryId)), dc: cast.dc, myRank: (x.spell?.rank ?? 5) + 2 });
  else if (row.counter === "auto") Object.assign(out, { rank: cast.rank });
  else if (row.recognize) { const skill = TRADITION_SKILL[cast.tradition], st = skill ? actor.skills?.[skill] : null, prof = Number(st?.rank) || 0;
    Object.assign(out, { skill, skillName: st?.label ?? skill, mod: Number(st?.mod) || 0, prof, rdc: recognizeDc(cast.rank, cast.rarity), rarity: cast.rarity, auto: prof > 0 && recognizeDegree(0, { prof, rank: cast.rank, rarity: cast.rarity }) >= 2 }); }
  const r = { slug: x.slug, reaction: row.name, ...out };
  out.detail = castDetail(r); out.words = castWords(r, cast.monster, cast.name); out.gmWords = castWords(r, cast.gmMonster, cast.name, true);
  if (out.detail) { out.words = `${out.words} (${out.detail})`; out.gmWords = `${out.gmWords} (${out.detail})`; }
  return { who, row: out };
}
/** The users who answer for an actor: its non-GM owners who are online. None: the GM answers on the card. */
const answerersOf = actor => game.users.filter(u => u.active && !u.isGM && actor?.testUserPermission?.(u, "OWNER")).map(u => u.id);
/** Does this creature perceive the monster now (observed or concealed)? Below ground or GM-hidden it doesn't; without Visioner, seen. */
function perceivesNow(observer, tok) {
  if (tok.hidden || isBelow(tok)) return false;
  const vis = visionerApi(); if (!vis) return true;
  try { return !HIDDEN.includes(vis.getVisibility(observer.id, tok.id) ?? "observed"); } catch { return true; }
}
/** The monster as a reactor may see it named: its token name when its name shows to players, otherwise "A creature". */
function moverName(tok) { const N = CONST.TOKEN_DISPLAY_MODES; return [N.ALWAYS, N.HOVER].includes(tok.displayName) ? tok.name : "A creature"; }
/** The highest circumstance bonus on a creature's AC now; without a raised shield's own (review finding 5: circumstance bonuses don't stack, so a new
    one adds only what it beats). */
function circNow(actor, { noShield = false } = {}) {
  return Math.max(0, ...(actor?.armorClass?.modifiers ?? []).filter(m => m.type === "circumstance" && m.enabled && m.modifier > 0 && !(noShield && /shield/i.test(`${m.slug ?? ""} ${m.label ?? ""}`))).map(m => m.modifier));
}
/** Who can react at this gate, with which reaction: characters on the other side, able to act, with a known reaction that fits; Reactive Strike and
    Nimble Dodge also need to perceive the monster (review finding 15: Shield Block and Reactive Shield don't). One row per reaction (`id`).
    o: { target, melee, damageTypes, at, elev (where it was, for reach), anyReach (route gates: reach is checked per square) } */
function reactorsFor(combat, tok, gate, o = {}) {
  const scene = sceneOf(combat), out = [], me = o.at ? { pos: o.at, span: sizeOf(tok) } : placeOf(tok, scene), myElev = o.elev ?? heightUp(tok);
  for (const c of combat.combatants) {
    const t = c.token, a = t?.actor;
    if (!t || t.id === tok.id || !reactsLikeParty(a) || !a.isEnemyOf?.(tok.actor) || t.hidden || t.getFlag(ID, "escaped") || isBelow(t)) continue;
    if (cantAct(a) || ["stunned", "confused"].some(k => a.hasCondition?.(k)) || (a.hitPoints?.value ?? 1) <= 0) continue;
    /* no reaction to use (0.27.0; Rhea, PR-6 and PR-11): its box is ticked, or it is Delaying (PF2e HUD's hourglass; Player Core pg. 416) */
    const spent = reactionUsed(combat, t.id) || turns(combat).reacted?.[t.id] ? "used" : c.getFlag(HUD, "delayed") ? "delaying" : null;   /* `reacted`: its own Reactive Strike, when the module runs it too (review 12) */
    const reach = a.getReach?.({ action: "attack" }) ?? 5, p = placeOf(t, scene), sees = perceivesNow(t, tok);
    const dist = distanceBetween({ x: me.pos[0], y: me.pos[1], size: me.span, elev: myElev }, { x: p.pos[0], y: p.pos[1], size: p.span, elev: heightUp(t) }, { reach });
    const sh = a.attributes?.shield, ally = !!o.target?.actor && o.target.id !== t.id && !!a.isAllyOf?.(o.target.actor);
    const who = { inReach: !cantAttack(a) && (o.anyReach || dist <= reach), isTarget: o.target?.id === t.id, isAlly: ally, shieldRaised: !!sh?.raised && !sh?.broken, hasShield: !!sh?.itemId && !sh?.broken && (sh?.ac ?? 0) > 0 };
    for (const x of reactionsFor(a)) { if (!x.known || !(sees || !(NEED_SIGHT.includes(x.slug) || KNOWN[x.slug]?.sees))) continue;
      const row = KNOWN[x.slug], cf = gate === "cast" && o.cast ? castFacts(a, x, o.cast, dist) : null, w = { ...who, ...(cf?.who ?? {}), canCast: !x.spell || x.spell.rank != null, inAura: !!row.aura && ally && inAura(t, row.aura, [tok, o.target]) };
      if (!fits(x.slug, gate, w, { melee: !!o.melee, damageTypes: o.damageTypes ?? [], ...(o.cast ?? {}) })) continue;
      if (spent) { o.skipped?.push({ name: t.name, reaction: x.name, why: spent, token: t.id, pos: p.pos, span: p.span, elev: heightUp(t), reach }); continue; }
      out.push({ id: `${t.id}:${x.slug}`, token: t.id, actor: a.id, name: t.name, reaction: x.name, slug: x.slug, gate, pos: p.pos, span: p.span, elev: heightUp(t), reach,
        ...(o.kind ? { kind: o.kind } : {}), ...(x.spell ? { spell: x.spell } : {}), ...(cf?.row ?? {}), ...(row.aura ? { value: glimpseResistance(a.level), guilt: a.items.some(it => it.slug === "weight-of-guilt") } : {}) }); }
  }
  return out;
}
/** Who is asked and has a reaction box (Rhea, 2026-11-11, PR-11): a character, or an ordinary NPC fighting on the party's side; never a minion. */
const reactsLikeParty = a => !!a && canReact({ type: a.type, traits: [...(a.traits ?? a.system?.traits?.value ?? [])] }) && (a.isOfType?.("character") || a.alliance === "party");
/** Are all of these inside a creature's aura (its champion's aura) now? The aura is PF2e's own, read from the creature: no aura when it is suppressed
    or its bearer is unconscious, and a feat that changes its size is followed (Rhea, PR-8). PF2e's own test where the map is drawn on this page;
    otherwise the distance from the bearer's edge, as an emanation is measured. */
function inAura(holder, slug, others) {
  const aura = holder.auras?.get?.(slug) ?? null, radius = Number(aura?.radius ?? holder.actor?.auras?.get?.(slug)?.radius) || 0; if (!(radius > 0)) return false;
  const scene = holder.parent, p = placeOf(holder, scene);
  return others.every(x => { if (!x) return false;
    if (typeof aura?.containsToken === "function" && holder.object && x.object) { try { return !!aura.containsToken(x); } catch (e) { console.warn(`${ID} | aura`, e); } }
    const q = placeOf(x, scene); return distanceBetween({ x: p.pos[0], y: p.pos[1], size: p.span, elev: heightUp(holder) }, { x: q.pos[0], y: q.pos[1], size: q.span, elev: heightUp(x) }, { reach: radius }) <= radius; });
}
/** Was this gate of this step asked already (before a reload, a hold or a stop)? Then its stored answers stand and nobody is listed as "not asked". */
const askedBefore = (combat, id, i, key) => !!request(combat, id)?.gates?.[i]?.[key];
/** The note for reactions that fit but weren't asked ("Shield Block not asked (reaction already used)"), once each. */
async function noteSkipped(combat, id, skipped = []) {
  const seen = new Set(), list = skipped.filter(x => { const k = `${x.name}.${x.reaction}`; if (seen.has(k)) return false; seen.add(k); return true; });
  const words = notAskedWords(list); if (words && !String(request(combat, id)?.note ?? "").includes(words)) await addNote(combat, id, words);
}

/* ---------- the party's reaction boxes (0.27.0) ---------- */
/* Rhea, 2026-11-11 (PR-2, PR-3, PR-9): "a checkbox ... to track if a player has their reaction still for that round. It would auto track when an
   action is used that consumes it and it would come back at the start of their turn. I'd treat it like a focus point." The boxes live on the
   Combat's flag (`turns.rx.<token id>`): ticked by the module when React is pressed in one of its questions or a reaction's card shows, or by hand
   (the GM for anyone, a player for their own character, through the runner); cleared when that creature's turn begins. A new fight has none, so
   everyone starts with their reaction ready. Nothing is put on tokens or in PF2e HUD's tracker. */
export const reactionUsed = (combat, tokenId) => turns(combat).rx?.[tokenId] ?? null;
/** The rows of the Party reactions block and the players' chips: every creature on the party's side that can react. */
export function partyReactors(combat) {
  const out = []; if (!combat?.started) return out;
  for (const c of combat.combatants) { const t = c.token, a = t?.actor; if (!t || !a || c.defeated || a.alliance !== "party" || !reactsLikeParty(a)) continue;
    const ready = turns(combat).ready?.[t.id] ?? null, waiting = Object.entries(turns(combat).requests ?? {}).find(([, r]) => r?.readied?.tokens?.includes(t.id) && r.round === combat.round)?.[0] ?? null;
    out.push({ id: t.id, name: t.name, used: reactionUsed(combat, t.id), delaying: !!c.getFlag(HUD, "delayed"), mine: !game.user.isGM && !!a.testUserPermission?.(game.user, "OWNER"), ready, waiting }); }
  return out;
}
const writeUsed = (combat, tokenId, v) => saveTurns(combat, { [`rx.${tokenId}`]: v ? whole({ round: combat.round, at: Date.now(), ...v }) : null });
/** Tick or clear a box by hand: a GM for anyone, a player for a character they own (the runner writes it for them). */
export async function setReactionUsed(combat, tokenId, used) {
  const t = sceneOf(combat)?.tokens.get(tokenId); if (!t?.actor || !combat.started) return;
  if (!game.user.isGM) { if (!t.actor.testUserPermission(game.user, "OWNER")) return; return emitSocket({ t: "rx", combat: combat.id, token: tokenId, used: !!used }); }
  await writeUsed(combat, tokenId, used ? { by: "hand", user: game.user.name } : null);
}
/** The module's own tick: a reaction it saw used. Never over a box already ticked. */
async function markUsed(combat, tokenId, reaction, by = "module") { if (!isRunner() || !combat?.started || reactionUsed(combat, tokenId)) return; await writeUsed(combat, tokenId, { by, reaction }); }
/** A reaction used outside the module's questions (the runner's `createChatMessage` hook): the card of a reaction, or of a reaction spell being
    cast, ticks its owner's box. A card can also be an ability only shown in chat, which is why the box can be cleared with a click. */
export function onReactionCard(message) {
  if (!isRunner()) return;
  const tok = message.speaker?.token ? game.scenes.get(message.speaker.scene)?.tokens.get(message.speaker.token) : null, combat = tok && fightOf(tok);
  if (!combat || tok.actor?.alliance !== "party" || !reactsLikeParty(tok.actor) || reactionUsed(combat, tok.id)) return;
  const f = message.flags?.pf2e ?? {}; if (f.context?.type && f.context.type !== "spell-cast") return;   /* a roll's card follows an action already seen */
  let item = null; try { item = message.item ?? (f.origin?.uuid ? fromUuidSync(f.origin.uuid) : null); } catch { item = null; }
  if (!item) return;
  const used = item.type === "spell" ? item.system?.time?.value === "reaction" && !!f.casting : ["action", "feat"].includes(item.type) && item.system?.actionType?.value === "reaction";
  if (used) markUsed(combat, tok.id, item.name, "card").catch(e => console.warn(`${ID} | reaction box`, e));
}
/* ---------- Ready (0.35.0; Rhea, 2026-11-16, q-37: ""Now!" button (Recommended)") ---------- */
/* A Ready card posted by a party member marks them readied (`turns.ready.<token id>`: the round, and the trigger the player types on the chip, may be
   blank). While anyone readied still has their reaction, each monster step waits READY_WAIT_MS before it resolves (and once after the last), and a
   move goes a square at a time. Now! ticks the reaction box, clears Readied and puts the character on the turn in hand (`readied`): the running step
   waits where it is (before the step, or in the square a move was entering), as it waits for a reaction question, until that player's Done or her
   Continue; then the look before the step runs again (a move goes on from where it stopped). A turn not running when Now! comes waits the same way
   once Do it or Auto runs it. Readied clears at that character's next turn (or a round later if that turn never comes), on Now!, or by Clear on her
   card. Rules: Ready, Player Core pg. 417, checked on Archives of Nethys 2026-11-16 (it uses the reaction; it lasts until the start of the reader's
   next turn). */
async function setReady(combat, tok) {
  if (!isRunner() || !combat?.started || tok.actor?.alliance !== "party" || !reactsLikeParty(tok.actor) || !combat.combatants.some(c => c.tokenId === tok.id)) return;
  const was = turns(combat).ready?.[tok.id];
  await saveTurns(combat, { [`ready.${tok.id}`]: whole({ round: combat.round, at: Date.now(), trigger: was?.trigger ?? "" }) });
}
/** Who is readied and can still act on it now: their reaction unused, in this fight, standing, and readied this round or the last (a readied
    action lasts until the start of their next turn: a character whose turn never came isn't readied for ever). [{ id, name, trigger }] */
export function readiedNow(combat) {
  const out = []; if (!combat?.started) return out;
  for (const [id, v] of Object.entries(turns(combat).ready ?? {})) { if (!v) continue; const c = combat.combatants.find(x => x.tokenId === id), t = c?.token;
    if (!t?.actor || c.defeated || reactionUsed(combat, id) || isDown(t.actor) || (Number(v.round) || 0) < combat.round - 1) continue; out.push({ id, name: t.name, trigger: v.trigger ?? "" }); }
  return out;
}
/** The chip's and the card's buttons: a player's go to the runner by socket; on the runner they act at once. op: "text" (the trigger), "now",
    "done" (also her Continue, with the turn's request id), "clear" (a GM's). */
export async function readyAct(combat, tokenId, op, text = "", requestId = null) {
  if (!["text", "now", "done", "clear"].includes(op)) return;
  if (op === "clear" && !game.user.isGM) return;
  if (isRunner()) return readyNowOn(combat, tokenId, op, text, game.user, requestId);
  emitSocket({ t: "ready", combat: combat.id, token: tokenId, op, text: op === "text" ? cleanTrigger(text) : "", request: requestId });
}
async function readyNowOn(combat, tokenId, op, text, from, requestId = null) {
  if (op === "done") {
    /* her Continue ends the wait for everyone on that turn; a player's Done only for their own character, on this round's turn */
    const reqs = Object.entries(turns(combat).requests ?? {}).map(([id, x]) => ({ ...x, id }));
    const r = from?.isGM && requestId ? reqs.find(x => x.id === requestId && x.readied) : reqs.find(x => x.round === combat.round && x.readied?.tokens?.includes(tokenId));
    if (!r) return;
    const left = from?.isGM && requestId ? [] : r.readied.tokens.filter(t => t !== tokenId);
    await save(combat, r.id, { readied: left.length ? whole({ ...r.readied, tokens: left, names: r.readied.names.filter((_, k) => r.readied.tokens[k] !== tokenId) }) : null });
    return;
  }
  const t = sceneOf(combat)?.tokens.get(tokenId); if (!t) return;
  const was = turns(combat).ready?.[tokenId];
  if (op === "text") { if (was) await saveTurns(combat, { [`ready.${tokenId}`]: whole({ ...was, trigger: cleanTrigger(text) }) }); return; }   /* the whole record: never a field on one just cleared */
  if (op === "clear") { await saveTurns(combat, { [`ready.${tokenId}`]: null }); return; }
  /* now */
  if (!was || reactionUsed(combat, tokenId)) return;
  await saveTurns(combat, { [`ready.${tokenId}`]: null, [`rx.${tokenId}`]: whole({ round: combat.round, at: Date.now(), by: "ready", reaction: "Ready", user: from?.name ?? null }) });   /* Now! ticks the box: Ready is the reaction */
  const r = currentRequest(combat);
  if (!r || r.reaction || ["done", "manual", "fled"].includes(r.state)) return;   /* no monster turn to wait: the player acts, the box shows it */
  const rd = r.readied ?? { tokens: [], names: [], moved: false };
  await save(combat, r.id, { readied: whole({ ...rd, tokens: [...rd.tokens, tokenId], names: [...rd.names, t.name], at: Date.now() }) });
}
/** While a readied action is being taken (Now! pressed), the step waits where it is. Returns "ok" once everyone readied pressed Done (or she pressed
    Continue), "manual" (Play it myself) or "gone" (the turn moved on). moved: it waits in the middle of a move. */
async function waitReadied(combat, id, moved = false) {
  if (moved && request(combat, id)?.readied && !request(combat, id).readied.moved) await save(combat, id, { "readied.moved": true });
  for (;;) {
    const n = request(combat, id); if (!n?.readied?.tokens?.length) return "ok";
    if (n.state === "manual") return "manual"; if (turnMovedOn(combat, n)) return "gone";
    await new Promise(r => setTimeout(r, 250));
  }
}
/** Before a monster step resolves, while someone is readied: wait READY_WAIT_MS for a Now!, and then for the readied action. "ok" to go on with the
    step (the caller looks again if a readied action was taken: `took`), "manual", "gone", or "held" (Hold pressed meanwhile). */
async function readyWindow(combat, id) {
  let took = false;
  if (request(combat, id)?.readied) { took = true; const w = await waitReadied(combat, id); if (w !== "ok") return { w }; }
  if (!readiedNow(combat).length) return { w: "ok", took };
  const end = Date.now() + READY_WAIT_MS;
  while (Date.now() < end) {
    await new Promise(r => setTimeout(r, 150)); const n = request(combat, id);
    if (!n || n.state === "manual") return { w: "manual" }; if (turnMovedOn(combat, n)) return { w: "gone" }; if (n.hold) return { w: "held" };
    if (n.readied) { const w = await waitReadied(combat, id); return w === "ok" ? { w: "ok", took: true } : { w }; }
  }
  return { w: "ok", took };
}
/** What the turn does after the wait: null to go on, or the request's ending. */
const readyEnd = (combat, id, i, w) => w === "manual" ? save(combat, id, { state: "manual" }).then(() => true) : w === "gone" ? save(combat, id, { state: "stopped", pos: i, note: joinNote(combat, id, `The turn moved on during a readied action, before step ${i + 1}.`) }).then(() => true) : w === "held" ? save(combat, id, { state: "held", hold: false, pos: i, note: "Held before the next step." }).then(() => true) : null;
/* Attack rolls made while a question is open, from any page (the createChatMessage hook): a Reactive Strike's critical hit disrupts a manipulate action.
   Collected on the runner by the hook, not compared by clocks (review finding 14). */
const rxWatch = new Map();
export function noteReactionRoll(message) {
  if (!rxWatch.size || message.flags?.pf2e?.context?.type !== "attack-roll") return;
  const r = { actor: message.actor?.id ?? message.speaker?.actor ?? null, target: String(message.flags.pf2e.context.target?.token ?? ""), outcome: message.flags.pf2e.context.outcome ?? null };
  for (const w of rxWatch.values()) w.push(r);
}
const strip = ({ users, words, gmWords, pos, span, elev, reach, ...x }) => x;
/** Ask the reactions in `list` and wait: players by a prompt in their browser, the GM on the card. key names the gate within step i ("before",
    "move:<route index>", "stay", "hit"). Returns { done, list (each with its answer), rolls (attack rolls made meanwhile), held } once everyone has
    answered, passed, run out of time, the GM pressed Continue or Hold, or the monster went down; "manual" when the GM took the turn; "gone" when the
    turn moved on. Each gate is asked once: a reload while asking keeps what was answered and skips the rest, with a note (review finding 2). The
    question (`react`) is cleared on every way out (review finding 3). */
async function askReactions(combat, id, i, key, gate, tok, list, kind = "", gmKind = null) {
  /* what was asked once is never worked out again (0.27.0, seen live: after a reload the champion who had reacted had her box ticked, so her row was
     gone from a fresh list, and her answer with it): the stored question wins over whatever `list` holds now */
  const had = request(combat, id).gates?.[i]?.[key];
  if (had?.done) return had;
  if (!had && !list.length) return { done: true, list: [], rolls: [] };
  if (had) {
    const rx = request(combat, id).react, ans = rx?.key === key ? rx.answers ?? {} : {}, final = (rx?.key === key ? rx.list : []).map(x => ({ ...strip(x), answer: ans[x.id] ?? "continue" }));
    await save(combat, id, { react: null, gates: { [i]: { [key]: whole({ done: true, list: final, reloaded: true }) } }, note: joinNote(combat, id, `The page reloaded while ${tok.name}'s ${gate === "hit" ? "hit" : "action"} waited for reactions: what was answered stands and the rest were skipped. Check the chat for a reaction already rolled.`) });
    emitSocket({ t: "close", combat: combat.id, request: id, key });
    /* what was answered before the reload still counts (review 8): its box is ticked, and a reaction spell is cast */
    for (const x of final) if (!x.free && x.answer === "done") { await markUsed(combat, x.token, x.reaction); if (x.spell && !KNOWN[x.slug]?.pause) await castReaction(combat, id, x); }
    return { done: true, list: final, rolls: [], reloaded: true };
  }
  const who = moverName(tok), start = request(combat, id), watchKey = `${combat.id}.${id}.${i}.${key}`, rolls = [];
  /* each row is worded by its own gate (a question can hold rows of several: a Strike in reach asks Reactive Strike and Nimble Dodge together) */
  const asked = list.map(x => { const users = answerersOf(sceneOf(combat).tokens.get(x.token)?.actor ?? game.actors.get(x.actor)), g = x.gate ?? (x.slug === "nimble-dodge" ? "attack" : gate), k = x.kind ?? kind;
    return { ...strip(x), to: users.length ? "player" : "gm", users, words: x.words ?? gateWords(g, who, { kind: k, reaction: x.reaction }), gmWords: x.gmWords ?? gateWords(g, tok.name, { kind: x.gmKind ?? (x.kind ? k : gmKind ?? k), reaction: x.reaction }) }; });   /* a spell's name only on her card (0.36.0, review 5) */   /* the GM's card names the monster (seen live: "A creature" on her own card) */
  /* the countdown is for players' windows only: a row the GM answers on her card waits for React, Pass or Continue (Rhea, 2026-11-09, 0.20.1) */
  const until = untilFor(asked, reactionTimer(), clock());
  /* `since` moves on: waiting for a reaction is a wait on a person for the stall check (brain.mjs stallOf, review finding 9) */
  await save(combat, id, { react: whole({ key, step: i, gate, list: asked, until, answers: {}, cont: false }), since: clock(), gates: { [i]: { [key]: { asked: clock() } } } });
  rxWatch.set(watchKey, rolls);
  emitSocket({ t: "ask", combat: combat.id, request: id, key, until, list: asked.filter(x => x.to === "player") });
  let out = "done", held = false; const marked = new Set();
  const skip = async (n, as) => { for (const x of asked) if (!n?.react?.answers?.[x.id] || n.react.answers[x.id] === "react") await save(combat, id, { [`react.answers.${x.id}`]: n?.react?.answers?.[x.id] === "react" ? "done" : as }); };   /* a reactor who pressed React used it (0.33.1, review): "done", not skipped */   /* one key each, so an answer arriving now isn't overwritten (review finding 12) */
  try {
    for (;;) {
      await sleep(REACT_POLL);
      const n = request(combat, id), rx = n?.react;
      if (!n || n.state === "manual") { out = "manual"; break; }
      if (!game.combats.has(combat.id) || combat.round !== start.round || combat.combatant?.id !== (start.reaction ? start.turnOf : start.combatantId)) { out = "gone"; break; }   /* a monster's reaction (0.21.0) belongs to the turn it was made on */   /* review finding 10 */
      if (!rx || rx.key !== key) break;
      if (n.hold) { held = true; await skip(n, "continue"); break; }
      if (rx.cont) { await skip(n, "continue"); break; }
      /* a reaction being used ticks its owner's box at once, and that creature's other rows in this question are skipped: one reaction (0.27.0) */
      for (const x of asked) if (!x.free && ["react", "done"].includes(rx.answers?.[x.id]) && !marked.has(x.token)) { marked.add(x.token); await markUsed(combat, x.token, x.reaction); }
      for (const rid of spentRows(asked, rx.answers ?? {})) { await save(combat, id, { [`react.answers.${rid}`]: "continue" }); emitSocket({ t: "close", combat: combat.id, request: id, key, row: rid }); }
      if (until && clock() >= until) for (const x of asked) if (x.to === "player" && !rx.answers?.[x.id]) await save(combat, id, { [`react.answers.${x.id}`]: "timeout" });
      if (finished(asked.map(x => ({ answer: request(combat, id)?.react?.answers?.[x.id] })))) break;
      if (downNow(tok)) { await skip(n, "continue"); break; }
    }
  } finally { rxWatch.delete(watchKey); }
  const answers = request(combat, id)?.react?.answers ?? {}, final = asked.map(x => ({ ...strip(x), answer: answers[x.id] ?? "continue" }));
  await save(combat, id, { react: null, since: clock(), gates: { [i]: { [key]: whole({ done: true, list: final, rolls }) } } });
  noteReactionAnswers(combat, tok, final);   /* fight memory (0.25.0): who strikes at a move, who blocks */
  emitSocket({ t: "close", combat: combat.id, request: id, key });
  if (out !== "done") return out;
  if (final.some(x => x.answer === "done" && !x.free)) await addNote(combat, id, `Reactions: ${answerWords(final.filter(x => !x.free && !(x.group && x.answer === "continue"))).join("; ")}.`);   /* not a champion's rows for the allies it didn't pick */
  /* a reaction spell is cast for real: its slot is spent and its card shows (0.27.0) */
  for (const x of final) if (x.answer === "done" && x.spell && !KNOWN[x.slug]?.pause) await castReaction(combat, id, x);   /* a Pause row's spell is the player's to cast (0.36.0) */
  return { done: true, list: final, rolls, held };
}
const downNow = tok => !!tok.actor?.isDead || (tok.actor?.hitPoints?.value ?? 1) <= 0;
/** Cast a reaction spell for its caster (React was pressed for it): the entry's own cast, as a sheet's Cast does. Its card is a manipulate action when
    the spell is, so a monster's Reactive Strike to it is offered by the usual watcher, and one taken by itself (Auto) goes first: the turn's own
    action steps aside for it (one roller at a time). */
async function castReaction(combat, id, x) {
  const actor = sceneOf(combat).tokens.get(x.token)?.actor, entry = actor?.spellcasting?.get(x.spell.entryId), spell = entry?.spells?.get(x.spell.spellId);
  if (!entry || !spell || x.spell.rank == null) { await addNote(combat, id, `I couldn't cast ${x.reaction} for ${x.name}: spend ${pro("{their}", P(sceneOf(combat).tokens.get(x.token ?? x.id), combat))} slot yourself.`); return; }
  try { await watched(() => entry.cast(spell, { rank: x.spell.rank, consume: true })); }
  catch (e) { console.error(`${ID} | reaction spell`, e); await addNote(combat, id, `I couldn't cast ${x.reaction} for ${x.name} (${e.message}): spend ${pro("{their}", P(sceneOf(combat).tokens.get(x.token ?? x.id), combat))} slot yourself.`); return; }
  const autoOpen = () => queued.size > 0 || openReactions(combat).some(r => r.id !== id && r.reaction?.auto && ["ready", "running"].includes(r.state));   /* never itself: a monster's own Reactive Strike can be the one asking (review 1) */
  let seen = false; for (let t = 0; t < 8 && !seen; t++) { await sleep(250); seen = autoOpen(); }
  if (!seen || !running.has(id)) return;
  running.delete(id); try { for (let t = 0; t < 300 && autoOpen(); t++) await sleep(200); } finally { running.add(id); }
}
/** After the reactions to a monster's cast (0.36.0, Moment E): each one used is carried out once. Counterspell spends the reactor's copy and rolls
    the counteract check; Nullify counteracts at once and costs its caster HP; Shadow Siphon rolls and halves the damage on a success; Recognize
    Spell is rolled in secret and told to that player only (in their window, never a whispered card) and to the GM's card; a Pause row (Mimic
    Spell, Spell Riposte, Redirect Teleportation) stops the turn before the spell so the GM can rule on it. Returns "countered", "paused", "ask"
    or null. What was done is kept on the gate (`counter`), so a Do it after a stop never rolls again. */
async function castAnswers(combat, id, i, step, tok, list, cast) {
  const used = list.filter(x => x.answer === "done" && x.gate === "cast"); if (!used.length) return null;
  const had = request(combat, id).gates?.[i]?.counter;
  if (had?.result) return had.result === "paused" ? null : had.result === "countered" ? "countered" : null;   /* paused once: her Do it means go on */
  if (had?.started) { await addNote(combat, id, `The page reloaded while ${tok.name}'s ${cast.name} was being countered: check the chat for the counteract check and spend any slot yourself. If it was countered, play the rest of the turn yourself; if not, Do it casts the spell.`); await save(combat, id, { gates: { [i]: { counter: { result: "ask" } } } }); return "ask"; }
  await save(combat, id, { gates: { [i]: { counter: { started: true } } } });
  const scene = sceneOf(combat); let result = null, siphon = false;
  const roll = async (x, mod, dc, mine, reaction) => {
    const r = await new Roll(`1d20 + ${Number(mod) || 0}`).evaluate(), nat = r.dice[0]?.results?.[0]?.result ?? r.total - mod, degree = degreeAgainst(r.total, nat, dc), ok = counteracts(degree, mine, cast.rank);
    const line = counterLine({ who: x.name, reaction, monster: cast.monster, spell: cast.name, total: r.total, dc, degree, ok, halved: x.slug === "shadow-siphon" });
    await watched(() => r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: scene.tokens.get(x.token) }), flavor: `<p>${esc(line)}</p>` }));   /* for everyone (PR-10) */
    await addNote(combat, id, line); return ok; };
  for (const x of used) { const a = scene.tokens.get(x.token)?.actor; if (!a) continue;
    try {
      if (result === "countered" && (x.slug.startsWith("counterspell") || ["nullify", "shadow-siphon"].includes(x.slug))) { await addNote(combat, id, `${x.name}'s ${x.reaction} wasn't needed: the spell was already countered (nothing spent).`); continue; }
      if (x.slug.startsWith("counterspell")) {
        const e = a.spellcasting?.get(x.copy?.entryId), sp = e?.spells?.get(x.copy?.spellId);
        let spent = false; try { spent = !!(e && sp && await e.consume(sp, x.copy.rank, x.copy.slot)); } catch (err) { console.warn(`${ID} | counterspell slot`, err); }
        if (!spent) await addNote(combat, id, `I couldn't spend ${x.name}'s ${cast.name} for Counterspell: spend it yourself.`);
        if (await roll(x, x.mod, x.dc, x.copy?.rank ?? cast.rank, "Counterspell")) result = "countered";
      } else if (x.slug === "nullify") {
        const hp = await new Roll(`${Math.max(1, cast.rank)}d8`).evaluate(), now = a.hitPoints?.value ?? 0, left = Math.max(0, now - hp.total);
        await a.update({ "system.attributes.hp.value": left });
        const line = `${x.name} uses Nullify on ${String(cast.monster).replace(/^A creature$/, "a creature")}'s ${cast.name}: it is counteracted automatically, and the feedback costs ${x.name} ${hp.total} HP (${cast.rank}d8).`;
        await watched(() => hp.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: scene.tokens.get(x.token) }), flavor: `<p>${esc(line)}</p>` }));
        await addNote(combat, id, line); result = "countered";
        if (left === 0) await addNote(combat, id, `${x.name} is at 0 HP from Nullify: apply Dying as for any drop to 0 (it is HP lost, so the module didn't).`);   /* review 8 */
      } else if (x.slug === "shadow-siphon") { if (await roll(x, x.mod, x.dc, x.myRank, "Shadow Siphon")) siphon = true; }
      else if (x.slug === "recognize-spell") {
        const r = await new Roll(`1d20 + ${Number(x.mod) || 0}`).evaluate(), nat = r.dice[0]?.results?.[0]?.result ?? 10;
        const degree = recognizeDegree(degreeAgainst(r.total, nat, x.rdc), { prof: x.prof, rank: cast.rank, rarity: x.rarity }), words = recognizeWords(degree, cast.name, cast.rank);
        const users = answerersOf(a); if (users.length) emitSocket({ t: "told", users, title: `Recognize Spell: ${x.name}`, lines: [words] });
        await addNote(combat, id, `${x.name}'s Recognize Spell (rolled in secret: ${r.total} vs DC ${x.rdc}, ${CHECK_OUTCOMES[degree]}): ${degree === 0 ? `tell ${pro("{them}", P(scene.tokens.get(x.token), combat))} it is another spell of your choice.` : users.length ? `told ${pro("{them}", P(scene.tokens.get(x.token), combat))}: "${words}"` : `tell ${pro("{them}", P(scene.tokens.get(x.token), combat))}: "${words}"`}`);
        if (degree === 3) await a.createEmbeddedDocuments("Item", [{ name: "Recognize Spell (+1)", type: "effect", img: "icons/svg/eye.svg", system: { rules: ["ac", "saving-throw"].map(selector => ({ key: "FlatModifier", selector, type: "circumstance", value: 1, label: "Recognize Spell", slug: "leb-recognize-spell" })), duration: { value: -1, unit: "unlimited" } }, flags: { [ID]: { recognize: true } } }]);   /* against this spell only: gone when the step ends */
      } else if (KNOWN[x.slug]?.pause) { result = result ?? "paused"; await addNote(combat, id, `${x.name} used ${x.reaction} against ${tok.name}'s ${cast.name}. Rule on it with ${pro("{their}", P(scene.tokens.get(x.token), combat))} player (the counteract and what happens to the spell), then press Do it to cast the spell anyway, or play the rest yourself.`); }
    } catch (err) { console.error(`${ID} | cast reaction`, err); await addNote(combat, id, `I couldn't finish ${x.name}'s ${x.reaction} (${err.message}): resolve it yourself.`); result = result ?? "paused"; }
  }
  if (result === "countered") { const f = spellFor(tok.actor, step);   /* a countered spell is lost: its slot or use is spent all the same */
    try { if (f && !(await f.entry.consume(f.spell, Number(step.rank ?? f.spell.rank) || 1))) await addNote(combat, id, `Spend ${tok.name}'s ${cast.name} (slot or use) yourself.`); } catch (err) { console.warn(`${ID} | countered slot`, err); await addNote(combat, id, `Spend ${tok.name}'s ${cast.name} (slot or use) yourself.`); } }
  if (siphon && result !== "countered" && (step.mode === "card" || (step.area?.aim && step.mode !== "area") || !applySetting())) await addNote(combat, id, `Halve ${step.itemName ?? "the spell"}'s damage for everyone it hurts (Shadow Siphon).`);   /* review 9: damage the module doesn't apply itself */
  await save(combat, id, { gates: { [i]: { counter: { started: true, result: result ?? "none" } } }, ...(siphon ? { log: { [i]: { siphon: true } } } : {}) });
  return result;
}
/** Before an action that isn't a move: a manipulate action (Release excepted: it triggers no such reactions, Player Core pg. 417, review finding 4), a
    ranged attack, a Strike at a character (Nimble Dodge). Returns null to go on, "disrupted", "down", "held", "ask", "manual" or "gone". */
async function beforeAction(combat, id, i, step, tok, target) {
  const w = beforeKinds(tok.actor, step, target);
  if (!w.manipulate && !w.ranged && !w.attack && !w.area && !w.cast) return null;
  const list = [], skipped = [], add = l => { for (const x of l) if (!list.some(y => y.id === x.id)) list.push(x); };
  if (w.manipulate) add(reactorsFor(combat, tok, "manipulate", { skipped }));
  if (w.ranged) add(reactorsFor(combat, tok, "ranged", { skipped }));
  if (w.attack && target) add(reactorsFor(combat, tok, "attack", { target, skipped }));
  /* a damaging area with a Reflex save (0.27.0): each creature it will catch that can answer it (Interposing Earth), before the spell is cast */
  if (w.area) { const scene = sceneOf(combat); let ids = []; try { ids = coverage(scene, tok, step.area.aim, { square: squareOf(tok, scene), size: sizeOf(tok), elev: Number(tok.elevation) || 0 }).ids; } catch (e) { console.warn(`${ID} | area reactions`, e); }
    for (const t of ids) { const caught = scene.tokens.get(t); if (caught && !caught.hidden) add(reactorsFor(combat, tok, "area", { target: caught, kind: "spell", skipped }).map(x => ({ ...x, gmKind: step.itemName }))); } }   /* the players' window says "spell", her card its name (0.36.0, review 5) */
  /* a monster casting (0.36.0, Moment E): Counterspell, Recognize Spell, Nullify, Shadow Siphon and the Pause rows, in the same question */
  if (w.cast) add(reactorsFor(combat, tok, "cast", { target: step.area?.aim ? null : target, cast: w.cast, kind: w.cast.name, skipped }));
  if (!askedBefore(combat, id, i, "before")) await noteSkipped(combat, id, skipped);
  const res = await askReactions(combat, id, i, "before", w.manipulate ? "manipulate" : w.ranged ? "ranged" : w.attack ? "attack" : w.area ? "area" : "cast", tok, list, w.kind, w.gmKind ?? null);
  if (typeof res === "string") return res;
  /* Interposing Earth against an area: standard cover on the Reflex save, as PF2e's own Effect: Cover, taken off when the step ends */
  for (const x of res.list) if (x.answer === "done" && x.slug === "interposing-earth" && x.gate === "area") { const a = sceneOf(combat).tokens.get(x.token)?.actor;
    try { if (a && !(a.itemTypes?.effect ?? []).some(e => e.getFlag?.(ID, "earth"))) await addEarthCover(a);   /* once: a step held and started again comes back here (review 9) */
      /* an area the GM resolves from its card (review 2): the cover stays until the turn moves on, and the 2 off is hers to take */
      if (a && step.mode !== "area") await addNote(combat, id, `${x.name} used Interposing Earth against ${step.itemName}: ${pro("{they} {has|have} cover for {their} save", P(sceneOf(combat).tokens.get(x.token ?? x.id), combat))} until this turn ends; take ${earthLess(x.spell?.rank)} off the damage ${pro("{they} {takes|take}", P(sceneOf(combat).tokens.get(x.token ?? x.id), combat))} yourself (the barrier is then destroyed), or if none is taken it stands for 3 rounds (AC 5, Hardness ${barrierStats(x.spell?.rank).hardness}, ${barrierStats(x.spell?.rank).hp} HP): yours to put on the map and rule on, since you resolve this area.`); } catch (e) { console.error(`${ID} | cover`, e); await addNote(combat, id, `I couldn't give ${x.name} cover from Interposing Earth (${e.message}): add 2 to ${pro("{their}", P(sceneOf(combat).tokens.get(x.token ?? x.id), combat))} Reflex save.`); } }
  if (downNow(tok)) return "down";
  if (res.held) return "held";
  const struck = new Set(res.list.filter(x => x.answer === "done" && KNOWN[x.slug]?.reach).map(x => x.actor));
  if (w.manipulate && (res.rolls ?? []).some(r => struck.has(r.actor) && r.target.endsWith(tok.id) && r.outcome === "criticalSuccess")) return "disrupted";
  /* the counters to a cast (0.36.0) only once the caster is still up, the turn not held and the spell not disrupted (review 2) */
  if (w.cast) { const c = await castAnswers(combat, id, i, step, tok, res.list, w.cast); if (c) return c; }
  return null;
}
/** What an action is for the reaction gates: { manipulate, ranged, attack, kind (words) }. Nimble Dodge is asked only for a Strike, the one attack whose
    degree the module reads again (review finding 7). */
function beforeKinds(actor, step, target) {
  const pc = reactsLikeParty(target?.actor);   /* a character, or an NPC ally on the party's side (0.27.0) */
  if (step.do === "interact" || step.do === "draw") return { manipulate: true, kind: "Interact" };
  if (step.do === "point-out") return { manipulate: true, kind: "Point Out" };   /* 0.30.0 */
  if (step.do === "strike") { const s = strikesWithIds(actor).find(x => x.id === step.item)?.strike; return { ranged: !!s?.item?.isRanged, attack: pc, kind: "Strike" }; }
  if (step.do === "ability") { const ab = abilityList(actor).find(a => a.id === step.item), tr = ab?.traits ?? []; if (ab?.followUp) return {}; return { manipulate: tr.includes("manipulate"), kind: ab?.name ?? "" }; }
  if (step.do === "spell") { const sp = spellFor(actor, step)?.spell, tr = [...(sp?.system?.traits?.value ?? [])];
    const found = spellFor(actor, step), tok = actor?.getActiveTokens?.(false, true)?.[0] ?? null;
    const cast = sp ? { slug: sp.slug ?? "", name: sp.name, rank: Number(step.rank ?? sp.rank) || 1, tradition: found?.entry?.tradition ?? null, rarity: sp.system?.traits?.rarity ?? "common", dc: found?.entry?.statistic?.dc?.value ?? null,
      damaging: !!step.damaging, teleport: tr.includes("teleportation"), monster: tok ? moverName(tok) : "A creature", gmMonster: tok?.name ?? actor?.name ?? "The monster" } : null;   /* Moment E (0.36.0) */
    return { manipulate: tr.includes("manipulate"), ranged: tr.includes("attack") && !/touch/i.test(String(sp?.system?.range?.value ?? "")), area: !!step.area?.aim && !!step.damaging && sp?.system?.defense?.save?.statistic === "reflex", cast, kind: sp?.name ? "casting a spell" : "", gmKind: sp?.name ? `casting ${sp.name}` : "" }; }
  return {};
}
/** What the target's reactions before this step's Strike add to its AC against it (Nimble Dodge; Interposing Earth's standard cover), from the answers
    recorded before it: circumstance bonuses, so only the best counts. { bonus, by (the reaction's name), earth (Interposing Earth's row, or null) } */
function acRaised(combat, id, i, target) {
  const rows = (request(combat, id)?.gates?.[i]?.before?.list ?? []).filter(x => x.answer === "done" && AC_ROWS.includes(x.slug) && x.token === target?.id).sort((a, b) => KNOWN[b.slug].ac - KNOWN[a.slug].ac);
  return { bonus: rows.length ? KNOWN[rows[0].slug].ac : 0, by: rows.map(x => x.reaction).join(" and ") || "A reaction", earth: rows.find(x => x.slug === "interposing-earth") ?? null };
}
/* ---------- Interposing Earth's barrier on the map (0.35.0; Rhea, 2026-11-16, q-36: "Wall plus picture (Recommended)") ---------- */
/* When the caster isn't damaged, the barrier stays: a wall on the square edge between the caster and the source (nothing moves across it; Visioner's
   cover override on the wall gives standard cover behind it, both ways, and it doesn't block sight: a 5-ft slab hides nobody) and a slab picture on
   the edge with its HP and rounds. Records live on the fight (`turns.barriers.<key>`); the wall and the pictures carry `flags.<ID>.barrier` so they
   can be found and removed after the fight is gone. Rules: Rage of Elements pg. 95, checked on Archives of Nethys 2026-11-16. */
const SLAB_FILL = "#8b6a43", SLAB_EDGE = "#3b2a17";
/** The barriers standing now (one cut half-made by a reload is left out; its parts go with the fight's end). */
export const barriersOf = (combat, sceneId = null) => Object.entries(turns(combat)?.barriers ?? {}).filter(([, b]) => b && !b.raising && (!sceneId || b.scene === sceneId)).map(([key, b]) => ({ ...b, key }));
const barrierByLabel = (combat, label) => label ? barriersOf(combat).find(b => b.label === label) ?? null : null;
const senseNone = () => (CONST.EDGE_SENSE_TYPES ?? CONST.WALL_SENSE_TYPES).NONE;
/** The two pictures of a barrier: the slab on the edge and its label above it. */
function barrierPics(scene, b) {
  /* seen on a player's page (test build 2): tokens on both squares hid a slab drawn at the ground, and the tree canopy (tiles at 20 ft) hid the label,
     which also wrapped. So the slab stands 5 ft up, its own height (above creatures on the ground, below anything flying over it), and the label
     sits above everything, one line wide. */
  const px = scene.grid.size, d = scene.dimensions, t = Math.max(8, Math.round(px * 0.16)), [ax, ay] = [d.sceneX + b.edge[0][0] * px, d.sceneY + b.edge[0][1] * px], upright = b.edge[0][0] === b.edge[1][0];
  const flags = { [ID]: { barrier: { combat: b.combat, key: b.key } } }, w = Math.round(px * 3.4), h = Math.round(px * 0.34);
  const slab = { x: upright ? ax - t / 2 : ax, y: upright ? ay : ay - t / 2, elevation: 5, shape: { type: "r", width: upright ? t : px, height: upright ? px : t }, fillType: CONST.DRAWING_FILL_TYPES.SOLID, fillColor: SLAB_FILL, fillAlpha: 1, strokeWidth: 2, strokeColor: SLAB_EDGE, strokeAlpha: 1, locked: true, flags };
  const cx = upright ? ax : ax + px / 2, top = upright ? ay : ay - t / 2;
  const text = { x: Math.round(cx - w / 2), y: Math.round(top - h - 6), elevation: 1000, shape: { type: "r", width: w, height: h }, fillType: CONST.DRAWING_FILL_TYPES.SOLID, fillColor: "#111111", fillAlpha: 0.75, strokeWidth: 0, text: barrierLabel(b), fontSize: Math.max(12, Math.round(px * 0.19)), textColor: "#ffffff", locked: true, flags };
  return [slab, text];
}
/** Put the barrier on the map, once per caster and step (a reload never makes two), and say so on the card. caster: the token that cast it; source:
    the monster whose attack or area it answered. */
async function raiseBarrier(combat, id, i, caster, source, rank) {
  if (!isRunner()) return;
  const scene = sceneOf(combat), key = `${id}-${i}-${caster.id}`; if (!scene || turns(combat).barriers?.[key]) return;
  const q = placeOf(source, scene), e = barrierEdge({ pos: squareOf(caster, scene), span: sizeOf(caster) }, { x: q.pos[0] + q.span / 2, y: q.pos[1] + q.span / 2 });   /* the grid square it mostly stands on: the wall goes on a grid line (review 9) */
  const st = barrierStats(rank), label = `B${Object.keys(turns(combat).barriers ?? {}).length + 1}`, px = scene.grid.size, d = scene.dimensions;
  const b = { key, label, combat: combat.id, scene: scene.id, caster: caster.id, casterName: caster.name, source: source.id, side: e.side, edge: [e.a, e.b], squares: [e.near, e.far], ac: st.ac, hardness: st.hardness, hp: st.hp, max: st.hp, left: st.rounds, rank: Number(rank) || 1, round: combat.round,
    ...(combat.combatant?.tokenId === caster.id ? { ticked: `${combat.round}` } : {}) };   /* raised on the caster's own turn: that turn's start has passed (review nit) */
  await saveTurns(combat, { [`barriers.${key}`]: whole({ ...b, raising: true }) });   /* marked first: a reload in the middle finds it and tidies up, never draws two */
  const flags = { [ID]: { barrier: { combat: combat.id, key } } }, none = senseNone();
  const [wall] = await scene.createEmbeddedDocuments("Wall", [{ c: [d.sceneX + e.a[0] * px, d.sceneY + e.a[1] * px, d.sceneX + e.b[0] * px, d.sceneY + e.b[1] * px], move: CONST.WALL_MOVEMENT_TYPES.NORMAL, sight: none, light: none, sound: none, flags: { ...flags, [VISIONER]: { coverOverride: "standard", provideCover: true } } }]);
  const pics = await scene.createEmbeddedDocuments("Drawing", barrierPics(scene, b));
  await saveTurns(combat, { [`barriers.${key}`]: whole({ ...b, wall: wall?.id ?? null, pics: pics.map(x => x.id) }) });
  await addNote(combat, id, pro(barrierCardWords(caster.name, b), P(caster, combat)));
}
/** Change a barrier's record: the whole record read again and written back, so a field never lands on one just removed (review 8). */
async function putBarrier(combat, key, change) { const now = turns(combat).barriers?.[key]; if (!now) return null; const b = { ...now, ...change }; await saveTurns(combat, { [`barriers.${key}`]: whole(b) }); return { ...b, key }; }
/** Redraw a barrier's label after its HP or rounds changed. */
async function showBarrier(combat, b) {
  const scene = game.scenes.get(b.scene), pic = scene?.drawings.get(b.pics?.[1]); if (pic) await pic.update({ text: barrierLabel(b) }).catch(e => console.warn(`${ID} | barrier`, e));
}
/** Take a barrier off the map and out of the fight's records. why: a short reason for the card's note, or null. */
async function dropBarrier(combat, key, why = null) {
  const b = turns(combat).barriers?.[key]; if (!b) return;
  const scene = game.scenes.get(b.scene);
  if (scene) { const walls = scene.walls.filter(w => w.flags?.[ID]?.barrier?.key === key).map(w => w.id), pics = scene.drawings.filter(x => x.flags?.[ID]?.barrier?.key === key).map(x => x.id);
    if (walls.length) await scene.deleteEmbeddedDocuments("Wall", walls).catch(e => console.warn(`${ID} | barrier`, e));
    if (pics.length) await scene.deleteEmbeddedDocuments("Drawing", pics).catch(e => console.warn(`${ID} | barrier`, e)); }
  await saveTurns(combat, { [`barriers.${key}`]: null });
  const r = currentRequest(combat); if (why && r) await addNote(combat, r.id, `${b.casterName}'s earth barrier is gone: ${why}.`);
}
/** Remove now, from her card (any GM). */
export async function removeBarrier(combat, key) { if (!game.user.isGM) throw new Error("Only a GM can do this."); await dropBarrier(combat, key, "you removed it"); }
/** A fight that ended (End Encounter, or the fight deleted): every barrier it made goes, found by the flag on the map (the fight's records are gone). */
export async function clearBarriers(combat) {
  if (!isRunner() && !(game.user === game.users.activeGM && !runner()?.active)) return;   /* the runner, or the active GM while it is away (review 7) */
  for (const scene of game.scenes) {
    const walls = scene.walls.filter(w => w.flags?.[ID]?.barrier?.combat === combat.id).map(w => w.id), pics = scene.drawings.filter(x => x.flags?.[ID]?.barrier?.combat === combat.id).map(x => x.id);
    if (walls.length) await scene.deleteEmbeddedDocuments("Wall", walls).catch(e => console.warn(`${ID} | barrier`, e));
    if (pics.length) await scene.deleteEmbeddedDocuments("Drawing", pics).catch(e => console.warn(`${ID} | barrier`, e));
  }
}
/** On the runner's start: barriers of fights that are gone, and parts of one whose raising a reload cut off, are taken off the map (review 7). */
async function sweepBarriers() {
  for (const scene of game.scenes) {
    const stale = x => { const f = x.flags?.[ID]?.barrier; if (!f) return false; const c = game.combats.get(f.combat); return !c || !c.getFlag(ID, "turns")?.barriers?.[f.key] || !!c.getFlag(ID, "turns").barriers[f.key].raising; };
    const walls = scene.walls.filter(stale).map(w => w.id), pics = scene.drawings.filter(stale).map(x => x.id);
    if (walls.length) await scene.deleteEmbeddedDocuments("Wall", walls).catch(e => console.warn(`${ID} | barrier`, e));
    if (pics.length) await scene.deleteEmbeddedDocuments("Drawing", pics).catch(e => console.warn(`${ID} | barrier`, e));
  }
}
/** At the start of a caster's turn one round comes off; at none left the barrier goes (a duration in rounds counts down at its caster's turns). */
async function tickBarriers(combat) {
  const now = combat.combatant?.tokenId; if (!now) return;
  /* a caster with no turn of its own any more (removed from the fight or defeated): its rounds come off at the start of each round instead (review 14) */
  const turnless = b => !combat.combatants.some(c => c.tokenId === b.caster && !c.defeated);
  for (const b of barriersOf(combat).filter(x => x.caster === now || (turnless(x) && combat.turn === 0))) {
    if (b.ticked === `${combat.round}`) continue;   /* once a turn, whatever redraws */
    const left = b.left - 1; if (left <= 0) { await dropBarrier(combat, b.key, "its 3 rounds are over"); continue; }
    const nb = await putBarrier(combat, b.key, { left, ticked: `${combat.round}` }); if (nb) await showBarrier(combat, nb);
  }
}
/** A monster's Strike at a barrier (0.35.0): rolled against the barrier's AC with no creature targeted; on a hit its damage less the Hardness comes
    off the barrier's HP, and it crumbles at 0. Recorded before and after the roll, so a reload never rolls it twice. */
async function runSlabStrike(combat, id, i, step, tok, b) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {};
  if (get().slab) return "next";   /* done before a reload (the barrier may be gone since) */
  if (!b) return "gone";
  const strike = strikesWithIds(tok.actor).find(x => x.id === step.item)?.strike; if (!strike) throw new Error(`${tok.name} has no ${step.itemName} now.`);
  const ammo = await ammoOf(tok.actor, strike).catch(() => null), own = !!ammo?.stack;
  if (get().started) { await addNote(combat, id, `${tok.name}'s ${step.itemName} at the earth barrier may already be in chat: check its cards and the barrier's HP, then press Next step.`); return "ask"; }
  if (ammo && !ammo.unreadable && (shotsFor(combat, tok, step.item, ammo) ?? 1) < 1) return "noShot";
  if (!stepGate("attack", id)) return "stopped";
  if (!(await ensureScene(combat) && tok.object)) throw new Error(cantOpen());
  stopAiming(); pending = { tokenId: tok.id, waiters: new Map() };
  let degree = 0, rolled = 0, attack = null;
  try {
    await record({ started: true });
    const shot = await watched(async () => { const card = waitFor("attack-roll"), roll = await strike.variants[step.variant].roll({ event: clickWith("showCheckDialogs"), ...(own ? { options: ["skip-post-processing"] } : {}) }); if (!roll) return { roll: null }; return { message: await card, roll }; });
    if (!shot.roll) { await record({ started: false }); if (ammo) return "noShot"; throw new Error(`${step.itemName} didn't roll.`); }
    if (own) await takeAmmo(tok.actor, ammo);
    const check = shot.message.rolls?.[0] ?? shot.roll; attack = shot.message.id;
    degree = degreeAgainst(check.total, check.dice?.[0]?.total, b.ac);
    if (degree >= 2) { const dm = await watched(async () => { const card = waitFor("damage-roll"); await strike[degree === 3 ? "critical" : "damage"]({ event: clickWith("showDamageDialogs"), mapIncreases: step.variant }); return card; }); rolled = Math.floor(dm.rolls?.[0]?.total ?? 0); }
  } finally { pending = null; }
  /* the barrier's HP first, then the step's record: a reload between them asks the GM instead of losing the damage (review 15) */
  const dealt = degree >= 2 ? slabHit(rolled, b.hardness) : 0, now = turns(combat).barriers?.[b.key], hp = now ? now.hp - dealt : null;
  if (now && hp <= 0) await dropBarrier(combat, b.key, `${tok.name} broke it`);
  else if (now && dealt) { const nb = await putBarrier(combat, b.key, { hp }); if (nb) await showBarrier(combat, nb); }
  await record({ attack: { message: attack, degree }, slab: { key: b.key, degree, rolled, dealt } });
  await sayToAll(tok, slabWords({ who: moverName(tok), outcome: OUTCOMES[degree], rolled, dealt, hardness: b.hardness, hp: hp ?? 0, max: b.max, gone: !now }));
  return "next";
}
/** Interposing Earth used by this creature against this step (a Strike at it, or an area that catches it): its row, or null. */
const earthUsed = (combat, id, i, target) => (request(combat, id)?.gates?.[i]?.before?.list ?? []).find(x => x.answer === "done" && x.slug === "interposing-earth" && x.token === target?.id) ?? null;
/** PF2e's own Effect: Cover at standard, for Interposing Earth against an area (its +2 to the Reflex save); marked as this module's so it is taken
    off when the step ends (`dropEarthCover`). Its level is chosen on the source so no prompt opens. */
async function addEarthCover(actor) {
  const src = (await fromUuid(COVER_EFFECT))?.toObject(); if (!src) throw new Error("PF2e's Effect: Cover isn't in its compendium.");
  const choice = src.system.rules.find(r => r.key === "ChoiceSet"); if (!choice) throw new Error("PF2e's Effect: Cover has no choice to set.");
  delete src._id; choice.selection = { bonus: COVER_BONUS.standard, level: "standard" }; src.name = "Interposing Earth (cover)"; foundry.utils.setProperty(src, `flags.${ID}.earth`, true);
  await actor.createEmbeddedDocuments("Item", [src]);
}
async function dropEarthCover(combat, { recognizeOnly = false } = {}) {
  for (const c of combat?.combatants ?? []) { const a = c.token?.actor, ids = (a?.itemTypes?.effect ?? []).filter(e => (!recognizeOnly && e.getFlag?.(ID, "earth")) || e.getFlag?.(ID, "recognize")).map(e => e.id); if (ids.length) await a.deleteEmbeddedDocuments("Item", ids).catch(e => console.warn(`${ID} | cover`, e)); }
}
/** At the end of a move action that leaves no square (Stand, Drop Prone, a Climb), measured from where it was (a Climb can take it out of reach). */
async function stayGate(combat, id, i, step, tok, from) {
  const skipped = [], list = reactorsFor(combat, tok, "stay", { ...(from ?? {}), skipped }); if (!askedBefore(combat, id, i, "stay")) await noteSkipped(combat, id, skipped);
  return askReactions(combat, id, i, "stay", "stay", tok, list, step.do === "stand" ? "stands up" : step.do === "drop-prone" ? "drops prone" : "climbs");
}
/** The answers of a socket message: from the player (only for a reactor that player owns) or a GM's page; the runner writes them on the request. */
export function onSocket(data, senderId) {
  if (!data || typeof data !== "object") return;
  if (data.t === "answer") {
    if (!isRunner()) return;
    const combat = game.combats.get(data.combat), n = combat && request(combat, data.request), rx = n?.react; if (!rx || rx.key !== data.key) return;
    const from = game.users.get(senderId), x = rx.list.find(y => y.id === data.row); if (!from || !x) return;   /* the sender as Foundry reports it, never as the message claims (review finding 13) */
    if (!from.isGM && !game.actors.get(x.actor)?.testUserPermission(from, "OWNER")) return;   /* only the player who owns that character */
    if (!["react", "done", "pass"].includes(data.answer)) return;
    if (["done", "pass", "timeout", "continue"].includes(rx.answers?.[x.id])) return;
    save(combat, data.request, { [`react.answers.${x.id}`]: data.answer }).catch(e => console.warn(`${ID} | reaction`, e));
    return;
  }
  /* a player's own reaction box (0.27.0): only for a character that player owns */
  if (data.t === "rx") {
    if (!isRunner()) return;
    const combat = game.combats.get(data.combat), t = sceneOf(combat)?.tokens.get(data.token), from = game.users.get(senderId); if (!combat?.started || !t?.actor || !from) return;
    if (!from.isGM && !t.actor.testUserPermission(from, "OWNER")) return;
    if (t.actor.alliance !== "party" || !reactsLikeParty(t.actor) || !combat.combatants.some(c => c.tokenId === t.id)) return;
    writeUsed(combat, t.id, data.used ? { by: "hand", user: from.name } : null).catch(e => console.warn(`${ID} | reaction box`, e));
    return;
  }
  /* Ready (0.35.0): the trigger typed on the chip, Now! and Done, only for a character the sender owns (Clear: a GM only) */
  if (data.t === "ready") {
    if (!isRunner()) return;
    const combat = game.combats.get(data.combat), from = game.users.get(senderId); if (!combat?.started || !from) return;
    /* her Continue from another GM page names the turn, not a character (found live in 0.35.0's test build 1) */
    if (data.op === "done" && from.isGM && typeof data.request === "string") { readyNowOn(combat, null, "done", "", from, data.request).catch(e => console.warn(`${ID} | ready`, e)); return; }
    const t = sceneOf(combat)?.tokens.get(data.token); if (!t?.actor) return;
    if (!from.isGM && (!t.actor.testUserPermission(from, "OWNER") || data.op === "clear")) return;
    readyNowOn(combat, t.id, data.op, data.text, from, typeof data.request === "string" ? data.request : null).catch(e => console.warn(`${ID} | ready`, e));
    return;
  }
  /* "Two Steps, or a Stride?" (0.34.0): only from a player who owns the mover */
  if (data.t === "stepsAnswer") {
    if (!isRunner()) return;
    const a = stepAsks.get(data.key), from = game.users.get(senderId); if (!a || !from || !["steps", "stride"].includes(data.answer)) return;
    const c = game.combats.get(a.combat), t = c && sceneOf(c)?.tokens.get(a.by); if (!from.isGM && !t?.actor?.testUserPermission(from, "OWNER")) return;   /* the sender as Foundry reports it */
    answerSteps(data.key, data.answer, from.name).catch(e => console.warn(`${ID} | steps`, e));
    return;
  }
  Hooks.callAll(`${ID}.reactionPrompt`, data);   /* "ask" and "close": the prompt window in a player's browser (ui/react.mjs) */
}
function emitSocket(data) { try { game.socket.emit(SOCKET, data); } catch (e) { console.warn(`${ID} | socket`, e); } }
/** A player's answer to "Two Steps, or a Stride?": to the runner by socket (the runner's own page answers directly). */
export function answerStepsQuestion(key, answer) {
  if (isRunner()) return answerSteps(key, answer, game.user.name);
  emitSocket({ t: "stepsAnswer", key, answer });
}
/** An answer to one reaction row: a player's goes to the runner by socket; a GM writes it on the request. */
export async function answerReaction(combatId, requestId, key, row, answer) {
  const combat = game.combats.get(combatId), rx = combat && request(combat, requestId)?.react; if (!rx || rx.key !== key) return;
  if (game.user.isGM) return save(combat, requestId, { [`react.answers.${row}`]: answer });
  emitSocket({ t: "answer", combat: combatId, request: requestId, key, row, answer });
}
/** The GM's Continue: everyone not yet answered is skipped and the turn goes on. */
export async function continueReactions(combat, requestId) { if (!game.user.isGM) return; const rx = request(combat, requestId)?.react; if (rx) await save(combat, requestId, { "react.cont": true }); }
/** The reactions on the other side the module doesn't know (shown to the GM on the card with their trigger, never asked). */
export function otherReactions(combat, tok, steps = null) {
  const out = [];   /* steps given: only those this turn's plan could set off (0.33.2) */
  for (const c of combat?.combatants ?? []) { const a = c.token?.actor; if (!reactsLikeParty(a) || !a.isEnemyOf?.(tok?.actor)) continue;
    for (const x of reactionsFor(a)) if (!x.known && (!steps || couldSetOff(x.trigger, steps))) out.push({ name: c.token.name, reaction: x.name, trigger: x.trigger }); }
  return out;
}
/** Where a move's reaction gates fall: [{ k, list }] by route index (see react.mjs routeGates). */
function moveGates(combat, tok, step, route) {
  if (step.do === "step" || (step.do === "burrow" && isBelow(tok)) || (route?.length ?? 0) < 2) return [];
  const skipped = [], all = reactorsFor(combat, tok, "move", { anyReach: true, skipped }), path = ["fly", "swim", "burrow"].includes(step.do) ? route.slice(0, 2) : route;
  /* those whose reach the move leaves but who have no reaction to use: named on the card (0.27.0) */
  const near = new Set(routeGates(path, { size: sizeOf(tok), elev: heightUp(tok) }, skipped.map(x => ({ id: x.token, pos: x.pos, span: x.span, elev: x.elev, reach: x.reach }))).flatMap(g => g.ids));
  const out = []; out.skipped = skipped.filter(x => near.has(x.token)); if (!all.length) return out;
  const one = new Map(); for (const x of all) if (!one.has(x.token)) one.set(x.token, x);   /* one reaction per creature per move action */
  for (const g of routeGates(path, { size: sizeOf(tok), elev: heightUp(tok) }, [...one.values()].map(x => ({ id: x.token, pos: x.pos, span: x.span, elev: x.elev, reach: x.reach })))) out.push({ k: g.k, list: [...one.values()].filter(x => g.ids.includes(x.token)) });
  return out;
}
/** A Strike's damage types, for Shield Block (physical only); empty when unknown. */
const damageTypesOf = strike => { const it = strike?.item; return [...Object.values(it?.system?.damageRolls ?? {}).map(d => d?.damageType), it?.system?.damage?.damageType].filter(Boolean); };
/** A hit, before its damage: Shield Block and Reactive Shield. Returns null to go on, "missed" (Reactive Shield turned the hit into a miss), "held",
    "ask", "manual" or "gone". Reactive Shield raises the shield (the module does it if the player didn't) and the attack is read again against the
    attack's own DC plus what the shield adds over the circumstance bonus the target had (review finding 5). */
async function hitGate(combat, id, i, step, tok, target, what, get) {
  const rec = get(); if (rec.reacted || !target?.actor) return null;
  const skipped = [], list = reactorsFor(combat, tok, "hit", { target, melee: !!what.melee, damageTypes: what.damageTypes ?? [], skipped }), again = askedBefore(combat, id, i, "hit"); if (!again) await noteSkipped(combat, id, skipped); if (!list.length && !again) return null;
  const res = await askReactions(combat, id, i, "hit", "hit", tok, list, what.kind ?? ""); if (typeof res === "string") return res;
  const used = slug => res.list.some(x => x.answer === "done" && x.slug === slug), change = { reacted: true };
  let degree = rec.attack.degree;
  if (used("reactive-shield")) {
    const before = circNow(target.actor, { noShield: true });
    if (!target.actor.attributes?.shield?.raised) await watched(async () => game.pf2e.actions.get?.("raise-a-shield")?.use?.({ actors: [target.actor] }) ?? game.pf2e.actions.raiseAShield?.({ actors: [target.actor] })).catch(e => console.warn(`${ID} | raise a shield`, e));
    const m = game.messages.get(rec.attack.message), check = m?.rolls?.[0], add = acAdds(target.actor.attributes?.shield?.ac ?? 0, Math.max(before, coverInDc(m?.flags?.pf2e?.context?.options))), dc = (m?.flags?.pf2e?.context?.dc?.value ?? target.actor.armorClass?.value ?? 0) + add;
    if (check && add) { degree = degreeAgainst(check.total, check.dice?.[0]?.total, dc); if (degree !== rec.attack.degree) { change.attack = { ...rec.attack, degree, was: rec.attack.degree, against: dc }; await addNote(combat, id, `Reactive Shield: against AC ${dc} ${step.itemName}'s ${OUTCOMES[rec.attack.degree]} becomes a ${OUTCOMES[degree]}.`);
      if (degree < 2) await sayToAll(target, missWords(target.name, "Reactive Shield")); } }
  }
  if (used("shield-block") && degree >= 2) { change.shieldBlock = true; if (!applySetting()) await addNote(combat, id, `${target.name} used Shield Block: apply the damage with the card's Shield Block option.`); }
  await save(combat, id, { log: { [i]: change } });
  if (degree < 2) return "missed";
  return res.held ? "held" : null;
}

/* ---------- the party's reactions to damage (0.27.0) ---------- */
/* Rhea, 2026-11-11 (docs/features/reactions.md, PR-1 to PR-11). Just before a monster's damage is applied, a champion whose aura holds both the
   monster and the damaged ally is asked Glimpse of Redemption; once React is pressed (and only then: PR-6) the monster repents or refuses: by the
   rule when it is mindless, by the thinker through its mind when Angel runs it, otherwise by the GM's buttons (which are always on her card, so she
   can answer for a thinker that doesn't). What came of it is kept on the step's record (`harm.<token id>`, `choices.<token id>`), so a reload asks
   and applies nothing twice, and it is said in chat for everyone with the numbers (PR-10). */
/** The monster as players may name it, inside a sentence. */
const enemyName = tok => { const n = moverName(tok); return n === "A creature" ? "the creature" : n; };
/** A line for everyone, spoken as the creature it is about. Never whispered (the module's rule). */
async function sayToAll(target, words) {
  if (!words) return;
  try { await ChatMessage.implementation.create({ speaker: ChatMessage.implementation.getSpeaker({ token: target }), content: `<p>${esc(words)}</p>`, flags: { [ID]: { reason: true } } }); }
  catch (e) { console.warn(`${ID} | reason`, e); }
}
/** Before a monster's damage is applied. hits: [{ target, hit }] (the damage each would take as rolled, after doubling or halving): one question for
    all of them, so a champion picks which ally. Returns null to go on, or "manual", "held", "gone". */
async function harmGate(combat, id, i, tok, hits) {
  const rec = () => request(combat, id).log?.[i] ?? {}, open = hits.filter(h => h.target?.actor && h.hit > 0 && !rec().harm?.[h.target.id]?.asked); if (!open.length) return null;
  const skipped = [], list = [];
  for (const h of open) for (const x of reactorsFor(combat, tok, "harm", { target: h.target, skipped }))
    list.push({ ...x, id: `${x.id}:${h.target.id}`, ally: h.target.id, kind: `${h.target.name} (${h.hit} damage)`, group: x.id, label: h.target.name });
  const again = askedBefore(combat, id, i, "harm"); if (!again) await noteSkipped(combat, id, skipped);
  const change = Object.fromEntries(open.map(h => [h.target.id, { asked: true }]));
  if (list.length || again) {
    const res = await askReactions(combat, id, i, "harm", "harm", tok, list); if (typeof res === "string") return res;
    for (const used of res.list.filter(x => x.answer === "done" && x.slug === "glimpse-of-redemption")) {
      const ally = sceneOf(combat).tokens.get(used.ally); if (!ally) continue;
      if (change[used.ally]?.glimpse) { const second = sceneOf(combat).tokens.get(used.token); if (second) await refund(combat, id, second, used.reaction, `${used.name}'s Glimpse of Redemption wasn't needed (${change[used.ally].glimpse.by} had already answered for ${ally.name}): ${pro("{their}", P(second, combat))} reaction is back.`); continue; }
      const c = await glimpseChoice(combat, id, i, tok, ally, used); if (typeof c === "string") return c;
      let guilt = "enfeebled";
      if (c.choice === "refuse" && used.guilt) { const g = await guiltPick(combat, id, i, tok, used); if (!(g in GUILT)) return g; guilt = g; }
      change[used.ally] = { asked: true, glimpse: { by: used.name, token: used.token, choice: c.choice, who: c.by, ...(c.reason ? { reason: c.reason } : {}), ...(c.choice === "refuse" ? { resist: used.value, guilt } : {}) } };
    }
    if (res.held) { await save(combat, id, { log: { [i]: { harm: change } } }); return "held"; }
  }
  await save(combat, id, { log: { [i]: { harm: change } } });
  return null;
}
/** What the reactions do to this creature's share of the damage: { repent, resist, less }. less: Interposing Earth, when it is still damaged. */
function harmFor(combat, id, i, target, hit = 0) {
  const g = request(combat, id).log?.[i]?.harm?.[target.id]?.glimpse ?? null, earth = earthUsed(combat, id, i, target);
  return { repent: g?.choice === "repent", resist: g?.choice === "refuse" ? g.resist ?? 0 : 0, less: earth && g?.choice !== "repent" ? Math.min(earthLess(earth.spell?.rank), Math.max(0, hit)) : 0 };
}
/** After the damage: the refused monster's condition (enfeebled 2, or stupefied 2 with Weight of Guilt, until the end of its next turn), the line
    for everyone, and the same on the GM's card with who decided. Once per creature per step. */
async function afterHarm(combat, id, i, tok, target, { hit = 0, was = null, block = false, byHand = false } = {}) {
  const h = request(combat, id).log?.[i]?.harm?.[target.id] ?? {}, g = h.glimpse ?? null, hm = harmFor(combat, id, i, target, hit); if (h.said || (!g && !hm.less)) return;
  await save(combat, id, { log: { [i]: { harm: { [target.id]: { said: true } } } } });   /* first: a reload can't say or apply it twice */
  const refused = g?.choice === "refuse";
  if (refused) { try { await guiltEffect(combat, tok, g.guilt); } catch (e) { console.error(`${ID} | glimpse`, e); await addNote(combat, id, `I couldn't make ${tok.name} ${GUILT[g.guilt]?.name ?? "Enfeebled 2"} (${e.message}): add it yourself, until the end of its next turn.`); } }
  const taken = was == null ? null : Math.max(0, was - hpNow(target)), cond = refused ? GUILT[g.guilt]?.name ?? "Enfeebled 2" : null;
  const decided = !g ? "" : g.who === "rule" ? pro(" (mindless: {they} {refuses|refuse} by the rule)", P(tok, combat)) : g.who === "angel" ? ` (Angel chose${g.reason ? `: ${g.reason}` : ""})` : " (your choice)";
  if (byHand) {   /* automatic damage is off: the GM applies it, so she is told what to apply */
    const parts = [g?.choice === "repent" ? `${tok.name} repented${decided}: don't apply this damage to ${target.name}` : null, refused ? `${tok.name} refused${decided}: apply it to ${target.name} with resistance ${hm.resist} to all damage; ${tok.name} is ${cond} until the end of {their} next turn` : null,
      hm.less ? `Interposing Earth: take ${hm.less} off what ${target.name} takes; the barrier is destroyed` : null].filter(Boolean);
    const e = enemyName(tok), E = e.replace(/^t/, "T");
    await sayToAll(target, [g?.choice === "repent" ? `${target.name} is unharmed by this: ${e} repented (Glimpse of Redemption).` : null, refused ? `Glimpse of Redemption: ${e} refused, so ${target.name} resists ${hm.resist} of each kind of this damage. ${E} is ${cond} until the end of ${pro("{their}", P(tok, combat))} next turn.` : null,
      hm.less ? `Interposing Earth: ${target.name} takes ${hm.less} less of this damage, and the barrier is destroyed.` : null].filter(Boolean).join(" "));
    return addNote(combat, id, `${g ? `Glimpse of Redemption (${g.by}). ` : ""}${parts.join(". ")}.`);
  }
  const words = harmWords({ name: target.name, enemy: enemyName(tok), hit, taken: taken ?? 0, repent: g?.choice === "repent", resist: hm.resist, less: taken > 0 || hm.less >= hit ? hm.less : 0, block });
  await sayToAll(target, refused ? `${words} ${enemyName(tok).replace(/^t/, "T")} is ${cond} until the end of ${pro("{their}", P(tok, combat))} next turn.` : words);
  const gmWords = `${harmWords({ name: target.name, enemy: tok.name, hit, taken: taken ?? 0, repent: g?.choice === "repent", resist: hm.resist, less: taken > 0 || hm.less >= hit ? hm.less : 0, block })}${g ? `${decided}${refused ? ` ${tok.name} is ${cond} until the end of ${pro("{their}", P(tok, combat))} next turn.` : ""}` : ""}`;
  if (gmWords.trim()) await addNote(combat, id, gmWords);
  /* a Shield Block that the monster's repentance made needless isn't spent (review 13): nothing was applied, so nothing was blocked */
  if (g?.choice === "repent" && block) await refund(combat, id, target, "Shield Block", `${target.name}'s Shield Block wasn't needed (the blow did no harm): ${pro("{their}", P(target, combat))} reaction is back.`);
}
/** Give a reaction back that the module ticked for something that then came to nothing: only its own tick for that reaction, never one made by hand. */
async function refund(combat, id, target, reaction, words) {
  const u = reactionUsed(combat, target.id); if (!u || u.by !== "module" || u.reaction !== reaction) return;
  await writeUsed(combat, target.id, null); await addNote(combat, id, words);
}
/** With automatic damage off the GM applies the damage from its card: the question is still asked, and the card tells her what to apply. */
async function harmByHand(combat, id, i, tok, hits) {
  try { const hg = await harmGate(combat, id, i, tok, hits);
    /* the damage is already rolled and the step doesn't come back here, so a question cut short is the GM's to finish (review 3) */
    if (typeof hg === "string") { if (hg !== "manual") await addNote(combat, id, "The reactions to this damage weren't finished: ask them yourself before you apply it."); return hg; }
    for (const h of hits) if (h.target) await afterHarm(combat, id, i, tok, h.target, { hit: h.hit, byHand: true }); }
  catch (e) { console.error(`${ID} | reactions`, e); await addNote(combat, id, `I couldn't ask the reactions to this damage (${e.message}).`); }
  return null;
}
/** The monster's answer to Glimpse of Redemption: { choice: "repent" | "refuse", by: "rule" | "angel" | "gm", reason }, or "manual", "held",
    "gone". The question sits on the request (`choice`) while it is open: the GM's card shows Repent and Refuse, and when Angel runs the monster a
    "choice" event goes to the thinker with the packet its turn began with. */
async function glimpseChoice(combat, id, i, tok, ally, used) {
  const had = request(combat, id).log?.[i]?.choices?.[ally.id]; if (had?.choice) return had;
  const done = async (choice, by, reason = null) => { const v = { choice, by, ...(reason ? { reason } : {}) }; await save(combat, id, { choice: null, log: { [i]: { choices: { [ally.id]: v } } } }); return v; };
  if (tok.actor?.traits?.has?.("mindless") || (tok.actor?.system?.traits?.value ?? []).includes("mindless")) return done("refuse", "rule");   /* Player Core 2 pg. 93 */
  const r = request(combat, id), packet = tok.getFlag(ID, "run") && runnable(tok) ? packetFor(combat, id) : null;
  /* the creature its blow lands on, as it knows it: this turn's label, or (a reaction has none of its own) the fight's */
  const label = (r.reaction ? null : Object.entries(r.labels ?? {}).find(([, t]) => t === ally.id)?.[0]) ?? (r.reaction ? turns(combat).labels?.[ally.id] : null) ?? null;
  /* a question left open by a reload of the runner's page is the same question: it isn't asked, or sent to the thinker, a second time (review 5) */
  const open = r.choice?.step === i && r.choice.allyId === ally.id ? r.choice : null;
  if (open && CHOICES.includes(open.answer)) return done(open.answer, open.answeredBy === "angel" ? "angel" : "gm", open.reason ?? null);
  const ev = packet && !open ? eventChange("choice", id, 0) : {}, seq = open ? open.seq : packet ? Number(Object.keys(ev)[0].split(".")[1]) : Date.now(); if (packet && !open) Object.values(ev)[0].choiceSeq = seq;
  if (!open) await saveTurns(combat, { [`requests.${id}.choice`]: whole({ seq, kind: "glimpse-of-redemption", ally: label, allyId: ally.id, allyName: ally.name, by: used.name, words: choiceWords(label), angel: !!packet, step: i }), [`requests.${id}.since`]: clock(), ...ev });
  const start = request(combat, id);
  for (;;) {
    await sleep(REACT_POLL);
    const n = request(combat, id), c = n?.choice;
    if (!n || n.state === "manual") { if (n) await save(combat, id, { choice: null }); return "manual"; }
    if (!game.combats.has(combat.id) || combat.round !== start.round || combat.combatant?.id !== (start.reaction ? start.turnOf : start.combatantId)) { await save(combat, id, { choice: null }); return "gone"; }
    if (CHOICES.includes(c?.answer)) return done(c.answer, c.answeredBy === "angel" ? "angel" : "gm", c.reason ?? null);
    if (!c || c.seq !== seq) return done("refuse", "gm");   /* the question was cleared from under it: the rule's default */
    if (n.hold) { await save(combat, id, { choice: null }); return "held"; }
  }
}
/** The GM's Repent or Refuse on her card: hers to press for any monster, and for Angel's when the thinker doesn't answer. */
export async function chooseFor(combat, requestId, choice) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, requestId); if (!r?.choice || r.choice.answer || !CHOICES.includes(choice)) return;
  await save(combat, requestId, { "choice.answer": choice, "choice.answeredBy": "gm" });
}
/** Weight of Guilt: after a refusal the champion's player picks Enfeebled 2 or Stupefied 2, in a window that says what each does; no answer in time
    is Enfeebled 2. It is no reaction, so it ticks no box. Returns "enfeebled", "stupefied", or "manual", "held", "gone". */
async function guiltPick(combat, id, i, tok, used) {
  const row = { id: `${used.token}:weight-of-guilt`, token: used.token, actor: used.actor, name: used.name, reaction: "Weight of Guilt", slug: "weight-of-guilt", free: true,
    words: guiltWords(enemyName(tok).replace(/^t/, "T"), P(tok, combat)), lines: guiltLines(enemyName(tok).replace(/^t/, "T"), P(tok, combat)), gmWords: guiltWords(tok.name, P(tok, combat)), labels: { react: GUILT.stupefied.name, pass: GUILT.enfeebled.name } };
  const res = await askReactions(combat, id, i, `guilt:${used.ally}`, "harm", tok, [row]); if (typeof res === "string") return res;   /* one question for each refusal (review 4) */
  return res.list[0]?.answer === "done" ? "stupefied" : "enfeebled";
}
/** The refused monster's condition, as a PF2e effect that grants it and runs out at the end of the monster's next turn (counted from its own
    initiative: `untilNextTurnEnds`). PF2e sets an effect's start itself when it is made, so the initiative is written just after. */
const GUILT_CONDITION = { enfeebled: "Compendium.pf2e.conditionitems.Item.MIRkyAjyBeXivMa7", stupefied: "Compendium.pf2e.conditionitems.Item.e1XGnhKNSQIm5IXg" };
async function guiltEffect(combat, tok, kind = "enfeebled") {
  if (!(kind in GUILT_CONDITION)) kind = "enfeebled";
  const order = combat.turns.map(x => x.id), mine = combat.combatants.find(x => x.tokenId === tok.id), at = order.indexOf(mine?.id), now = order.indexOf(combat.combatant?.id);
  const rounds = untilNextTurnEnds({ ownTurn: at === now, acted: at >= 0 && at < now });
  const src = { type: "effect", name: `Glimpse of Redemption: ${GUILT[kind].name}`, img: kind === "stupefied" ? "systems/pf2e/icons/conditions/stupefied.webp" : "systems/pf2e/icons/conditions/enfeebled.webp", flags: { [ID]: { glimpse: kind } },
    system: { rules: [{ key: "GrantItem", uuid: GUILT_CONDITION[kind], onDeleteActions: { grantee: "restrict" }, alterations: [{ mode: "override", property: "badge-value", value: 2 }] }], duration: { value: rounds, unit: "rounds", expiry: "turn-end", sustained: false }, tokenIcon: { show: true } } };
  const [e] = await tok.actor.createEmbeddedDocuments("Item", [src]);
  if (e && mine?.initiative != null) await e.update({ "system.start": { value: game.time.worldTime, initiative: mine.initiative } });
}

/* ---------- monsters reacting on players' turns (0.21.0) ---------- */
/* Rhea's answers of 2026-11-09 (docs/features/reactions.md): a monster with Angel and Auto ticked takes a Reactive Strike by itself, any other is
   Do it / Skip on her card; every trigger the rule names; a trigger the module isn't sure of always comes to her card. The runner's page watches token
   moves, chat cards, items changing hands and Prone coming off; each offer is its own request (`reaction`), run with the same Strike code as a turn's,
   so a player's Shield Block and Reactive Shield are asked as usual. The reaction comes just after the action shows (the design's first version: a
   player's drag isn't interrupted). A monster reacts once a round; its reaction comes back when its own turn begins. */
const CARD_MS = 15000, stepCards = new Map(), strideCards = new Map(), stepAsks = new Map(), stepsSettling = new Set(), standCards = new Map(), castCards = new Map(), carried = new Map(), queued = new Set(), reactionIds = new Set(), offering = new Set();
let reactionLine = Promise.resolve();
/* A fight's scene (B-6, 0.33.2): Foundry 14 makes a new encounter unlinked (its `scene` null) from the tracker's + and the token HUD's
   combat toggle, so the scene is read from the combatants' tokens when the encounter names none. Every "the fight's scene" in the module
   goes through this. */
export const sceneOf = combat => { if (!combat) return null; if (combat.scene) return combat.scene;
  for (const x of combat.combatants ?? []) { const s = x.sceneId ? game.scenes.get(x.sceneId) : x.token?.parent; if (s) return s; } return null; };
const fightOf = tok => game.combats.find(c => c.started && sceneOf(c)?.id === tok?.parent?.id && c.combatants.some(x => x.tokenId === tok.id)) ?? null;
const tokenIn = (combat, actor) => combat.combatants.find(c => c.token && (c.token.actor === actor || (c.token.actorLink && c.actorId === actor?.id)))?.token ?? null;
/** The reaction requests of a fight that aren't finished: [{ id, ...request }]. */
export const openReactions = combat => Object.entries(turns(combat).requests ?? {}).filter(([, r]) => r?.reaction && r.state !== "done").map(([id, r]) => ({ id, ...r }));
/** A monster's melee Strikes for reactionStrike, and its longest melee reach. */
function meleeOf(actor) {
  const list = strikesWithIds(actor).map(({ id, strike: a }) => ({ id, name: a.label, ranged: !!a.item?.isRanged, reach: actor.getReach?.({ action: "attack", weapon: a.item }) ?? 5, mod: strikeMods((a.variants ?? []).map(v => v.label))[0] ?? 0 })).filter(s => !s.ranged);
  return { list, reach: Math.max(0, ...list.map(s => s.reach)) };
}
/** The monsters that could react to this creature now: NPCs in the fight that are its enemies, able to act and attack, with Reactive Strike, perceiving
    it, their reaction unspent and no offer open. [{ c, t, a, melee }] */
function monsterReactors(combat, by) {
  const t0 = turns(combat), open = new Set(openReactions(combat).map(r => r.tokenId)), out = [];
  /* a monster the module is running right now: the party's side was already asked in its own reaction pass (0.33.1, review: a party-side NPC was
     offered the same trigger twice) */
  const cr = currentRequest(combat), modulesTurn = !!by.getFlag?.(ID, "run") && cr?.tokenId === by.id && (running.has(cr.id) || cr.state === "running");   /* only while the module is acting (review of 0.33.1) */
  for (const c of combat.combatants) {
    const t = c.token, a = t?.actor;
    if (modulesTurn && a && onParty(a)) continue;
    if (!t || t.id === by.id || c.defeated || t.hidden || !a?.isOfType?.("npc") || !a.isEnemyOf?.(by.actor) || t.getFlag(ID, "escaped") || stoodDown(t) || isBelow(t) || isDown(a)) continue;   /* a GM-hidden monster stays hidden (review finding 6) */   /* one that has yielded takes no reactions (0.29.0, design review 3) */
    if (cantAct(a) || cantAttack(a) || ["stunned", "confused"].some(k => a.hasCondition?.(k))) continue;
    if (t0.reacted?.[t.id] || t0.rx?.[t.id] || open.has(t.id) || offering.has(t.id)) continue;   /* `rx`: a party-side creature's reaction box (0.27.0, review 12) */   /* `offering`: two triggers in the same moment make one offer (review finding 3) */
    if (!reactionsFor(a).some(x => MONSTER_REACTIONS.includes(x.slug))) continue;
    /* what the monster perceives, as its turns work it out (sight, light, its senses, then Visioner's record): Visioner alone answers "observed"
       for a pair with no record (review finding 5). Off the fight map the runner can't tell, so Visioner's record is all there is. */
    let state = null;
    if (onFightScene(combat) && t.object && by.object) { try { state = sense(combat, t, t0.memory?.[t.id] ?? {}).find(o => o.id === by.id)?.state ?? "unnoticed"; } catch (e) { console.warn(`${ID} | reaction sight`, e); } }
    if (state == null) { if (!perceivesNow(t, by)) continue; try { state = visionerApi()?.getVisibility(t.id, by.id) ?? "observed"; } catch { state = "observed"; } }
    if (!["observed", "concealed"].includes(state)) continue;
    const melee = meleeOf(a); if (!melee.list.length) continue;
    out.push({ c, t, a, melee, state });
  }
  return out;
}
/** Offer one monster's Reactive Strike at a creature: a request of its own. from: { at: [x, y], elev } where the creature was (a move), or null for
    where it is. Sure and Angel and Auto ticked: it runs at once (waiting out the game's pause); otherwise it waits for Do it or Skip on the card. */
async function offerReaction(combat, m, by, trig, from = null) {
  const scene = sceneOf(combat), me = placeOf(m.t, scene), there = from ? { pos: from.at, span: sizeOf(by) } : placeOf(by, scene);
  const dist = distanceBetween({ x: there.pos[0], y: there.pos[1], size: there.span, elev: from?.elev ?? heightUp(by) }, { x: me.pos[0], y: me.pos[1], size: me.span, elev: heightUp(m.t) }, { reach: m.melee.reach });
  const pick = reactionStrike(m.melee.list, dist); if (!pick) return null;
  const state = m.state ?? "observed";
  const id = foundry.utils.randomID(8), auto = !!trig.sure && !!m.t.getFlag(ID, "run") && !!m.t.getFlag(ID, "auto");
  const step = { do: "strike", item: pick.id, itemName: pick.name, target: "T", targetName: by.name, variant: 0, flat: flatDC(state) };   /* variant 0: a reaction takes no multiple attack penalty */
  reactionIds.add(id);
  await saveTurns(combat, { [`requests.${id}`]: { state: "ready", reaction: whole({ by: by.id, gate: trig.gate, sure: !!trig.sure, kind: trig.kind ?? "", why: trig.why ?? null, strike: pick.name, auto }), combatantId: m.c.id, tokenId: m.t.id, turnOf: combat.combatant?.id ?? null, round: combat.round, turn: combat.turn, at: Date.now(), since: clock(), log: {}, labels: { T: by.id }, steps: [step], pos: 0, tries: 0, note: null } });
  if (auto) autoReaction(combat, id, by);
  return id;
}
/** A sure offer to a monster with Angel and Auto ticked: it strikes by itself once the move shows, waiting out the game's pause. */
function autoReaction(combat, id, by) {
  (async () => {
    const moving = by.object?.movementAnimationPromise; if (moving) await Promise.race([moving, sleep(5000)]).catch(() => {});   /* let the move be seen first */
    while (game.paused) { await sleep(300); if (request(combat, id)?.state !== "ready") return; }   /* the game's pause pauses Auto (Rhea, 2026-11-08) */
    if (request(combat, id)?.state === "ready") await doReaction(combat, id);
  })().catch(e => console.error(`${ID} | reaction`, e));
}
/** Offer every monster that the trigger reaches. route: the squares of a move (reach is tested for each square left), or null. Returns the
    ids of the offers made. */
async function offerAll(combat, by, trig, route = null, elev = null) {
  const made = [];
  if (!trig?.gate || !isRunner() || !combat?.started || !by?.actor || isDown(by.actor) || (by.hidden && !by.actor.hasPlayerOwner)) return made;   /* a body dragged past a monster triggers nothing */
  const scene = sceneOf(combat), here = placeOf(by, scene);
  for (const m of monsterReactors(combat, by)) {
    const p = placeOf(m.t, scene); let from = null;
    if (route) { const g = routeGates(route, { size: sizeOf(by), elev: elev ?? heightUp(by) }, [{ id: m.t.id, pos: p.pos, span: p.span, elev: heightUp(m.t), reach: m.melee.reach }])[0]; if (!g) continue; from = { at: route[g.k], elev: elev ?? heightUp(by) }; }
    else if (distanceBetween({ x: here.pos[0], y: here.pos[1], size: here.span, elev: heightUp(by) }, { x: p.pos[0], y: p.pos[1], size: p.span, elev: heightUp(m.t) }, { reach: m.melee.reach }) > m.melee.reach) continue;
    offering.add(m.t.id);
    try { const id = await offerReaction(combat, m, by, trig, from); if (id) made.push(id); } catch (e) { console.error(`${ID} | reaction offer`, e); } finally { offering.delete(m.t.id); }
  }
  return made;
}
/** Do it on a monster's reaction (or its own start, with Auto): the runner makes the Strike. From another GM's browser it asks the runner. */
export async function doReaction(combat, id) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  if (!isRunner()) { const why = runnerProblem(); if (why) throw new Error(why); return save(combat, id, { go: true }); }
  if (running.has(id) || queued.has(id)) return;
  if (stepsSettling.has(id)) { for (let t = 0; t < 50 && stepsSettling.has(id); t++) await sleep(100); if (request(combat, id)?.state !== "ready") return; }   /* a player's Steps answer being written wins (0.34.0, review 1) */
  /* one roller at a time: a Strike's cards are matched by a single waiter (`pending`), so a reaction waits for whatever is running (a turn's
     action, another reaction) and reactions go in the order they were asked (review finding 1) */
  queued.add(id);
  const mine = reactionLine = reactionLine.catch(() => {}).then(async () => {
    for (let t = 0; t < 600 && running.size; t++) await sleep(200);
    queued.delete(id); running.add(id); try { await runReaction(combat, id); } finally { running.delete(id); stopAiming(); }
  });
  try { await mine; } finally { queued.delete(id); }
}
/** A turn's action waits while a monster's reaction is mid-Strike or queued (at most a minute). */
async function reactionsClear(butId) { for (let t = 0; t < 300 && ([...running].some(x => x !== butId && reactionIds.has(x)) || queued.size); t++) await sleep(200); }
/** Skip: the offer ends and the monster keeps its reaction. */
export async function skipReaction(combat, id) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const r = request(combat, id); if (!r?.reaction || r.state !== "ready" || running.has(id)) return;
  await save(combat, id, { state: "done", go: false, skipped: true });
}
async function runReaction(combat, id) {
  const r = request(combat, id); if (!r?.reaction || r.state !== "ready") return;
  const tok = sceneOf(combat).tokens.get(r.tokenId), target = sceneOf(combat).tokens.get(r.reaction.by), end = note => save(combat, id, { state: "done", go: false, note: joinNote(combat, id, note) });
  if (!tok || !target) return end("One of them is gone.");
  if (turns(combat).reacted?.[tok.id]) return end(`${tok.name} has already used {their} reaction this round.`);
  if (isDown(tok.actor) || cantAct(tok.actor) || cantAttack(tok.actor)) return end(`${tok.name} can't react now.`);
  if (!await ensureScene(combat)) return save(combat, id, { go: false, note: cantOpen() });
  await saveTurns(combat, { [`requests.${id}.state`]: "running", [`requests.${id}.go`]: false, [`requests.${id}.since`]: clock(), [`reacted.${tok.id}`]: whole({ round: combat.round, request: id }) });
  if (tok.actor?.alliance === "party" && reactsLikeParty(tok.actor)) await markUsed(combat, tok.id, "Reactive Strike");   /* its box on the Party reactions block shows it too */
  /* the reactions before its Strike (0.27.0): Nimble Dodge and Interposing Earth, as for a Strike on its own turn */
  let pre = null; try { pre = await beforeAction(combat, id, 0, r.steps[0], tok, target); } catch (e) { console.error(`${ID} | reactions`, e); await addNote(combat, id, `I couldn't ask the reactions before its Reactive Strike (${e.message}); it went ahead.`); }
  if (pre === "manual") return;
  /* nothing was rolled: the monster keeps its reaction, and Interposing Earth's cover doesn't linger (review 10) */
  if (pre === "gone" || pre === "down") { await saveTurns(combat, { [`reacted.${tok.id}`]: null }); await dropEarthCover(combat).catch(e => console.warn(`${ID} | cover`, e));
    return end(pre === "gone" ? "The turn moved on while reactions to it were being asked." : `${tok.name} went down before {they} could strike.`); }
  let result; try { result = await runStrike(combat, id, 0, r.steps[0], tok, target); } catch (e) { console.error(e); result = "ask"; await save(combat, id, { note: e.message }); }
  await dropEarthCover(combat).catch(e => console.warn(`${ID} | cover`, e));
  if (request(combat, id)?.state === "manual") return;
  const rec = request(combat, id)?.log?.[0] ?? {}, degree = rec.attack?.degree, words = [];
  if (!rec.started && !rec.flatStarted && !rec.attack) await saveTurns(combat, { [`reacted.${tok.id}`]: null });   /* nothing was rolled: the reaction isn't spent (review finding 10) */
  if (rec.flat && !rec.flat.ok) words.push(`${tok.name}'s Reactive Strike failed its flat check.`);
  else if (degree != null) words.push(`${tok.name}'s Reactive Strike at ${target.name}: ${OUTCOMES[degree] ?? "rolled"}.`);
  /* a critical hit disrupts a manipulate action (the rule): the action already shows, so undoing it is the GM's call */
  if (degree === 3 && r.reaction.gate === "manipulate") words.push(`By the rules a critical Reactive Strike disrupts the manipulate action (${target.name} ${r.reaction.kind}): undo what it did if you rule so.`);
  if (result === "gone") words.push("The turn moved on while reactions to it were being asked.");
  else if (result !== "next") words.push("It may not have finished: check the chat and HP.");
  await save(combat, id, { state: "done", pos: 1, note: joinNote(combat, id, words.join(" ")) });
}
/** A turn or round change: offers nobody answered lapse (the moment has passed), and the creature whose turn begins has its reaction back. */
async function turnReactions(combat) {
  if (!isRunner()) return;
  const change = {};
  for (const r of openReactions(combat)) if (r.state === "ready" && !running.has(r.id)) { change[`requests.${r.id}.state`] = "done"; change[`requests.${r.id}.lapsed`] = true; change[`requests.${r.id}.go`] = false; }
  const now = combat.combatant?.tokenId; if (now && turns(combat).reacted?.[now]) change[`reacted.${now}`] = null;
  if (now && turns(combat).rx?.[now]) change[`rx.${now}`] = null;   /* a party member's reaction comes back when its turn begins (0.27.0) */
  if (now && turns(combat).ready?.[now]) change[`ready.${now}`] = null;   /* a readied action lasts until the start of that character's next turn (0.35.0) */
  if (Object.keys(change).length) await saveTurns(combat, change);
  for (const [key, a] of stepAsks) if (a.combat === combat.id) { stepAsks.delete(key); emitSocket({ t: "stepsClose", key }); }   /* the moment has passed (0.34.0) */
  await dropEarthCover(combat).catch(e => console.warn(`${ID} | cover`, e));   /* Interposing Earth's cover never outlives the turn it was used on */
  await tickBarriers(combat).catch(e => console.warn(`${ID} | barrier`, e));   /* its barrier's rounds count down at the caster's turns (0.35.0) */
  noteCarried(combat);
}
/** What everyone in the fight holds now, for items changing hands (read on every turn change; an item never seen is not guessed at). */
function noteCarried(combat) { for (const c of combat.combatants) for (const it of c.actor?.items ?? []) if (it.system?.equipped && !carried.has(it.uuid)) carried.set(it.uuid, { carry: it.system.equipped.carryType, hands: it.system.equipped.handsHeld ?? 0 }); }
/** A token moved (the runner's `moveToken` hook): a move action out of a monster's reach. */
export function onTokenMoved(doc, movement) {
  if (!isRunner() || !movement || ["undo", "config", "paste"].includes(movement.method)) return;
  const combat = fightOf(doc); if (!combat || !doc.actor?.isOfType?.("creature")) return;
  const scene = sceneOf(combat), px = scene.grid.size, d = scene.dimensions, near = (doc.width ?? 1) < 1 ? Math.floor : Math.round, sq = w => [near((w.x - d.sceneX) / px), near((w.y - d.sceneY) / px)];   /* a Tiny token counts as the square holding its corner, as placeOf has it */
  const way = movement.passed?.waypoints ?? [], route = squaresAlong([sq(movement.origin), ...way.map(sq)]); if (route.length < 2) return;
  /* PF2e's "travel" is walking out of an encounter, and a token keeps its last move's action: a creature's first drag in a fight after moving
     outside one comes as "travel" (B-10, seen live 2026-11-16 on 0.33.2: a real Stride read as Not certain). In a fight it is a walk. */
  const raw = way.find(w => w.action)?.action ?? doc.movementAction ?? "walk", action = raw === "travel" ? "walk" : raw, at = stepCards.get(doc.actor.id), stepped = !!at && clock() - at < CARD_MS; if (stepped) stepCards.delete(doc.actor.id);
  const sAt = strideCards.get(doc.actor.id), strode = !!sAt && clock() - sAt < CARD_MS; if (strode) strideCards.delete(doc.actor.id);
  /* a Step can't go into difficult terrain or be made with a Speed under 10 ft (q-33): read for a walk of up to three squares only */
  const short = action === "walk" && route.length <= 4, elev = heightUp({ elevation: movement.origin?.elevation });
  const land = short ? Number(doc.actor.system?.movement?.speeds?.land?.value) : NaN, difficult = short && difficultIn(scene, route, sizeOf(doc), movement.origin?.elevation ?? 0);
  let trig = moveTrigger({ action, squares: route.length - 1, ownTurn: combat.combatant?.tokenId === doc.id, stepped, strode, difficult, landSpeed: Number.isFinite(land) ? land : null, keyboard: movement.method === "keyboard", script: movement.method === "api" });
  if (trig?.sure && movement.method === "api") trig = { ...trig, sure: false, why: "It was moved by a script or another module, which may not be its own move action." };
  if (trig) offerAll(combat, doc, trig, route, elev).then(ids => trig.steps && ids.length ? askSteps(combat, doc, trig.steps, ids) : null).catch(e => console.error(`${ID} | reactions`, e));
}
/** Whether a move entered difficult terrain: any square its footprint enters (not the one it started on) lies in a region that makes walking cost
    more (PF2e's and Survey Sheet's `modifyMovementCost`), at the height it moved at. */
function difficultIn(scene, route, size, elevation = 0) {
  const px = scene.grid.size, d = scene.dimensions, start = new Set(footprintAt(route[0], size).map(p => p.join())), hard = [];
  for (const r of scene.regions) if (r.behaviors.some(b => b.type === "modifyMovementCost" && !b.disabled && (Number(b.system?.difficulties?.walk) || 1) > 1)) hard.push(r);
  if (!hard.length) return false;
  for (const sq of route.slice(1)) for (const [i, j] of footprintAt(sq, size)) { if (start.has(`${i},${j}`)) continue;
    const pt = { x: d.sceneX + (i + .5) * px, y: d.sceneY + (j + .5) * px, elevation };
    if (hard.some(r => { try { return r.testPoint(pt); } catch { return false; } })) return true; }
  return false;
}
/* ---------- "Two Steps, or a Stride?" (0.34.0; Rhea, 2026-11-15, q-33: "Ask the player") ----------
   One walk of 10 or 15 ft on the mover's own turn could be Steps (no reaction) or a Stride. The offers are made as Not certain at once (Do it and Skip
   stay on her card), and the mover's player is asked in a small window. Steps: the offers end with a note. Stride: they become sure, and a monster on
   Auto strikes. No answer in the reaction timer's time, or nobody playing the mover: the offers stay hers, saying so. */
async function askSteps(combat, by, n, ids) {
  const users = game.users.filter(u => u.active && !u.isGM && by.actor?.testUserPermission?.(u, "OWNER"));
  if (!users.length) return;
  const key = foundry.utils.randomID(8), secs = reactionTimer(), until = secs ? clock() + secs * 1000 : 0, names = users.map(u => u.name).join(" or ");
  stepAsks.set(key, { combat: combat.id, by: by.id, actor: by.actor.id, n, ids, users: users.map(u => u.id), names });
  const ch = {}; for (const id of ids) ch[`requests.${id}.reaction.ask`] = { key, n, who: names, until };
  await saveTurns(combat, ch);
  /* the monsters as the mover's player knows them: a name only when the token shows it and the character perceives that monster (review 2) */
  const monsters = ids.map(id => sceneOf(combat).tokens.get(request(combat, id)?.tokenId)).filter(Boolean).map(m => seenBy(by, m) ? moverName(m) : "a creature");
  emitSocket({ t: "steps", combat: combat.id, key, token: by.id, n, monsters, users: users.map(u => u.id), until });
  /* closes on the timer, or as soon as the GM has answered every offer (Do it or Skip), or the fight is gone (review 5) */
  const poll = setInterval(() => {
    if (!stepAsks.has(key)) return clearInterval(poll);
    const c = game.combats.get(combat.id), open = c && ids.some(id => { const r = request(c, id); return r?.state === "ready" && !r.go; });
    if (!open) { clearInterval(poll); answerSteps(key, "gm").catch(e => console.warn(`${ID} | steps`, e)); }
    else if (until && clock() >= until) { clearInterval(poll); answerSteps(key, "timeout").catch(e => console.warn(`${ID} | steps`, e)); }
  }, 500);
}
/** Whether a creature perceives another as the module's other player-facing words read it: seen, or concealed (Visioner's record when it has one). */
function seenBy(viewer, tok) {
  if (tok.hidden) return false;
  try { const v = visionerApi()?.getVisibility(viewer.id, tok.id); if (v) return ["observed", "concealed"].includes(v); } catch { /* no Visioner record */ }
  return true;
}
/** The player's answer (or the timer's): "steps", "stride" or "timeout". Offers the GM already answered are left as they are. */
async function answerSteps(key, answer, user = null) {
  const a = stepAsks.get(key); if (!a) return; stepAsks.delete(key);
  emitSocket({ t: "stepsClose", key });
  const combat = game.combats.get(a.combat); if (!combat) return;
  const by = sceneOf(combat)?.tokens.get(a.by), name = by?.name ?? "The creature";
  for (const id of a.ids) {
    const r = request(combat, id); if (!r?.reaction || r.reaction.ask?.key !== key) continue;
    /* `stepsSettling` holds Do it off while this offer's answer is written (review 1: Do it in that moment struck and was then marked Steps) */
    if (answer === "gm" || !by || r.state !== "ready" || running.has(id) || queued.has(id) || r.go) { await save(combat, id, { "reaction.ask": null }); continue; }
    stepsSettling.add(id);
    try {
      if (answer === "steps") { await save(combat, id, { state: "done", go: false, stepped: true, "reaction.ask": null, note: stepsAnswerWords("steps", name, user ?? a.names, a.n) }); continue; }
      if (answer === "stride") { const m = sceneOf(combat).tokens.get(r.tokenId), auto = !!m?.getFlag(ID, "run") && !!m?.getFlag(ID, "auto");
        await save(combat, id, { "reaction.ask": null, "reaction.sure": true, "reaction.why": null, "reaction.kind": stepsAnswerWords("stride", name, user ?? a.names, a.n), "reaction.auto": auto });
        if (auto) autoReaction(combat, id, by); continue; }
      await save(combat, id, { "reaction.ask": null, "reaction.why": `${r.reaction.why ?? ""} ${stepsAnswerWords("timeout", name, a.names, a.n)}`.trim() });
    } finally { stepsSettling.delete(id); }
  }
}
/** A chat card (the runner's `createChatMessage` hook): a ranged attack, a manipulate spell or action, a move action that leaves no square. */
export async function onActionCard(message) {
  if (!isRunner()) return;
  const tok = message.speaker?.token ? game.scenes.get(message.speaker.scene)?.tokens.get(message.speaker.token) : null, combat = tok && fightOf(tok); if (!combat) return;
  const f = message.flags?.pf2e ?? {}, c = f.context ?? {}, o = f.origin ?? null, html = `${message.flavor ?? ""} ${message.content ?? ""}`;
  const opts = [...(c.options ?? []), ...(o?.rollOptions ?? [])], read = readCard(html, opts, (c.traits ?? []).map(x => x?.name ?? x)), traits = new Set(read.traits);
  let item = null; if (o?.uuid) { try { item = fromUuidSync(o.uuid); } catch { item = null; } }
  const name = item?.name ?? read.title ?? null, slug = read.slug ?? (name ? game.pf2e.system.sluggify(name) : null);
  if (slug === "ready") return setReady(combat, tok);   /* a Ready card (0.35.0): the character is readied, and Ready itself triggers nothing */
  let consumable = null, srcName = null;
  if (o?.type === "consumable") {
    if (read.itemCard) return;   /* an item shown in chat, not used (review finding 4) */
    let src = item; if (!src && o.sourceId) src = await fromUuid(o.sourceId).catch(() => null); consumable = src?.system?.category ?? true; srcName = src?.name ?? null; for (const x of src?.system?.traits?.value ?? []) traits.add(x); }
  /* a ranged attack: a ranged weapon's roll, or a spell attack whose spell isn't touch (review finding 9) */
  const spellAttack = c.type === "attack-roll" && opts.some(x => /(?:^|:)item:type:spell$/.test(x)), ranged = spellAttack ? !/touch/i.test(String(item?.system?.range?.value ?? "")) : opts.includes("item:ranged") || (c.domains ?? []).includes("ranged-attack-roll");
  const trig = cardTrigger({ type: c.type ?? null, ranged, spell: !!f.casting, consumable, traits: [...traits], slug, name: name ?? srcName });
  if (!trig) return;
  /* one Cast a Spell is one trigger: its cast card (manipulate) and then its attack roll (ranged) would offer twice (seen live, 0.21.0) */
  if (f.casting && trig.gate === "manipulate") castCards.set(tok.actor.id, clock());
  if (spellAttack) { const at = castCards.get(tok.actor.id); castCards.delete(tok.actor.id); if (at && clock() - at < 60000) return; }
  if (slug === "stand") standCards.set(tok.actor.id, clock());
  if (trig.step) { stepCards.set(tok.actor.id, clock()); return; }
  if (trig.stride) { strideCards.set(tok.actor.id, clock()); return; }
  await offerAll(combat, tok, trig);
}
/** An item changed hands with no card (the runner's `updateItem` hook): drawing, stowing or picking up is an Interact, if it was an action. */
export function onItemHands(item, change) {
  const eq = change?.system?.equipped; if (!isRunner() || !eq || !("carryType" in eq || "handsHeld" in eq) || !item.actor) return;   /* invested and the like are not hands (review finding 7) */
  const now = { carry: item.system.equipped?.carryType, hands: item.system.equipped?.handsHeld ?? 0 }, before = carried.get(item.uuid) ?? null; carried.set(item.uuid, now);
  if (!before) return;   /* never seen (picked up new, or the page reloaded this turn): no guessing which way it went */
  const combat = game.combats.find(c => c.started && tokenIn(c, item.actor)), tok = combat && tokenIn(combat, item.actor); if (!tok) return;
  const trig = equipTrigger(before, now, item.name, combat.combatant?.tokenId === tok.id); if (trig) offerAll(combat, tok, trig).catch(e => console.error(`${ID} | reactions`, e));
}
/** Prone came off (the runner's `deleteItem` hook): if no Stand card comes with it, the GM is asked whether it stood up. */
export function onConditionGone(item) {
  if (!isRunner() || item.type !== "condition" || item.slug !== "prone" || !item.actor) return;
  const actor = item.actor, combat = game.combats.find(c => c.started && tokenIn(c, actor)), tok = combat && tokenIn(combat, actor); if (!tok) return;
  const ownTurn = combat.combatant?.tokenId === tok.id;   /* whose turn it was when Prone came off, not 1.5 s later (0.34.0, review 9) */
  setTimeout(() => { const at = standCards.get(actor.id), stood = !!at && clock() - at < CARD_MS;   /* the Stand card can land just after the condition goes */
    const trig = proneOffTrigger({ ownTurn, stood }); if (trig) offerAll(combat, tok, trig).catch(e => console.error(`${ID} | reactions`, e)); }, 1500);
}
/** The monsters' reactions the module doesn't run (anything but Reactive Strike), for the GM's card: [{ name, reaction, trigger }], one per kind of monster. */
export function monsterReactionsLeft(combat) {
  const out = [], seen = new Set();
  for (const c of combat?.combatants ?? []) { const a = c.token?.actor; if (!a?.isOfType?.("npc") || c.defeated) continue;
    for (const x of reactionsFor(a)) { if (MONSTER_REACTIONS.includes(x.slug)) continue; const k = `${a.name}.${x.name}`; if (seen.has(k)) continue; seen.add(k); out.push({ name: a.name, reaction: x.name, trigger: x.trigger ?? null }); } }
  return out;
}

/* ---------- fight memory (0.25.0, monster minds release 2): each monster's notebook ---------- */
/* The rules are memory.mjs's; this is who perceived what, and the writing. Lines live on the Combat's flag `notebook` (`memory` already means
   last-seen squares): notebook.<token id>.<key> = one line, written once by the runner in one update per event; a GM's page crosses a line out
   (a field on it) or adds her own (its own key). A line holds labels and fixed words only. The sources are PF2e's own cards (the feature doc's
   source table, from a live probe): a card is the event, and an HP drop with no card is "unsure what". */
const HP_WAIT = 1500;
const books = combat => combat?.getFlag(ID, "notebook") ?? {};
/** Who keeps a notebook: every creature that isn't a player's, ticked for Angel or not (a party member the GM plays too). */
const keepsBook = tok => runnable(tok) && !tok.actor?.hasPlayerOwner;
/** Unconscious and dead creatures write nothing (review 2); nor does one that got away. */
const awake = tok => !!tok?.actor && !tok.getFlag(ID, "escaped") && !isDeadNow(tok.actor) && !["unconscious", "dying"].some(c => tok.actor.hasCondition?.(c));
/** When a monster's last turn began, for "its allies' deeds since its last turn": during its own turn the turn before this one, otherwise this one. */
const deedsSince = (combat, tokenId) => { const m = turns(combat).nbTurn?.[tokenId] ?? [0, 0]; return combat.combatant?.tokenId === tokenId ? (m[0] ?? 0) : (m[1] ?? 0); };
async function markTurn(combat) { hpBaseline(combat); const id = combat.combatant?.tokenId; if (!id || !combat.started) return; const was = turns(combat).nbTurn?.[id] ?? [0, 0]; await saveTurns(combat, { [`nbTurn.${id}`]: [was[1] ?? 0, Date.now()] }); }
/** Its side's tally: itself and its allies in this fight, counted as standing, down, or fled (an escaped monster no longer in the tracker). */
function sideOf(combat, tok) {
  /* a GM-hidden ally isn't counted (it never reaches the thinker; a burrowed one is there), and one asleep isn't down: the builder puts Unconscious on a monster built asleep
     (0.33.1, review, as fallenWord has it) */
  const mine = t => t.id === tok.id || (!!t.actor?.isAllyOf?.(tok.actor) && (!t.hidden || isBelow(t))), inFight = combat.combatants.filter(c => c.token && mine(c.token));
  const fled = (sceneOf(combat)?.tokens.contents ?? []).filter(t => (t.id === tok.id || !!t.actor?.isAllyOf?.(tok.actor)) && t.getFlag(ID, "escaped")?.combat === combat.id && !inFight.some(c => c.tokenId === t.id)).length;
  const isOut = c => c.defeated || fallenWord(c.token) === "down" || isDeadNow(c.token.actor), down = inFight.filter(isOut).length;
  /* yielded (0.29.0): standing down in the tracker, or a prisoner out of it */
  const prisoners = (sceneOf(combat)?.tokens.contents ?? []).filter(t => mine(t) && prisonerOf(t)?.combat === combat.id && !inFight.some(c => c.tokenId === t.id)).length, yielding = inFight.filter(c => !isOut(c) && !!yieldOf(c.token)).length;
  return { started: inFight.length + fled + prisoners, standing: inFight.length - down - yielding, down, fled, yielded: yielding + prisoners };
}
/* one write at a time: events arrive in bursts (a card, its HP update, a save's flag) and each write reads the notebooks as they stand */
let bookQueue = Promise.resolve(), packetsBuilding = 0;
const packetsDone = async () => { for (let i = 0; i < 50 && packetsBuilding > 0; i++) await new Promise(r => setTimeout(r, 100)); };
const booked = work => { bookQueue = bookQueue.then(work).catch(e => console.warn(`${ID} | notebook`, e)); return bookQueue; };
/** Write lines ([{ id: token id, line }]) and any labels given out for them, in one update; a notebook over its cap loses its least useful lines. */
async function writeLines(combat, pairs, fresh = {}) {
  if (!pairs.length) { if (Object.keys(fresh).length) await saveTurns(combat, Object.fromEntries(Object.entries(fresh).map(([k, v]) => [`labels.${k}`, v]))); return; }
  const change = {}, added = {}, at = Date.now(); let n = 0;
  for (const { id, line } of pairs) { const key = lineKey(line.at || at, n++, foundry.utils.randomID(3)); (added[id] ??= {})[key] = line; }
  for (const [id, lines] of Object.entries(added)) {
    const gone = new Set(evict({ ...(books(combat)[id] ?? {}), ...lines }, STORE_MAX, deedsSince(combat, id)));
    for (const [key, line] of Object.entries(lines)) if (!gone.has(key)) change[`flags.${ID}.notebook.${id}.${key}`] = line;
    for (const key of gone) if (!(key in lines)) change[`flags.${ID}.notebook.${id}.${key}`] = foundry.data.operators.ForcedDeletion.create();
  }
  for (const [k, v] of Object.entries(fresh)) change[`flags.${ID}.turns.labels.${k}`] = v;
  if (Object.keys(change).length) await combat.update(change, { render: false, [ID]: { quiet: true } });
}
/** Every notebook keeper in the fight with how it perceives the one who did a thing and the one it was done to, right now (the moment the effect
    lands). A label is given out only for a creature the witness sees. */
function witnessList(combat, actorTok, targetTok) {
  const t = turns(combat), labels = { ...(t.labels ?? {}) }, fresh = {}, list = [];
  const labelOf = (x, rel) => { if (!labels[x.id]) { const f = assignLabels(labels, [x.id], rel === "enemy" ? "E" : "M"); Object.assign(labels, f); Object.assign(fresh, f); } return labels[x.id]; };
  for (const c of combat.combatants) { const w = c.token; if (!w?.object || !keepsBook(w) || !awake(w)) continue;
    const one = senser(combat, w, t.memory?.[w.id] ?? {});
    const side = x => !x ? null : x.id === w.id ? "self" : x.actor?.isAllyOf?.(w.actor) ? "ally" : x.actor?.isEnemyOf?.(w.actor) ? "enemy" : null;
    const view = x => { if (!x) return {}; const rel = side(x); if (rel === "self") return { state: "self", label: labelOf(x, rel) };
      const state = !x.object || (x.hidden && !isBelow(x)) ? "unnoticed" : one(x).state; return { state, label: SEES.includes(state) ? labelOf(x, rel) : null }; };
    list.push({ id: w.id, isActor: actorTok?.id === w.id, isTarget: targetTok?.id === w.id, actorIs: side(actorTok), targetIs: side(targetTok), actor: view(actorTok), target: view(targetTok), knows: (w.actor.itemTypes?.spell ?? []).map(s => s.slug).filter(Boolean) }); }
  return { list, fresh };
}
/** Something happened: every creature that perceived it gets its lines. Runner only; off the fight's map the notebooks get a gap line instead. */
function noteEvent(combat, event, actorTok = null, targetTok = null) {
  if (!isRunner() || !combat?.started) return;
  if (!onFightScene(combat)) { noteGap(combat); return; }
  booked(async () => { await packetsDone(); const { list, fresh } = witnessList(combat, actorTok, targetTok); await writeLines(combat, witnessLines(event, list, { round: combat.round, at: Date.now() }), fresh); });
}
/* a gap line once a round at most, from this page */
const gapAt = new Map();
/** The runner was away (a reload, another scene on its page): every notebook says it missed part of this round, instead of silence (review 2). */
function noteGap(combat) {
  hpBaseline(combat);
  if (!isRunner() || !combat?.started || gapAt.get(combat.id) === combat.round) return;
  gapAt.set(combat.id, combat.round);
  booked(() => writeLines(combat, witnessLines({ kind: "gap" }, combat.combatants.filter(c => c.token && keepsBook(c.token) && awake(c.token)).map(c => ({ id: c.tokenId })), { round: combat.round, at: Date.now() })));
}
const fightOn = sceneId => game.combats.find(c => c.started && sceneOf(c)?.id === sceneId) ?? null;
/** The token a card's actor uuid means: its own token when the uuid names one, else the linked actor's token on the fight's map. */
const tokenByUuid = (scene, uuid) => { const u = String(uuid ?? ""), t = /Token\.([A-Za-z0-9]+)/.exec(u); if (t) return scene.tokens.get(t[1]) ?? null; const a = /Actor\.([A-Za-z0-9]+)/.exec(u); return a ? (scene.tokens.find(x => x.actorLink && x.actorId === a[1]) ?? scene.tokens.find(x => x.actorId === a[1]) ?? null) : null; };
/* when each creature's last damage-taken card came, so an HP drop with no card can be told apart; and the HP this page last saw for each */
const cardAt = new Map(), hpSeen = new Map();
const hpBaseline = combat => { for (const c of combat?.combatants ?? []) if (c.token?.actor && !hpSeen.has(c.tokenId)) hpSeen.set(c.tokenId, hpNow(c.token)); };
/** A chat card that says something happened in a fight (the source table in docs/features/memory.md). */
/** The blow that took a creature to 0 hit points (0.28.0 live test): a creature that is down writes nothing in its own notebook, so who struck
    it down is kept on the turns flag (`dropped.<token>`: { by, round }) for a band that fights harder (`dropperOf`). The striker is named only
    when one of the fallen creature's own side, awake, saw it at that moment (observed or concealed), as a notebook names only whom its keeper
    saw; else `by` is null (lasting damage, a striker nobody saw). A card that leaves the creature above 0 again takes the entry away, so an old
    name never stands for a later fall (0.28.0 build-2 review 1 and 3). Written in the notebooks' queue, by the runner. */
function noteDropped(combat, tok, striker) {
  if (!isRunner() || !combat?.started || !tok?.actor) return;
  const down = (tok.actor.hitPoints?.value ?? 1) <= 0, id = tok.id;
  booked(async () => {
    const was = turns(combat).dropped?.[id] ?? null;
    if (!down) { if (was) await saveTurns(combat, { [`dropped.${id}`]: gone() }); return; }
    let by = null;
    if (striker && onFightScene(combat)) { await packetsDone(); by = witnessList(combat, striker, tok).list.some(w => w.id !== striker.id && w.targetIs === "ally" && SEES.includes(w.actor?.state)) ? striker.id : null; }
    await saveTurns(combat, { [`dropped.${id}`]: whole({ by, round: combat.round }) });
  });
}
export function onMemoryCard(message) {
  if (!isRunner()) return;
  const f = message.flags?.pf2e ?? {}, ctx = f.context ?? {}, combat = fightOn(message.speaker?.scene); if (!combat) return;
  const scene = sceneOf(combat), speaker = scene.tokens.get(message.speaker?.token) ?? null;
  if (ctx.type === "damage-taken") {
    if (!speaker?.actor) return; cardAt.set(speaker.id, performance.now());
    const applied = f.appliedDamage ?? null, origin = f.origin ?? null, lasting = origin?.type === "condition";
    let iwr = []; try { const m = /data-applications="([^"]*)"/.exec(message.content ?? ""); if (m) iwr = JSON.parse(m[1].replace(/&quot;/g, '"').replace(/&amp;/g, "&")); } catch { iwr = []; }
    if (!Array.isArray(iwr)) iwr = [];
    /* who did it: the card's origin; a card with none while this page is carrying out a monster's step is that monster's own hit */
    const actor = lasting ? null : origin?.actor ? tokenByUuid(scene, origin.actor) : pending?.tokenId && pending.tokenId !== speaker.id && message.author?.id === game.user.id ? scene.tokens.get(pending.tokenId) ?? null : null;   /* only a card this page posted itself (review 4) */
    noteDropped(combat, speaker, applied?.isHealing ? null : actor);
    /* struck after it yielded (0.29.0, R3-7): only an enemy's blow ends it, never healing, lasting damage or a card that names nobody */
    if (yieldOf(speaker) && breaksYield({ healing: !!applied?.isHealing, lasting, enemy: !!actor?.actor && !!speaker.actor.isEnemyOf?.(actor.actor) })) endYield(combat, speaker, "struck", actor.id).catch(e => console.warn(`${ID} | yield`, e));
    if (applied?.isHealing) { if (actor) noteEvent(combat, { kind: "heal" }, actor, speaker); return; }
    /* how much: the card keeps what it took off its HP and temporary HP, to give back on a revert (seen in the probe: 23 for a hit that left 57 of 80; 20 for one that took a creature's last 20) */
    const hp = speaker.actor.hitPoints ?? {}, HP_PATHS = ["system.attributes.hp.value", "system.attributes.hp.temp"];
    const amount = applied ? Math.max(0, (applied.updates ?? []).reduce((sum, u) => HP_PATHS.includes(u.path) ? sum + (Number(u.value) || 0) : sum, 0)) : 0;
    let kind = null; if (lasting) { try { kind = fromUuidSync(origin.uuid)?.system?.persistent?.damageType ?? "lasting"; } catch { kind = "lasting"; } }
    noteEvent(combat, { kind: "damage", amount, max: hp.max ?? 0, iwr, actor: !!actor, ...(kind ? { persistent: kind } : {}) }, actor, speaker);
    if (applied?.shield) noteEvent(combat, { kind: "block" }, speaker, actor);   /* a shield took part of it */
    return;
  }
  if (ctx.type === "spell-cast" || (f.casting && !ctx.type)) {
    if (!speaker) return; let item = message.item ?? null; if (!item && f.origin?.uuid) { try { item = fromUuidSync(f.origin.uuid); } catch { item = null; } }
    noteEvent(combat, { kind: "cast", slug: item?.slug ?? null, words: spellWords({ traits: [...(item?.system?.traits?.value ?? [])], area: item?.system?.area ?? null, attack: !!item?.isAttack, save: item?.system?.defense?.save?.statistic ?? null }) }, speaker, null);
    return;
  }
  if (ctx.type === "attack-roll" && ctx.target?.token && ctx.outcome in DEGREE) {
    const actor = scene.tokens.get(ctx.token ?? message.speaker?.token) ?? speaker, target = tokenByUuid(scene, ctx.target.token);
    if (actor && target && (keepsBook(actor) || combat.combatants.some(c => c.token && keepsBook(c.token) && c.token.actor?.isAllyOf?.(actor.actor)))) noteEvent(combat, { kind: "attack", degree: DEGREE[ctx.outcome] }, actor, target);
  }
}
/** A save rolled on Toolbelt's row leaves no card: it arrives as a flag on the spell's or the damage card. A creature that saved against a
    monster's own magic is something that monster tried that failed. */
export function onMemoryUpdate(message, change) {
  if (!isRunner()) return;
  const variants = change?.flags?.[TOOLBELT]?.targetHelper?.saveVariants; if (!variants || typeof variants !== "object") return;
  const combat = fightOn(message.speaker?.scene), caster = sceneOf(combat)?.tokens.get(message.speaker?.token); if (!caster || !keepsBook(caster)) return;
  for (const v of Object.values(variants)) for (const [tid, sv] of Object.entries(v?.saves ?? {})) { const target = sceneOf(combat).tokens.get(tid);
    if (target && (sv?.success === "success" || sv?.success === "criticalSuccess")) noteEvent(combat, { kind: "saved", item: message.item?.name ?? null }, caster, target); }
}
/** An HP drop: if no damage-taken card comes for that creature, nobody knows what did it (HP typed by hand): "something hurt it, unsure what". */
export function onMemoryHp(actor, change, options) {
  if (!isRunner() || !foundry.utils.hasProperty(change ?? {}, "system.attributes.hp")) return;
  const combat = game.combats.find(c => c.started && c.combatants.some(x => x.actor === actor)), tok = combat?.combatants.find(x => x.actor === actor)?.token; if (!tok || !keepsBook(tok)) return;
  /* how much: PF2e's own figure when the update carries one (a card's damage, and a linked actor's hand edit), else against the HP this page last
     saw for it (an unlinked token's hand edit carries none: seen live in 0.25.0's test) */
  const now = hpNow(tok), was = hpSeen.get(tok.id); hpSeen.set(tok.id, now);
  const taken = Number(options?.damageTaken) > 0 ? Number(options.damageTaken) : was != null ? was - now : 0; if (taken <= 0) return;
  const at = performance.now();
  setTimeout(() => { if ((cardAt.get(tok.id) ?? -1e9) >= at - 500 || !game.combats.get(combat.id)?.started || !awake(tok)) return;
    booked(() => writeLines(combat, [{ id: tok.id, line: { k: "hurt", s: severity(taken, actor.hitPoints?.max ?? 0), sure: 0, r: combat.round, at: Date.now() } }])); }, HP_WAIT);
}
/** The answers to a monster's action (0.20.0's reactions): who struck as it moved or lowered its guard, who blocked. */
function noteReactionAnswers(combat, tok, final) {
  for (const x of final ?? []) { if (x.answer !== "done") continue; const who = sceneOf(combat).tokens.get(x.token); if (!who) continue;
    if (["reactive-strike", "attack-of-opportunity"].includes(x.slug)) noteEvent(combat, { kind: "reactive" }, who, tok);
    else if (x.slug === "shield-block") noteEvent(combat, { kind: "block" }, who, tok); }
}
/* ---------- the leader's orders in the fight (0.28.0, monster minds release 3, tier 3b; docs/features/orders.md) ---------- */
/* Everything lives in the turns flag under `orders`: `log` (the band log the History reads, append-only), `heard` (each hearer's standing orders),
   `last` (the round of each band's last order), `calls` (the GM's own "can't hear" calls, for one round), `pending` (an order from her Give orders
   box, waiting for the runner) and `refused` (why the runner turned one down). What a leader's fall changed for the rest of the fight is on the
   Combat's `bands` and `minds` flags (the this-fight layers bands.mjs and minds.mjs already read). The runner is the only writer of all but
   `calls` and `pending`. */
const ordersOf = combat => turns(combat).orders ?? {};
const langName = slug => { const k = CONFIG.PF2E?.languages?.[slug]; return k ? game.i18n.localize(k) : String(slug ?? "").replace(/^./, c => c.toUpperCase()); };
const soundBlocked = (a, b) => !!CONFIG.Canvas.polygonBackends.sound.testCollision(a, b, { mode: "any", type: "sound" });
const gone = () => foundry.data.operators.ForcedDeletion.create();
/** The band log, oldest first: [{ key, ...entry }]. */
export const bandLog = combat => Object.entries(ordersOf(combat).log ?? {}).filter(([, e]) => e && typeof e === "object").sort((a, b) => a[0] < b[0] ? -1 : 1).map(([key, e]) => ({ key, ...e }));
/** A creature's band as an order sees it: whether it leads now, the others, those who follow orders and still stand, and the kinds. Null without a band. */
function orderFacts(combat, tok) {
  const scene = sceneOf(combat), band = tok ? bandOf(scene, tok) : null; if (!band) return null;
  const lead = leaderOf(scene, band, combat), members = membersOf(scene, band.key).filter(t => t.id !== tok.id), follows = t => PLANNED.includes(disciplineOf(scene, t, combat)) && !fellWord(t);
  const fell = fightBand(combat, band.key)?.fell, turnedAway = fell?.state === "turned" && !lead.took && lead.tok?.id !== fell.was;   /* its leader changed sides: nobody leads by the guess now (0.33.1, review) */
  return { band, leads: !turnedAway && lead.tok?.id === tok.id && follows(tok), members, followers: members.filter(follows), groups: jobGroups(scene, band) };
}
/** A kind's name as the thinker may read it: a brief row's name is typed by someone, so one that names a party member is left out (0.33.1, review,
    as the band's jobs are gated in bands.mjs). */
const kindWord = (scene, name) => { const g = noteForThinker(String(name ?? ""), partyPeople(scene, () => null)); return g.unknown.length || g.ambiguous.length ? "" : String(name ?? ""); };
/** For the plan check and the packet: null when it leads no band, else { ok, why, jobs: [{ id, name }], fallBack }. */
function orderCtx(combat, tok) {
  const f = orderFacts(combat, tok); if (!f?.leads) return null;
  const can = canOrder({ leads: true, followers: f.followers.length, cantAct: cantAct(tok.actor), langs: langsOf(tok.actor), below: isBelow(tok), round: combat.round, last: ordersOf(combat).last?.[f.band.key] ?? null, forms: P(tok, combat) });
  /* a kind's job can be ordered only when someone of that kind besides the leader takes spoken orders (0.28.0 live test: the list offered the
     leader's own kind when it was alone in it, and a wolf's) */
  const told = new Set(f.followers.map(t => t.id));
  return { ...can, jobs: f.groups.filter(g => g.tokens.some(id => told.has(id))).map(g => ({ id: g.id, name: g.name })), fallBack: fallBackWords(planOf(sceneOf(combat), f.band, combat).fallBack) };
}
/** Who of its band gets an order from this leader as things stand: { lang, canTest, list: [{ id, name, hears, why, called, listens }] }. The sound
    test needs the fight on this page's canvas (`canTest`); without it only the conditions, the language and the GM's calls decide. Membership is
    the band's own data, never the list of allies a monster is told of, so an ambusher the GM has hidden hears its leader (design review 9). */
function hearersOf(combat, lead, f = orderFacts(combat, lead), named = []) {
  const scene = sceneOf(combat), calls = ordersOf(combat).calls ?? {}, canTest = onFightScene(combat) && !!lead.object, memory = turns(combat).memory ?? {};
  /* `named`: the creatures the order names. A hearer that has never perceived one of them (nothing in its last-seen memory) and isn't on its
     side is told it exists, not where (R3-14): the cards say so beside its name, as the sample Rhea approved showed. */
  const foes = named.map(id => scene.tokens.get(id)).filter(x => x?.actor);
  const lang = orderLanguage(langsOf(lead.actor), f.followers.map(t => langsOf(t.actor)));
  const list = f.members.map(t => { const call = calls[t.id]?.round === combat.round ? calls[t.id].v : null, a = t.actor, discipline = disciplineOf(scene, t, combat);
    const h = hearing({ member: { fallen: !!fallenWord(t), yielded: stoodDown(t), discipline, asleep: !!a?.hasCondition?.("unconscious"), deafened: !!a?.hasCondition?.("deafened"), below: isBelow(t), langs: langsOf(a), path: canTest && t.object ? !soundBlocked(lead.object.center, t.object.center) : null }, lang, call });
    const unseen = h.hears ? foes.filter(x => x.id !== t.id && !memory[t.id]?.[x.id] && !!a && !x.actor.isAllyOf?.(a)).map(x => x.name) : [];
    return { id: t.id, name: t.name, ...h, called: call != null, listens: PLANNED.includes(discipline) && !fellWord(t), unseen }; });
  return { lang, canTest, list };
}
/** An order worked out, nothing written: { ok, why } or { ok, key, change (for the turns flag), entry, heard, band }. */
function orderOut(combat, lead, order, { by = "angel" } = {}) {
  const f = orderFacts(combat, lead), ctx = f?.leads ? orderCtx(combat, lead) : { ok: false, why: "it doesn't lead a band" }; if (!ctx.ok) return { ok: false, why: ctx.why };
  const { lang, list } = hearersOf(combat, lead, f), heard = list.filter(x => x.hears), missed = Object.fromEntries(list.filter(x => !x.hears && x.listens).map(x => [x.id, x.why]));
  const { say, ...o } = order, labels = turns(combat).labels ?? {}, tid = o.target ? Object.keys(labels).find(id => labels[id] === o.target) : null, t = tid ? sceneOf(combat).tokens.get(tid) : null;
  const words = orderWords(o, { ally: !!t && (t.id === lead.id || !!t.actor?.isAllyOf?.(lead.actor)), jobName: f.groups.find(g => g.id === o.job)?.name ?? "", fallBack: ctx.fallBack });
  const key = lineKey(Date.now(), 0, foundry.utils.randomID(3)), standing = ordersOf(combat).heard ?? {};
  const entry = { k: "order", band: f.band.key, r: combat.round, at: Date.now(), by, from: lead.id, o, words, ...(say ? { say } : {}), ...(lang ? { lang } : {}), heard: heard.map(x => x.id), missed };
  const change = { [`orders.log.${key}`]: entry, [`orders.last.${f.band.key}`]: combat.round };
  /* the leader keeps its own order too (review 3): its later packets say what it last ordered, and it follows it itself */
  for (const id of [lead.id, ...heard.map(x => x.id)]) change[`orders.heard.${id}`] = whole(applyHeard(standing[id], o, combat.round));
  return { ok: true, key, change, entry, heard, band: f.band };
}
/** The order's line in chat (R3-4, as far as tier 3b goes): one public line from the leader. Everyone's browser holds "Shouts something in
    <language>."; a GM's browser shows the words, the order and how many heard instead (`onRenderOrder`). The words by each player's languages come
    with tier 3c. A leader whose token the GM has hidden says nothing in chat: the line would give the ambush away. Out: the message's id or null. */
async function orderChat(combat, lead, entry) {
  if (lead.hidden) return null;
  const lang = entry.lang ? langName(entry.lang) : null, n = namer(turns(combat).labels ?? {}, Object.fromEntries(sceneOf(combat).tokens.contents.map(x => [x.id, x.name])));
  /* a leader every character has hidden or undetected (Visioner) shouts as "A voice", as its spoken lines do (0.33.1, review) */
  const voice = unseenByParty(lead), speaker = voice ? { scene: sceneOf(combat).id, actor: null, token: null, alias: "A voice" } : ChatMessage.implementation.getSpeaker({ token: lead });
  const m = await ChatMessage.implementation.create({ speaker, whisper: [], blind: false, content: `<p>Shouts something${lang ? ` in ${esc(lang)}` : ""}.</p>`,
    /* slug and pwords (0.29.0, R3-4): a player whose character knows the language reads the sentence, or the order in names made for players */
    flags: { [ID]: { order: { say: entry.say ?? null, lang, slug: entry.lang ?? null, words: n.named(entry.words), pwords: playerWords(combat, lead, entry), heard: entry.heard.length, of: entry.heard.length + Object.keys(entry.missed ?? {}).length, ...(voice ? { voice: true, who: lead.name } : {}) } } } });
  return m?.id ?? null;
}
/** On a GM's page, an order's chat line shows what was said and ordered; players keep the line as it is stored. */
export function onRenderOrder(message, html) {
  const o = message.getFlag?.(ID, "order"); if (!o || !message.author?.isGM) return;   /* only a GM's own message is an order's line (review 9) */
  const body = html.querySelector?.(".message-content"); if (!body) return;
  if (!game.user.isGM) { const h = understands(myLanguages(), o.slug) ? orderHtml(o, P(game.scenes.get(message.speaker?.scene)?.tokens.get(message.speaker?.token))) : ""; if (h) body.innerHTML = h; return; }   /* 0.29.0: by the player's own languages */
  body.innerHTML = `<p><strong>Order</strong>${o.voice ? ` (${esc(o.who ?? "")}, unseen)` : ""} <span class="action-glyph">F</span> ${o.say ? `“${esc(o.say)}”` : esc(o.words ?? "")}</p><p style="font-size:var(--font-size-12);opacity:.75;border-top:1px solid #8884;margin-top:4px;padding-top:3px">${[o.lang ? `In ${esc(o.lang)}` : "", o.say ? esc(o.words ?? "") : "", `heard by ${Number(o.heard) || 0} of its ${Number(o.of) || 0}`].filter(Boolean).join(" · ")}</p>`;
}
/** The `order` step of a leader's plan: speech, so no roll and no card of PF2e's. One write gives the order to every hearer, logs it and marks
    the step, so a reload can't give it twice or leave it half given. */
async function runOrder(combat, id, i, step, tok) {
  const rec = request(combat, id).log?.[i] ?? {}; if (rec.given || rec.skipped) return "next";
  if (!stepGate("order", id)) return "stopped";
  const out = orderOut(combat, tok, step.order, { by: "angel" });
  if (!out.ok) { await save(combat, id, { log: { [i]: { skipped: out.why } }, note: joinNote(combat, id, `${tok.name} gave no order: ${out.why}.`) }); return "next"; }
  await saveTurns(combat, { ...out.change, [`requests.${id}.log.${i}`]: { given: out.key, heard: out.entry.heard, missed: out.entry.missed, ...(out.entry.lang ? { lang: out.entry.lang } : {}) }, [`requests.${id}.since`]: clock() });
  const msg = await orderChat(combat, tok, out.entry).catch(e => { console.warn(`${ID} | order chat`, e); return null; });
  if (msg) await saveTurns(combat, { [`orders.log.${out.key}.msg`]: msg, [`requests.${id}.log.${i}.message`]: msg });
  return "next";
}
/** What a monster's packet carries of orders (orders.mjs `ordersForPacket`). Only for a member that follows a leader. */
function ordersBlock(combat, tok, { labels = {}, nameable = new Set(), memory = {}, discipline = "loose" } = {}) {
  const scene = sceneOf(combat), band = bandOf(scene, tok); if (!band || !PLANNED.includes(discipline)) return null;
  const standing = ordersOf(combat).heard?.[tok.id] ?? {}, groups = jobGroups(scene, band), mine = groups.find(g => g.tokens.includes(tok.id))?.id ?? null;
  const byLabel = Object.fromEntries(Object.entries(labels).map(([id, l]) => [l, id])), fb = fallBackWords(planOf(scene, band, combat).fallBack);
  const wordsOf = o => { const t = o.target ? scene.tokens.get(byLabel[o.target]) : null, self = !!t && t.id === tok.id;
    return orderWords(self ? { ...o, target: "yourself" } : o, { ally: self || !!t?.actor?.isAllyOf?.(tok.actor), mine: !!o.job && o.job === mine, jobName: kindWord(scene, groups.find(g => g.id === o.job)?.name ?? ""), fallBack: fb }); };
  /* told of, not seen (Rhea, R3-14): a creature an order names that it neither perceives nor remembers: it exists for it, with no square */
  const named = [...labelsIn(standing), ...(String(fightBand(combat, band.key)?.objective ?? "").match(/\b[EM]\d{1,3}\b/g) ?? [])];
  const unseen = [...new Set(named)].filter(l => { const id = byLabel[l]; return !!id && !nameable.has(id) && !memory[id]; });
  const give = orderCtx(combat, tok);   /* the kinds' names as the thinker may read them (her box keeps the real ones) */
  return ordersForPacket({ standing, wordsOf, unseen, give: give ? { ...give, jobs: (give.jobs ?? []).map(j => ({ ...j, name: kindWord(scene, j.name) || "some of the band" })) } : give });
}
/** A band's leader has fallen: the module does what the band's pick says (R3-2; tier 3a only told the thinker). Runner only, at every turn change,
    once for each fall (`fell.was` on the Combat's `bands` flag). A leader the GM has hidden isn't reported fallen (bands, open items). */
const settling = new Map();
async function settleBands(combat) {
  if (!isRunner() || !combat?.started || !sceneOf(combat)) return;
  /* two turn changes close together must not both act on one fall (review 8): the second waits for the first, so its turn is still asked for
     only after the fall is settled (build-2 review 5). The work runs in the notebooks' queue: who struck a leader down is written there from
     the blow's card, and a label given out here must not cross one given out there (build-2 review 2). The queue swallows errors, so they are
     caught and said here. */
  const going = settling.get(combat.id); if (going) return going;
  const work = booked(() => settleBandsNow(combat).catch(e => console.error(`${ID} | bands`, e))).finally(() => settling.delete(combat.id));
  settling.set(combat.id, work); return work;
}
async function settleBandsNow(combat) {
  const scene = sceneOf(combat), change = {}, fresh = {};
  for (const band of bandsOf(scene)) {
    /* a leader that changed sides (0.30.0, R3-15): "If the leader falls" fires once, as for any fall; it no longer counts as a member, so the
       marked leader reads as gone and a guessed one is silently passed over: the books (`turned`) say who it was */
    const tn = turns(combat).turned?.[band.key] ?? null, lead0 = leaderOf(scene, band, combat), useTurned = !!tn && !tn.done;   /* `done` is written with the fall itself: a later fall of the heir rewrites `fell.was`, which so can't say (0.30.0 review 1) */
    const heir0 = fightBand(combat, band.key)?.leader?.token, f0 = fightBand(combat, band.key)?.fell;
    /* its leader changed sides and the module acted on it with a pick other than Next in line: nobody leads by the guess, so a guessed member's fall
       is no leader's fall (review of 0.33.1; bandlib's `bandPacket` and `orderFacts` read it the same way) */
    if (!useTurned && f0?.state === "turned" && !lead0.took && lead0.tok?.id !== f0.was) continue;
    if (tn && !useTurned && lead0.gone && !(heir0 && !scene.tokens.get(heir0))) continue;   /* already acted on: the mark still points at the one that left; unless the heir has left the map since (0.33.1, review) */
    const lead = useTurned ? { tok: scene.tokens.get(tn.token) ?? null, gone: false } : lead0, state = useTurned ? "turned" : lead.gone ? "gone" : lead.tok ? fellWord(lead.tok) : null; if (!state) continue;
    if (!useTurned && lead.tok?.hidden && !lead.tok.getFlag(ID, "escaped")) continue;
    /* acted on already, unless the one who took over has since left the map: then the next in line is found again (review 13) */
    const was = useTurned ? tn.token : lead.tok?.id ?? "gone", now = fightBand(combat, band.key), heirGone = !!now?.leader?.token && !scene.tokens.get(now.leader.token); if (now?.fell?.was === was && !heirGone && !((["yielded", "turned"].includes(now.fell.state) || state === "turned") && state !== now.fell.state)) continue;   /* one that gave itself up and was later struck down has fallen again (0.29.0 review 2) */
    const members = membersOf(scene, band.key), pick = natureOf(natureLayers(scene, band, combat)).ifLeaderFalls?.pick ?? null;
    /* who struck it down: the blow that took it to 0 hit points, else the last sure blow in its notebook; an enemy of the leader only. One that
       has no label yet gets one here, so the new objective can name it */
    const labels = { ...(turns(combat).labels ?? {}), ...fresh }, dropper = lead.tok && !useTurned ? dropperOf({ dropped: turns(combat).dropped?.[lead.tok.id] ?? null, book: books(combat)[lead.tok.id], labels, isEnemy: id => !!scene.tokens.get(id)?.actor?.isEnemyOf?.(lead.tok.actor) }) : null;
    if (dropper && !dropper.label && pick === "harder") { const f = assignLabels(labels, [dropper.id], "E"); Object.assign(fresh, f); dropper.label = f[dropper.id]; change[`flags.${ID}.turns.labels.${dropper.id}`] = dropper.label; }
    const out = fallOutcome({ pick, state, leaderId: lead.tok?.id ?? null, second: secondOf(scene, band)?.id ?? null, dropper: dropper?.label ?? null,
      members: members.map(t => ({ id: t.id, level: t.actor?.level ?? 0, speaks: langsOf(t.actor).length > 0, discipline: disciplineOf(scene, t, combat), standing: !fellWord(t) && !(t.hidden && !t.getFlag(ID, "escaped") && !isBelow(t)) })) });
    const at = `flags.${ID}.bands.${band.key}`;
    change[`${at}.fell`] = whole({ was, state, round: combat.round, pick });
    if (useTurned) change[`flags.${ID}.turns.turned.${band.key}.done`] = true;
    if (out.leader) { change[`${at}.leader`] = whole({ token: out.leader }); change[`flags.${ID}.turns.orders.last.${band.key}`] = gone(); }   /* the new leader may give its own order on its turn, this round too (R3-2) */
    else if (heirGone) change[`${at}.leader`] = gone();
    if (out.planGone) { change[`${at}.planGone`] = true; for (const t of members) if (ordersOf(combat).heard?.[t.id]) change[`flags.${ID}.turns.orders.heard.${t.id}`] = gone(); }   /* with the plan, the orders that changed it */
    /* the new objective takes the place of whatever the fallen leader last ordered the whole band to do (review 4): orders heard rank above the plan */
    if (out.objective) { change[`${at}.objective`] = out.objective; for (const t of members) if (ordersOf(combat).heard?.[t.id]?.goal) change[`flags.${ID}.turns.orders.heard.${t.id}.goal`] = gone(); }
    for (const id of out.loosen) change[`flags.${ID}.minds.own.${id}.discipline`] = whole({ pick: "loose", text: "", by: "module" });
    for (const id of out.never) change[`flags.${ID}.minds.own.${id}.givesUp`] = whole({ text: NEVER_GIVES_UP, by: "module" });
    change[`flags.${ID}.turns.orders.log.${lineKey(Date.now(), Object.keys(change).length % 36, foundry.utils.randomID(3))}`] = { k: "fell", band: band.key, r: combat.round, at: Date.now(), was, state, pick, leader: out.leader, loosen: out.loosen, objective: out.objective, never: out.never };
  }
  if (Object.keys(change).length) await combat.update(change, { render: false, [ID]: { quiet: true } });
}
/** Who a GM's own order can name (design review 8: gated against the leader's perception, once, when it is given): as for a line she adds to
    its notebook. */
function orderGate(combat, tok, text, labels = labelsFor(combat, tok).labels) {
  const t = turns(combat), ids = [...Object.keys(t.memory?.[tok.id] ?? {}), ...knownAllies(sceneOf(combat), tok).map(a => a.id)];
  return noteForThinker(String(text ?? ""), notePeople(combat, { tokenId: tok.id, labels: Object.fromEntries(ids.filter(id => labels[id]).map(id => [labels[id], id])), packet: { you: { label: labels[tok.id] ?? "it" }, allies: [] } }, labels), 120);
}
/** The fight's labels as they would stand once every creature this leader has perceived has one: { labels, fresh }. Only the runner saves `fresh`
    (when the order is given); another GM's page uses them to show her words as they would be stored. */
function labelsFor(combat, tok) {
  const labels = { ...(turns(combat).labels ?? {}) }, need = Object.keys(turns(combat).memory?.[tok.id] ?? {}).filter(id => !labels[id] && sceneOf(combat).tokens.get(id));
  const fresh = { ...assignLabels(labels, need, "E") }; Object.assign(labels, fresh);
  /* itself and its allies too (review 2: "protect the shaman" in a fight where no packet has given out labels yet) */
  const own = { ...assignLabels(labels, [tok.id, ...knownAllies(sceneOf(combat), tok).map(a => a.id)], "M") }; Object.assign(labels, own, fresh);
  return { labels, fresh: { ...fresh, ...own } };
}
/** The Give orders box, on any GM's page (R3-5): whether this creature may give an order now, the kinds whose job it can change, the creatures it
    perceives this round (for "Everyone on that one"), who would hear it, and how her own words would be stored. Null for a creature that leads
    no band. order: what the box holds now ({ part, targetId, at, job, text, say }), or nothing. */
export function orderPreview(combat, tokenId, order = null) {
  const tok = sceneOf(combat)?.tokens.get(tokenId), f = tok ? orderFacts(combat, tok) : null; if (!f?.leads) return null;
  const ctx = orderCtx(combat, tok), t = turns(combat), mem = t.memory?.[tokenId] ?? {}, o = ordersOf(combat);
  const targets = Object.entries(mem).filter(([, m]) => m?.round === combat.round).map(([id]) => sceneOf(combat).tokens.get(id)).filter(x => x?.actor && !x.hidden && x.actor.isEnemyOf?.(tok.actor)).map(x => ({ id: x.id, name: x.name }));
  const lf = labelsFor(combat, tok), back = Object.fromEntries(Object.entries(lf.labels).map(([id, l]) => [l, sceneOf(combat).tokens.get(id)?.name ?? l]));
  const g0 = order?.text ? orderGate(combat, tok, order.text, lf.labels) : null, gate = g0 ? { ...g0, shown: g0.text.replace(/\b[EM]\d{1,3}\b/g, l => back[l] ?? l) } : null, last = bandLog(combat).filter(e => e.k === "order" && e.band === f.band.key).at(-1) ?? null;
  /* the creatures this order would name: the one picked, or the labels her own words came to */
  const named = order?.targetId ? [order.targetId] : g0 ? [...new Set(g0.text.match(/\b[EM]\d{1,3}\b/g) ?? [])].map(l => Object.keys(lf.labels).find(id => lf.labels[id] === l)).filter(Boolean) : [];
  return { can: ctx, band: f.band.name, jobs: ctx.jobs, targets, hearers: hearersOf(combat, tok, f, named), gate, refusal: gate ? noteRefusal(gate, tok.name, "order") || null : null,
    pending: !!o.pending?.[f.band.key], refused: o.refused?.[f.band.key]?.round === combat.round ? o.refused[f.band.key].why ?? null : null, last: last?.r === combat.round ? last : null, square: squareOf(tok, sceneOf(combat)), langName };
}
/** The GM gives an order as the leader she plays (R3-5). It waits on the flag for the runner, which works out who hears it on the fight's own map,
    exactly as for an order from a plan. order: { part, targetId (a token), at ([x, y]), job (a kind's id), text (her own words for the objective
    or a job), say (the sentence said aloud, for chat and the History) }. */
export async function giveOrder(combat, tokenId, order = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const tok = sceneOf(combat)?.tokens.get(tokenId), f = tok ? orderFacts(combat, tok) : null; if (!f?.leads) throw new Error(`${tok?.name ?? "That creature"} doesn't lead a band.`);
  const ctx = orderCtx(combat, tok); if (!ctx.ok) throw new Error(`${tok.name} can't give an order now: ${ctx.why}.`);
  const away = runnerProblem(); if (away) throw new Error(away);   /* nobody to give it: say so now, as a Change does (review 5) */
  if (order.text) { const bad = noteRefusal(orderGate(combat, tok, order.text), tok.name, "order"); if (bad) throw new Error(bad); }
  const c = cleanOrder({ ...order, text: order.text ? "x" : "", target: order.targetId ? "E1" : null }, { gm: true }); if (!c.ok) throw new Error(c.reason.replace(/^an order/, "An order"));
  if (c.order.job && !ctx.jobs.some(j => j.id === c.order.job)) throw new Error("Its band has no such kind.");
  await saveTurns(combat, { [`orders.pending.${f.band.key}`]: whole(toPending(order, { from: tokenId, round: combat.round, ts: Date.now() })), [`orders.refused.${f.band.key}`]: null });
}
/** Her call on who hears this round's order ("for what the module can't know"): v "yes" | "no", or null to leave it to the module again. */
export async function setHearCall(combat, tokenId, v) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  await saveTurns(combat, { [`orders.calls.${tokenId}`]: v === "yes" || v === "no" ? whole({ v, round: combat.round }) : gone() });
}
const pendingNow = new Set();
/** The runner picks up an order from the GM's box: the creature she named gets a label if it has none, her own words go through the name gate,
    and the order is given like any other. A refusal is written where the box shows it. */
async function runPending(combat) {
  if (!isRunner()) return;
  for (const [key, p] of Object.entries(ordersOf(combat).pending ?? {})) {
    const lock = `${combat.id}.${key}`; if (!p || pendingNow.has(lock)) continue; pendingNow.add(lock);
    try {
      const refuse = why => saveTurns(combat, { [`orders.pending.${key}`]: gone(), [`orders.refused.${key}`]: whole({ why, round: combat.round, at: Date.now() }) });
      const lead = sceneOf(combat).tokens.get(p.from); if (!lead) { await refuse("its leader is gone"); continue; }
      if (p.round !== combat.round) { await refuse("the round moved on before it was given"); continue; }
      if (!await ensureScene(combat)) { await refuse(cantOpen()); continue; }
      await booked(async () => { try {   /* labels are given out one writer at a time (as for the notebooks); the queue swallows an error, so it is caught here and told to the box */
        await packetsDone();
        const { labels, fresh } = labelsFor(combat, lead), target = p.targetId ? sceneOf(combat).tokens.get(p.targetId) : null;
        if (p.targetId && !target) return refuse("that creature is gone");
        if (target && !(turns(combat).memory?.[lead.id]?.[target.id]?.round === combat.round) && !target.actor?.isAllyOf?.(lead.actor)) return refuse(`${lead.name} doesn't perceive that creature this round`);
        if (target && !labels[target.id]) { const f = assignLabels(labels, [target.id], target.actor?.isAllyOf?.(lead.actor) ? "M" : "E"); Object.assign(fresh, f); Object.assign(labels, f); }
        let text = ""; if (p.text) { const g = orderGate(combat, lead, p.text, labels), bad = noteRefusal(g, lead.name, "order"); if (bad) return refuse(bad); text = g.text; }
        const c = fromPending(p, { text, target: target ? labels[target.id] : null }); if (!c.ok) return refuse(c.reason);
        if (Object.keys(fresh).length) await saveTurns(combat, Object.fromEntries(Object.entries(fresh).map(([k, v]) => [`labels.${k}`, v])));
        const out = orderOut(combat, lead, c.order, { by: "gm" }); if (!out.ok) return refuse(out.why);
        await saveTurns(combat, { ...out.change, [`orders.pending.${key}`]: gone(), [`orders.refused.${key}`]: null });
        const msg = await orderChat(combat, lead, out.entry).catch(e => { console.warn(`${ID} | order chat`, e); return null; });
        if (msg) await saveTurns(combat, { [`orders.log.${out.key}.msg`]: msg });
      } catch (e) { console.error(`${ID} | order`, e); await refuse(`something went wrong (${e.message})`).catch(() => {}); } });
    } catch (e) { console.error(`${ID} | order`, e); await saveTurns(combat, { [`orders.pending.${key}`]: gone(), [`orders.refused.${key}`]: whole({ why: e.message, round: combat.round, at: Date.now() }) }).catch(() => {}); }
    finally { pendingNow.delete(lock); }
  }
}
/** For the cards (any GM's page): what a creature's card says about orders. For the leader of a band: who would hear an order now. For a member:
    this round's order (heard, or missed and why) and how firmly it holds. Null when there is nothing to say. */
export function orderCard(combat, tokenId, order = null) {
  const tok = sceneOf(combat)?.tokens.get(tokenId), f = tok ? orderFacts(combat, tok) : null; if (!f) return null;
  const n = namer(turns(combat).labels ?? {}, Object.fromEntries(sceneOf(combat).tokens.contents.map(x => [x.id, x.name])));
  /* `order`: the order its plan still holds (a step's own `order`), so the hearers can be told apart by who has seen the creature it names */
  const lab = turns(combat).labels ?? {}, namedId = order?.target ? Object.keys(lab).find(id => lab[id] === order.target) : null;
  if (f.leads) return { leads: true, band: f.band.name, hearers: hearersOf(combat, tok, f, namedId ? [namedId] : []), langName };
  const line = roundLine(bandLog(combat).filter(e => e.band === f.band.key), tokenId, combat.round); if (!line) return null;
  return { leads: false, heard: line.heard, why: line.why ?? null, words: n.named(line.entry.words ?? ""), holds: holdWords(disciplineOf(sceneOf(combat), tok, combat), P(tok, combat)) };
}
/** The band log in the GM's words, for the History: [{ key, r, k, by, from, text, msg }]. */
export function bandLogWords(combat) {
  const scene = sceneOf(combat), names = Object.fromEntries((scene?.tokens.contents ?? []).map(x => [x.id, x.name])), n = namer(turns(combat).labels ?? {}, names), bands = new Map(bandsOf(scene).map(b => [b.key, b.name]));
  return bandLog(combat).map(e => ({ key: e.key, r: e.r, k: e.k, by: e.by ?? null, from: e.from ?? e.was ?? e.tok ?? null, msg: e.msg ?? null, text: logWords(e, { nameOf: id => names[id] ?? "a creature that is gone", named: n.named, langName, bandName: bands.get(e.band) ?? "", formsOf: id => P(scene?.tokens.get(id), combat) }) }));
}
/* ---------- speech to the party and yielding (0.29.0, monster minds release 3, tier 3c; docs/features/speech.md) ---------- */
/* On the turns flag: `speech.last.<token>` (the round it last spoke in). On the token: `yielded` ({ round, at, combat, words, lang }: it stands
   down until the GM answers), `prisoner` (its yield was accepted: out of the tracker, still on the map) and `yieldOver` ({ round, how, combat }:
   an earlier yield of this fight that ended, so it doesn't yield again). The log lines share the band log (`orders.log`). */
function speechCtx(combat, tok) {
  const a = tok.actor, over = tok.getFlag(ID, "yieldOver");
  return speechFor({ forms: P(tok, combat), party: onParty(a), cantAct: cantAct(a), langs: langsOf(a), below: isBelow(tok), round: combat.round, last: turns(combat).speech?.last?.[tok.id] ?? null, yielded: !!yieldOf(tok), over: over?.combat === combat.id ? over : null });
}
/** Names for a line players read: a creature the GM has hidden is "someone", one whose name doesn't show is "a creature". */
const playerNamer = combat => namer(turns(combat).labels ?? {}, Object.fromEntries(sceneOf(combat).tokens.contents.map(x => [x.id, x.hidden || (!x.actor?.hasPlayerOwner && unseenByParty(x)) ? "someone" : x.actor?.hasPlayerOwner ? x.name : moverName(x) === "A creature" ? "a creature" : x.name])));
/** An order in words a player may read (review 3): labels as players' names, the kind it names as "some of its band" (a kind's name can be a
    hidden creature's), and nothing at all for an order in the GM's own words. */
function playerWords(combat, lead, entry) {
  if (!entry?.o || entry.o.text) return null;
  const kind = entry.o.job ? orderFacts(combat, lead)?.groups.find(g => g.id === entry.o.job)?.name ?? "" : "";
  const words = kind ? String(entry.words ?? "").replace(`the job of ${kind} now`, "the job of some of its band now") : String(entry.words ?? "");
  return entry.o.job && !words.includes("some of its band") ? null : playerNamer(combat).named(words);
}
/** Is the speaker out of the party's sight: hidden by the GM, or hidden from or undetected by every player's character on the map (review 10)? */
function unseenByParty(tok) {
  if (tok.hidden) return true;
  const pcs = tok.parent.tokens.contents.filter(t => !t.hidden && t.actor?.isOfType?.("character") && t.actor.hasPlayerOwner); if (!pcs.length) return false;
  const from = new Set(hiddenFromWho(tok).map(t => t.id)); return pcs.every(p => from.has(p.id));
}
/** The languages of the characters this user owns: those in a fight that is going, else the user's own character. Read only in that player's
    browser, to choose what a line shows (R3-4); it never goes to a thinker. */
function myLanguages() {
  const mine = game.combats.filter(c => c.started).flatMap(c => c.combatants.contents).map(c => c.actor).filter(a => a?.isOfType?.("character") && a.testUserPermission?.(game.user, "OWNER"));
  const list = mine.length ? mine : [game.user.character].filter(Boolean);
  return [...new Set(list)].map(a => langsOf(a));
}
/** How many of the party's characters in the fight understand a language, for the GM's line: [n, m], or null with no fight on that scene. */
function partyUnderstands(sceneId, lang) {
  const combat = fightOn(sceneId); if (!combat) return null;
  const party = [...new Set(combat.combatants.contents.map(c => c.actor).filter(a => a?.isOfType?.("character") && a.alliance === "party"))];
  return [party.filter(a => langsOf(a).includes(lang)).length, party.length];
}
/** The line in chat (R3-7, R3-4): one public message. It stores what a player who doesn't know the language reads; each browser's render hook
    shows the words to a GM and to a player whose character knows the language (`onRenderSay`). A monster the GM has hidden speaks as "A voice"
    (Rhea, 2026-11-11). Out: the message's id, or null when there is nothing a player may see (a hidden monster yielding without words). */
async function sayChat(combat, tok, flag) {
  const content = sayHtml(flag, {}, P(tok, combat)); if (!content) return null;
  const speaker = flag.voice ? { scene: sceneOf(combat).id, actor: null, token: null, alias: "A voice" } : ChatMessage.implementation.getSpeaker({ token: tok });
  const m = await ChatMessage.implementation.create({ speaker, whisper: [], blind: false, content, flags: { [ID]: { say: flag } } });
  return m?.id ?? null;
}
/** A spoken line as this browser shows it: a GM reads the words, who and how many of the party understood; a player reads the words when a
    character of theirs knows the language. */
export function onRenderSay(message, html) {
  const s = message.getFlag?.(ID, "say"); if (!s || !message.author?.isGM) return;
  const body = html.querySelector?.(".message-content"); if (!body) return;
  if (game.user.isGM) body.innerHTML = sayHtml(s, { gm: true, understood: s.lang ? partyUnderstands(message.speaker?.scene, s.lang) : null }, P(game.scenes.get(message.speaker?.scene)?.tokens.get(message.speaker?.token)));
  else if (understands(myLanguages(), s.lang)) body.innerHTML = sayHtml(s, { knows: true }, P(game.scenes.get(message.speaker?.scene)?.tokens.get(message.speaker?.token)));
}
/** The `say` step: speech, so no roll. The step's record and the round's sentence are one write; a yield then marks the token (written again
    after a reload that fell between the two) and the turn ends. */
async function runSay(combat, id, i, step, tok) {
  const rec = request(combat, id).log?.[i] ?? {}, isYield = step.intent === "yield", mark = () => tok.setFlag(ID, "yielded", { round: combat.round, at: Date.now(), combat: combat.id, words: step.say ?? null, lang: rec.lang ?? null });
  if (rec.skipped) return "next";
  if (rec.said) { if (isYield && rec.yielded && !yieldOf(tok) && tok.getFlag(ID, "yieldOver")?.combat !== combat.id && !prisonerOf(tok)) await mark(); return isYield && rec.yielded ? "yielded" : "next"; }
  if (!stepGate("say", id)) return "stopped";
  const ctx = speechCtx(combat, tok), why = isYield ? (ctx.yield.ok ? null : ctx.yield.why) : (ctx.say.ok ? null : ctx.say.why);
  if (why) { await save(combat, id, { log: { [i]: { skipped: why } }, note: joinNote(combat, id, `${tok.name} ${isYield ? "didn't yield" : "said nothing"}: ${why}.`) }); return "next"; }
  const words = ctx.say.ok ? step.say ?? "" : "", lang = words ? speechLanguage(langsOf(tok.actor)) : null;
  const gesture = isYield ? gestureWords({ armed: heldItems(tok.actor).length > 0, forms: P(tok, combat) }) : null;
  await saveTurns(combat, { [`requests.${id}.log.${i}`]: { said: true, ...(lang ? { lang, langName: langName(lang) } : {}), ...(isYield ? { yielded: true } : {}) }, ...(words ? { [`speech.last.${tok.id}`]: combat.round } : {}), [`requests.${id}.since`]: clock() });
  if (isYield) await tok.setFlag(ID, "yielded", { round: combat.round, at: Date.now(), combat: combat.id, words: words || null, lang });
  const msg = await sayChat(combat, tok, { words, lang, langName: lang ? langName(lang) : null, intent: step.intent, gesture, voice: unseenByParty(tok), who: tok.name }).catch(e => { console.warn(`${ID} | say chat`, e); return null; });
  if (msg) await save(combat, id, { log: { [i]: { message: msg } } });
  return isYield ? "yielded" : "next";
}
/** A yielded monster's turn (design review 3): the module passes it. One request says so, for the card and the History; nothing is asked of the
    thinker. The turn then ends by itself, Auto or not (her sample: "its turns pass on their own"). */
async function passTurn(combat, combatant, tok, why = "yielded") {
  const round = combat.round, key = `${combat.id}.${round}.${combatant.id}`; if (starting.has(key)) return;
  const still = () => why === "command" ? commandPasses(combat, tok) : !!yieldOf(tok);   /* 0.30.0: an animal whose handler's command failed does nothing too */
  const had = Object.entries(turns(combat).requests).filter(([, r]) => !r.reaction && r.combatantId === combatant.id && r.round === round && !r.delayed);
  /* this turn is already passing, or is the one it yielded on: the timer lives on this page only, so a reload starts it again (review 5) */
  if (had.length) { const p = had.find(([, r]) => (r.passed || r.yielded) && r.state === "done"); if (p) passAfter(combat, p[0]);
    /* she played this turn and yielded from her box (0.32.0, review 4): the runner's timer died with a reload, so the turn is ended here */
    else if (why === "yielded" && bandLog(combat).some(e => e.k === "gave" && e.tok === tok.id && e.r === round)) endYieldTurn(combat, tok, combatant.id, round);
    return; }
  starting.add(key); let again = false;
  try {
    const settled = await settle(combat, combatant);   /* its start-of-turn effects first, as for any turn */
    if (combat.combatant?.id !== combatant.id || combat.round !== round) return;
    if (!still()) { again = true; return; }   /* its yield ended while this waited (review 4): the turn is asked for after all */
    const id = foundry.utils.randomID(8), c = why === "command" ? turns(combat).commands?.[tok.id] : null, by = c ? sceneOf(combat).tokens.get(c.by)?.name ?? "its handler" : "";
    await save(combat, id, { state: "done", passed: why, combatantId: combatant.id, tokenId: tok.id, round, turn: combat.turn, at: Date.now(), settled, log: {}, labels: {}, steps: [], pos: 0, note: why === "command" ? `${tok.name}: {their} handler's command failed (${by}, Nature ${c?.total} vs Will DC ${c?.dc}); {they} {does|do} nothing this turn (turn passed).` : `${tok.name} has yielded and stands down: {their} turn passes. Accepted or Fight on is yours to press on {their} row.` });
    passAfter(combat, id);
  } finally { starting.delete(key); if (again) onTurnChange(combat).catch(e => console.error(`${ID} | turn`, e)); }
}
/** End a stood-down monster's turn, END_MS after it began to pass, once the game is unpaused, if it is still its turn and it still stands down. */
function passAfter(combat, requestId) {
  const r = request(combat, requestId), tok = sceneOf(combat)?.tokens.get(r?.tokenId), key = `${combat.id}.${r?.round}.${r?.combatantId}`;
  if (!r || !tok || ending.has(key)) return;
  ending.add(key);
  setTimeout(async () => {
    try {
      while (game.paused) await new Promise(r => setTimeout(r, 300));
      if (!combat.started || combat.round !== r.round || combat.combatant?.id !== r.combatantId || currentRequest(combat) || !(r.passed === "command" ? commandPasses(combat, tok) : yieldOf(tok))) return;
      await combat.nextTurn();
    } catch (e) { console.error(`${ID} | passing the turn`, e); } finally { ending.delete(key); }
  }, END_MS);
}
const speechLog = (combat, entry) => ({ [`orders.log.${lineKey(Date.now(), 0, foundry.utils.randomID(3))}`]: { r: combat.round, at: Date.now(), ...entry } });
/** Its open requests, closed with a note (as Let it get away closes the one that fled). */
function closeRequests(combat, tokenId, note) {
  const change = {}; for (const [id, r] of Object.entries(turns(combat).requests ?? {})) if (r?.tokenId === tokenId && r.state !== "done") { change[`requests.${id}.state`] = "done"; change[`requests.${id}.go`] = false; change[`requests.${id}.note`] = [r.note, note].filter(Boolean).join(" "); }
  return change;
}
/** Accepted (Rhea, R3-7): the monster is a prisoner. It leaves the tracker and stays on the map, shown, with its HP and conditions; nothing is
    deleted but its combatant. Any GM may press it. */
export async function acceptYield(combat, tokenId) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const tok = sceneOf(combat)?.tokens.get(tokenId), y = tok ? yieldOf(tok) : null; if (!tok) throw new Error("Its token is gone.");
  if (prisonerOf(tok)) throw new Error("Already done."); if (!y) throw new Error("That monster hasn't yielded.");
  const combatant = combat.combatants.find(c => c.tokenId === tok.id), at = Date.now();
  /* the token first; cut off after it, the monster still reads as yielded (a prisoner in the tracker) and Accepted finishes the rest (review 1) */
  await tok.update({ [`flags.${ID}.-=yielded`]: null, [`flags.${ID}.prisoner`]: { round: combat.round, at, combat: combat.id, yielded: y.round, words: y.words ?? null, lang: y.lang ?? null } });
  await saveTurns(combat, { ...closeRequests(combat, tok.id, pro(`${tok.name}'s yield was accepted: {they} {is|are} a prisoner, out of the fight.`, P(tok, combat))), ...speechLog(combat, { k: "accepted", tok: tok.id }) });
  /* deleting the current combatant hands the turn on by itself (core, 14.370): never nextTurn first. Another GM's press may have deleted it already. */
  if (combatant && combat.combatants.has(combatant.id)) await combat.deleteEmbeddedDocuments("Combatant", [combatant.id]).catch(e => { if (combat.combatants.has(combatant.id)) throw e; });
  return { name: tok.name };
}
/** A yield ends without a prisoner: "refused" (Fight on: the party refuses), "own" (Play it myself: the GM plays it, and its Angel tick goes),
    "struck" (an enemy's blow after it yielded; the runner's own call). It goes back to its own mind and doesn't yield again in this fight. */
async function endYield(combat, tok, how, by = null) {
  if (!yieldOf(tok)) return false;
  await tok.update({ [`flags.${ID}.-=yielded`]: null, [`flags.${ID}.-=prisoner`]: null, [`flags.${ID}.yieldOver`]: { round: combat.round, how, combat: combat.id }, ...(how === "own" ? { [`flags.${ID}.run`]: false, [`flags.${ID}.auto`]: false } : {}) });
  /* ended on the very turn it yielded (review 6): that turn's plan is over and nothing passes it now, so the card says who ends it */
  const mine = Object.entries(turns(combat).requests ?? {}).find(([, r]) => r?.yielded && r.tokenId === tok.id && r.round === combat.round && combat.combatant?.tokenId === tok.id);
  await saveTurns(combat, { ...speechLog(combat, { k: how === "refused" ? "fighton" : how, tok: tok.id, ...(by ? { by } : {}) }), ...(mine ? { [`requests.${mine[0]}.note`]: [mine[1].note, `{Their} yield ended on the turn it was made: this turn is over (end it yourself), and {they} {acts|act} again on {their} next turn.`].filter(Boolean).join(" ") } : {}) });
  return true;
}
export async function refuseYield(combat, tokenId, { own = false } = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const tok = sceneOf(combat)?.tokens.get(tokenId); if (!tok) throw new Error("Its token is gone.");
  if (!await endYield(combat, tok, own ? "own" : "refused")) throw new Error("That monster hasn't yielded.");
  return { name: tok.name };
}
/** Back in the fight: a prisoner joins again where it stands and rolls initiative, as a monster brought back does. */
export async function backInFight(combat, tokenId) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const tok = sceneOf(combat)?.tokens.get(tokenId); if (!tok || !prisonerOf(tok)) throw new Error("That monster isn't a prisoner of this fight.");
  if (combat.combatants.some(c => c.tokenId === tok.id)) throw new Error("It is already in the fight.");
  /* the combatant first (review 7): cut off after it, the monster reads as yielded with its buttons, never as nothing at all */
  const [c] = await combat.createEmbeddedDocuments("Combatant", [{ tokenId: tok.id, actorId: tok.actorId, sceneId: sceneOf(combat).id }]);
  await tok.update({ [`flags.${ID}.-=prisoner`]: null, [`flags.${ID}.yieldOver`]: { round: combat.round, how: "back", combat: combat.id } });
  if (c) await combat.rollInitiative([c.id], { skipDialog: true });
  await saveTurns(combat, speechLog(combat, { k: "back", tok: tok.id }));
  return { name: tok.name, initiative: c?.initiative ?? null };
}
/* ---------- her Speak / Yield box (0.32.0; Rhea's q-19, samples approved 2026-11-12: "That looks ok") ---------- */
/* On the card of a monster she plays herself: one sentence to the party, shown by languages as Angel's are, or Yield (it stands down with Accepted
   and Fight on, the same as a yield Angel plans). Her press waits on the turns flag (`speech.pending.<token>`) for the runner, as her Give orders
   box does, so the line, the yield, the allies' notebooks and the end of the turn are done on the page that does them for Angel's monsters. */
const speakingNow = new Set();
/** The box, on any GM's page: null when there is no box (no fight, not its turn, a creature Angel runs, the party's side, one that stands down).
    Out: { id, name, can: { say, yield }, langs: [{ slug, name }], lang, party: [{ name, langs }], voice, pending, refused, last }. */
export function speakPreview(combat, tokenId) {
  const tok = sceneOf(combat)?.tokens.get(tokenId); if (!tok || !combat.started || combat.combatant?.tokenId !== tok.id || !runnable(tok)) return null;
  if (onParty(tok.actor) || partyMember(tok.actor) || yieldOf(tok)) return null;
  if (tok.getFlag(ID, "run") && !tookTurn(turns(combat).requests, combat.round, combat.combatant?.id)) return null;   /* Angel's, until she takes the turn with Play it myself */
  const ctx = speechCtx(combat, tok), langs = langsOf(tok.actor), sp = turns(combat).speech ?? {};
  const party = [...new Set(combat.combatants.contents.map(c => c.actor).filter(a => a?.isOfType?.("character") && a.alliance === "party"))].map(a => ({ name: a.name, langs: langsOf(a) }));
  const last = bandLog(combat).filter(e => (e.k === "said" || e.k === "gave") && e.tok === tok.id && e.r === combat.round).at(-1) ?? null;
  const refused = sp.refused?.[tok.id]?.round === combat.round ? sp.refused[tok.id].why ?? null : null;
  return { id: tok.id, name: tok.name, can: ctx, langs: langs.map(slug => ({ slug, name: langName(slug) })), lang: speechLanguage(langs), party, voice: unseenByParty(tok), pending: !!sp.pending?.[tok.id], refused, last,
    sign: gestureWords({ armed: heldItems(tok.actor).length > 0, forms: P(tok, combat) }) };
}
/** Her press: Speak (words, lang) or Yield (words optional). Checked here so the box answers at once; the runner checks again when it says it. */
export async function gmSpeak(combat, tokenId, { words = "", lang = null, yield: gives = false } = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const p = speakPreview(combat, tokenId); if (!p) throw new Error("That creature can't speak through this box now.");
  const tok = sceneOf(combat).tokens.get(tokenId), forms = P(tok, combat), gate = gives ? p.can.yield : p.can.say;
  if (!gate.ok) throw new Error(`${tok.name} can't ${gives ? "yield" : "speak"} now: ${gate.why}.`);
  const c = cleanGmSay({ words: gives && !p.can.say.ok ? "" : words, lang, yield: gives }, langsOf(tok.actor), forms); if (!c.ok) throw new Error(c.why);
  if (p.pending) throw new Error("A line is already waiting to be said.");   /* review 5: a second press would wipe out the first */
  const away = runnerProblem(); if (away) throw new Error(away);   /* nobody to say it: told now, as for her orders */
  await saveTurns(combat, { [`speech.pending.${tok.id}`]: whole({ words: c.words, lang: c.lang, yield: !!gives, round: combat.round, ts: Date.now() }), [`speech.refused.${tok.id}`]: gone() });
}
/** Her press taken back while it waits for the runner (review 6: a runner that went away left the box with no buttons). */
export async function cancelSpeak(combat, tokenId) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  await saveTurns(combat, { [`speech.pending.${tokenId}`]: gone() });
}
/** The runner says her line: the round's sentence and the log line in one write, the token marked for a yield, the chat line, the allies'
    notebooks for a yield, and a yield ends the turn (waiting out the game's pause). A refusal is written where the box shows it. */
async function runSpeech(combat) {
  if (!isRunner()) return;
  for (const [tokenId, p] of Object.entries(turns(combat).speech?.pending ?? {})) {
    const lock = `${combat.id}.${tokenId}`; if (!p || speakingNow.has(lock)) continue; speakingNow.add(lock);
    const refuse = why => saveTurns(combat, { [`speech.pending.${tokenId}`]: gone(), [`speech.refused.${tokenId}`]: whole({ why, round: combat.round, at: Date.now() }) });
    try {
      const tok = sceneOf(combat).tokens.get(tokenId); if (!tok) { await refuse("its token is gone"); continue; }
      if (p.round !== combat.round || combat.combatant?.tokenId !== tok.id) { await refuse("the turn moved on before it was said"); continue; }
      const cid = combat.combatant.id;   /* whose turn a yield ends: read before anything waits (review 1) */
      /* a yield cut off after its token mark (a reload): this press marked it, so it carries on from there (review 3) */
      const y0 = tok.getFlag(ID, "yielded"), resumed = p.yield && yieldOf(tok)?.combat === combat.id && y0?.round === p.round && (y0?.at ?? 0) >= (p.ts ?? Infinity) - 30000;   /* p.ts is the pressing page's clock, y0.at the runner's: 30 s of leeway (0.33.1, review); her box can't press over a yield already standing */
      const ctx = speechCtx(combat, tok), gate = p.yield ? ctx.yield : ctx.say; if (!gate.ok && !resumed) { await refuse(gate.why); continue; }
      if (!await ensureScene(combat)) { await refuse(cantOpen()); continue; }
      const words = p.words && (ctx.say.ok || resumed) ? String(p.words) : "", lang = words ? (langsOf(tok.actor).includes(p.lang) ? p.lang : speechLanguage(langsOf(tok.actor))) : null, ln = lang ? langName(lang) : null;
      /* giving itself up shows it, as a planned yield does (0.29.0 review 10); speaking keeps it hidden */
      let shown = ""; if (p.yield && !resumed) shown = await showYielder(combat, tok).catch(e => { console.warn(`${ID} | out of hiding`, e); return ""; });
      /* the token first: cut off after it, the press is still waiting and `resumed` finishes it; the other way round left a logged yield that wasn't one */
      if (p.yield && !resumed) await tok.setFlag(ID, "yielded", { round: combat.round, at: Date.now(), combat: combat.id, words: words || null, lang });
      const key = lineKey(Date.now(), 0, foundry.utils.randomID(3)), entry = { r: combat.round, at: Date.now(), k: p.yield ? "gave" : "said", tok: tok.id, by: "gm", ...(words ? { words } : {}), ...(lang ? { lang, langName: ln } : {}), ...(shown ? { shown } : {}) };
      await saveTurns(combat, { [`orders.log.${key}`]: entry, ...(words ? { [`speech.last.${tok.id}`]: combat.round } : {}), [`speech.pending.${tokenId}`]: gone(), [`speech.refused.${tokenId}`]: gone() });
      if (p.yield) noteEvent(combat, { kind: "deed", pre: "gave itself up", hasTarget: false }, tok);
      const gesture = p.yield ? gestureWords({ armed: heldItems(tok.actor).length > 0, forms: P(tok, combat) }) : null;
      const msg = await sayChat(combat, tok, { words, lang, langName: ln, intent: p.yield ? "yield" : "gm", gesture, voice: unseenByParty(tok), who: tok.name }).catch(e => { console.warn(`${ID} | say chat`, e); return null; });
      if (msg) await saveTurns(combat, { [`orders.log.${key}.msg`]: msg });
      if (p.yield) endYieldTurn(combat, tok, cid);
    } catch (e) { console.error(`${ID} | speech`, e); await refuse(`something went wrong (${e.message})`).catch(() => {}); }
    finally { speakingNow.delete(lock); }
  }
}
/** A yield from her box brings it out of hiding (Visioner), as any action but Hide, Sneak or Step does; out: a line for her, or "". */
async function showYielder(combat, tok) {
  if (turns(combat).stealth?.[tok.id]) await saveTurns(combat, { [`stealth.${tok.id}`]: gone() });
  const who = hiddenFromWho(tok); if (!who.length) return "";
  if (game.settings.get(VISIONER, "autoVisibilityEnabled")) return `${tok.name} ${pro("was hidden; Visioner's automatic visibility decides whether {they} still {is|are}.", P(tok, combat))}`;
  const vis = visionerApi(); for (const t of who) await vis.setVisibility(t.id, tok.id, "observed");
  return `${tok.name} was hidden from ${listWords(who.map(t => t.name))}; ${pro("giving {themself} up makes {them} observed by them.", P(tok, combat))}`;
}
/** Her Yield ends its turn ("Yield ends its turn", her sample), once the game is unpaused, if it is still its turn and it still stands down. */
function endYieldTurn(combat, tok, cid, round = combat.round) {
  const key = `${combat.id}.${round}.${cid}`; if (ending.has(key)) return; ending.add(key);   /* one end a turn, shared with passAfter */
  setTimeout(async () => {
    try { while (game.paused) await new Promise(r => setTimeout(r, 300));
      if (combat.started && combat.round === round && combat.combatant?.id === cid && combat.combatant?.tokenId === tok.id && yieldOf(tok)) await combat.nextTurn();
    } catch (e) { console.error(`${ID} | ending a yielded turn`, e); } finally { ending.delete(key); }
  }, 300);
}
/** For the window: who stands down now ([{ id, name, round, words, lang }]) and this fight's prisoners ([{ id, name, round }]). */
export function yieldedList(combat) {
  return (combat?.combatants.contents ?? []).map(c => c.token).filter(t => t && yieldOf(t)?.combat === combat.id).map(t => { const y = yieldOf(t); return { id: t.id, name: t.name, round: y.round, words: y.words ?? null, lang: y.lang ? langName(y.lang) : null }; });
}
export function prisonerList(combat) {
  return (sceneOf(combat)?.tokens.contents ?? []).filter(t => prisonerOf(t)?.combat === combat.id && !combat.combatants.some(c => c.tokenId === t.id)).map(t => ({ id: t.id, name: t.name, round: prisonerOf(t).round, at: prisonerOf(t).at })).sort((a, b) => b.at - a.at);
}
/** What a monster's allies saw it do, from a step the module carried out. Strikes and castings come from their cards; a plain move says nothing
    its allies' own packets don't (they know where it is); Hide and Sneak are secret. */
function noteDeed(combat, tok, step, rec = {}, r = null) {
  const target = step.target ? sceneOf(combat).tokens.get(r?.labels?.[step.target]) ?? null : null, to = target ? " on" : "";
  const words = step.do === "ability" ? { pre: `used ${step.itemName ?? step.item}${to}`, post: rec?.check ? ` (${CHECK_OUTCOMES[rec.check.degree] ?? "done"})` : "" }
    : step.do === "flee" ? { pre: "ran for the map's edge" } : step.do === "take-cover" ? { pre: "took cover" } : step.do === "stand" ? { pre: "stood up" } : step.do === "drop-prone" ? { pre: "dropped prone" }
    : step.do === "burrow" ? { pre: step.below ? "went below ground" : "came up out of the ground" } : step.do === "say" && step.intent === "yield" && rec?.yielded ? { pre: "gave itself up" }
    : step.do === "command-animal" && rec?.check ? { pre: "gave an animal a command", post: rec.check.degree >= 2 ? " (it obeys)" : " (it didn't take)" } : step.do === "point-out" && rec?.pointed ? { pre: "pointed out" } : null;
  if (words) noteEvent(combat, { kind: "deed", ...words, hasTarget: !!target }, tok, target);
}
/** The fold-out's content for one creature, on any GM's page: what is sent to the thinker, what it perceived and makes nothing of, what was crossed out. */
export function notebookOf(combat, tokenId) {
  const tok = sceneOf(combat)?.tokens.get(tokenId); if (!tok?.actor || !keepsBook(tok)) return null;
  const minded = mindOf(sceneOf(combat), tok, combat), rung = rungOf(minded.mind?.pick?.mind), r = render(books(combat)[tokenId], { rung, since: deedsSince(combat, tokenId), forms: P(tok, combat) });
  /* a creature with no Discipline is sent nothing of its allies or its side (0.26.0): the fold-out shows what is sent */
  const shares = onParty(tok.actor) || (minded.assembled.lines.discipline?.pick ?? "loose") !== "none";
  return { ...r, allies: shares ? r.allies : [], rung, mind: RUNGS[rung], side: rung > 0 && shares ? sideWords(sideOf(combat, tok), P(tok, combat)) : null };
}
/** Who a GM's notebook line can name: as for a note to Angel (`notePeople`), with a label for every creature this monster has perceived at some
    point in the fight (its last-seen memory, kept for every monster) or knows as an ally (review 5: gated once, at save). */
function bookPeople(combat, tok) {
  const t = turns(combat), labels = t.labels ?? {}, ids = [...Object.keys(t.memory?.[tok.id] ?? {}), ...knownAllies(sceneOf(combat), tok).map(a => a.id)];
  return notePeople(combat, { tokenId: tok.id, labels: Object.fromEntries(ids.filter(id => labels[id]).map(id => [labels[id], id])), packet: { you: { label: labels[tok.id] ?? "it" }, allies: [] } });
}
/** The line as it would be stored, for the fold-out to show before saving: { text, unknown, ambiguous }. */
export function previewRemember(combat, tokenId, text) { const tok = sceneOf(combat)?.tokens.get(tokenId); return tok ? noteForThinker(text, bookPeople(combat, tok), GM_LINE_MAX) : { text: "", unknown: [], ambiguous: [] }; }
/* her edit reaches a monster in the middle of its turn: the rest is thought through again once no step is running (review 4) */
async function touchTurn(combat, tokenId) { const r = currentRequest(combat); if (r?.tokenId === tokenId && Array.isArray(r.steps) && [...RESUMABLE].includes(r.state) && (r.pos ?? 0) < r.steps.length) await save(combat, r.id, { nbEdit: Date.now() }); }
/** The GM adds a line of her own to a monster's notebook, in a few words. A party member's name becomes its label here, once (refused in words
    when the monster has never perceived that creature); what is stored holds labels only. Angel never changes or removes it. */
export async function rememberAdd(combat, tokenId, text) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const tok = sceneOf(combat)?.tokens.get(tokenId); if (!tok || !keepsBook(tok)) throw new Error("That creature keeps no notebook.");
  const conv = previewRemember(combat, tokenId, text); if (!conv.text) throw new Error("Write the line first.");
  const bad = noteRefusal(conv, tok.name); if (bad) throw new Error(bad);
  const key = lineKey(Date.now(), 0, foundry.utils.randomID(3));
  await combat.update({ [`flags.${ID}.notebook.${tokenId}.${key}`]: gmLine(conv.text, { round: combat.round, at: Date.now() }) }, { render: false, [ID]: { quiet: true } });
  await touchTurn(combat, tokenId); return key;
}
/** The GM crosses lines out (or puts them back): a field on each line, so the runner's writes and hers never collide (review 7). */
export async function rememberCross(combat, tokenId, keys, on = true) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const book = books(combat)[tokenId] ?? {}, list = (Array.isArray(keys) ? keys : [keys]).filter(k => book[k]); if (!list.length) return 0;
  await combat.update(Object.fromEntries(list.map(k => [`flags.${ID}.notebook.${tokenId}.${k}.x`, on ? true : null])), { render: false, [ID]: { quiet: true } });
  await touchTurn(combat, tokenId); return list.length;
}
/** Her notebook edit, with a plan waiting: the rest of the turn is planned again. Not one of the turn's re-plans, and the new plan waits for Do it. */
const canRethink = (combat, r, i, tok) => actionsOf(tok.actor, combat) - ((r.spent ?? 0) + spentBy((r.steps ?? []).slice(0, i)).actions) > 0;   /* with no actions left a re-plan would end the turn (review 5): the plan in hand goes on */
async function rethinkGm(combat, requestId, i, tok) {
  if (!canRethink(combat, request(combat, requestId), i, tok)) return;
  await replan(combat, { ...request(combat, requestId), id: requestId }, i, [{ who: "gm", what: "notebook" }], tok, { counted: false });
  const next = request(combat, requestId)?.replanned; if (next) await save(combat, next, { gmWait: true });
}
async function runRemember(combat, requestId) {
  if (!isRunner() || running.has(requestId)) return;
  running.add(requestId);
  try {
    const r = request(combat, requestId); if (!r?.nbEdit || !CHANGEABLE.includes(r.state)) return;
    const tok = sceneOf(combat).tokens.get(r.tokenId);
    await save(combat, requestId, { nbEdit: null });
    if (!tok || changeProblem({ ...r, go: false }) || !await ensureScene(combat)) return;   /* a step already begun is finished by hand, as for a Change */
    await rethinkGm(combat, requestId, r.pos ?? 0, tok);
  } finally { running.delete(requestId); }
}

/* ---------- Command an Animal (0.30.0, monster minds release 3, tier 3d; docs/features/command-animal.md) ---------- */
/* On the turns flag: `commands.<animal token>` = { by (the handler's token), round, at, instruction, foe?, to?, degree, total, dc, used: { round }
   (stamped when the animal's next turn begins), own (the GM took a failed turn), angel (the GM let Angel plan a critical failure) }. One at a
   time an animal; the runner is the only writer of all but `own` and `angel`. */
const traitsOf = actor => [...(actor?.traits ?? actor?.system?.traits?.value ?? [])];
/** For the plan check: each ally it could name, by label, with whether it can be commanded and why not; and whether the handler is deafened. */
function commandCtx(combat, tok) {
  const scene = sceneOf(combat), labels = turns(combat).labels ?? {}, cmds = turns(combat).commands ?? {}, animals = {}, below = isBelow(tok);
  for (const a of knownAllies(scene, tok)) { const l = labels[a.id]; if (!l) continue; const act = a.actor, c = cmds[a.id];
    animals[l] = { name: l, pro: P(a, combat), ...canCommand({ handlerBelow: below, forms: P(tok, combat), animal: { pro: P(a, combat), ally: true, played: runnable(a), inFight: combat.combatants.some(c => c.tokenId === a.id && !c.defeated), traits: traitsOf(act), fallen: !!fallenWord(a), yielded: stoodDown(a), asleep: !!act?.hasCondition?.("unconscious"), deafened: !!act?.hasCondition?.("deafened"), below: isBelow(a),
      path: tok.object && a.object && onFightScene(combat) ? !soundBlocked(tok.object.center, a.object.center) : null, pending: !!c && !c.used } }) }; }
  if (labels[tok.id]) animals[labels[tok.id]] = { name: labels[tok.id], ...canCommand({ animal: { self: true }, forms: P(tok, combat) }) };
  return { animals, deafened: !!tok.actor?.hasCondition?.("deafened") };
}
/** The command in force for this creature's turn as things stand, or null. */
function commandNow(combat, tok) { const c = turns(combat).commands?.[tok.id] ?? null; return c && commandInForce(c, combat.round) && c.used ? c : null; }
/** Does a failed command still pass this animal's turn (it wasn't taken with Play it myself)? */
function commandPasses(combat, tok) { const c = commandNow(combat, tok); return !!c && outcomeOf(c.degree) === "nothing" && !c.own; }
/** At the start of the animal's turn (the runner): a command it hasn't acted on is stamped for this turn; one whose turn has gone is taken
    away. Out: the command in force, or null. */
async function commandAtTurn(combat, tok) {
  const c = turns(combat).commands?.[tok.id] ?? null; if (!c) return null;
  if (commandSpent(c, combat.round)) { await saveTurns(combat, { [`commands.${tok.id}`]: gone() }); return null; }
  if (!c.used) await saveTurns(combat, { [`commands.${tok.id}.used`]: { round: combat.round } });
  return commandNow(combat, tok);
}
/** The `command-animal` step: a deafened handler's DC 5 flat check, then a real, public Nature check against the animal's Will DC (as Arrest a
    Fall rolls an NPC's check). The result and the animal's command are one write, so a reload can't keep one without the other. */
async function runCommand(combat, id, i, step, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {};
  const aid = tokenIdOf(combat, request(combat, id), step.target), animal = aid ? sceneOf(combat).tokens.get(aid) : null;
  for (let guard = 0; guard < 4; guard++) {
    const now = nextCommand(get(), { flat: step.flat ?? 0 });
    if (now === "next" || now === "ask") return now;
    if (!stepGate(now, id)) return "stopped";
    /* as things stand now: the animal may have fallen, gone out of earshot or been commanded by another since the plan was checked */
    const can = animal?.actor ? commandCtx(combat, tok).animals[step.target] ?? { ok: false, why: pro("{they2} {is|are|2} no longer one of {their} allies", P(tok, combat), P(animal, combat)) } : { ok: false, why: "the animal is gone" };
    if (!can.ok) { await save(combat, id, { log: { [i]: { skipped: can.why } }, note: joinNote(combat, id, `${tok.name} gave ${animal?.name ?? "the animal"} no command: ${can.why}. The action is spent.`) }); return "next"; }
    pending = { tokenId: tok.id, waiters: new Map() };
    try {
      if (now === "flat") {
        await record({ flatStarted: true });
        const roll = await watched(async () => { const r = await new Roll("1d20").evaluate(); await r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Flat check, DC ${step.flat} (deafened, an auditory action)` }); return r; });
        await record({ flat: { dc: step.flat, total: roll.total, ok: roll.total >= step.flat } });
        if (roll.total < step.flat) await addNote(combat, id, `{Their} Command an Animal failed {their} DC ${step.flat} flat check (${roll.total}): {they} {is|are} deafened. The action is spent.`);
      } else if (now === "check") {
        const stat = tok.actor.skills?.nature; if (!stat) throw new Error(`${tok.name} has no Nature skill to roll.`);
        const will = animal.actor.saves?.will, dc = will?.dc?.value ?? 10 + (will?.mod ?? 0);
        await record({ started: true });
        const card = waitForAny(["skill-check", "check"]);
        const roll = await watched(() => stat.roll({ dc: { value: dc }, skipDialog: true, label: `Command an Animal: Nature check${animal.hidden || moverName(animal) === "A creature" ? "" : ` (${esc(animal.name)})`}`, extraRollOptions: ["action:command-an-animal"], traits: ["auditory", "concentrate"], token: tok, rollMode: "publicroll" }));
        if (!roll) throw new Error("The Nature check didn't roll.");
        const message = await Promise.race([card, sleep(1500).then(() => null)]).catch(() => null);
        const die = roll.dice?.[0]?.total ?? null, degree = Number.isInteger(roll.degreeOfSuccess) ? roll.degreeOfSuccess : degreeOf(roll.total, dc, die);
        const cmd = { by: tok.id, round: combat.round, at: Date.now(), instruction: step.instruction, ...(step.foe ? { foe: step.foe } : {}), ...(step.to ? { to: step.to } : {}), degree, total: roll.total, dc };
        /* the result also goes on the request's note (0.30.0 live test: a plan whose last step was the command left nothing on the card once the
           turn was done); the card turns its labels into names, and a note never goes to the thinker */
        await saveTurns(combat, { [`requests.${id}.log.${i}.check`]: { degree, total: roll.total, die, dc, message: message?.id ?? null }, [`requests.${id}.log.${i}.words`]: step.words, [`commands.${animal.id}`]: whole(cmd), [`requests.${id}.since`]: clock(),
          [`requests.${id}.note`]: joinNote(combat, id, `Command an Animal: ${resultWords({ check: { degree, total: roll.total, die, dc }, words: step.words }, step.target, { forms: P(tok, combat), animalForms: P(animal, combat) })}`) });
      }
    } finally { pending = null; }
  }
  return "ask";
}
/** For any GM's page: the commands in force, for the rows' tags and the animal's card. [{ id, name, by, tag: { kind, text }, degree, own, angel,
    isTurn, words, total, dc }], names in place of labels. */
export function commandList(combat) {
  const scene = sceneOf(combat), cmds = turns(combat).commands ?? {}, labels = turns(combat).labels ?? {}, n = namer(labels, Object.fromEntries((scene?.tokens.contents ?? []).map(x => [x.id, x.name])));
  return Object.entries(cmds).map(([id, c]) => { const tok = scene?.tokens.get(id); if (!tok || !c || !commandInForce(c, combat.round)) return null;
    if (c.used && combat.combatant?.tokenId !== id) return null;   /* its commanded turn is over (the entry itself goes when its next turn begins): no tag for the rest of the round (0.30.0 live test) */
    const isTurn = combat.combatant?.tokenId === id && c.used?.round === combat.round, tag = commandTag(c, combat.round, isTurn, P(tok, combat));
    return { id, name: tok.name, by: scene.tokens.get(c.by)?.name ?? pro("{their} handler", P(tok, combat)), tag: tag ? { ...tag, text: n.named(tag.text) } : null, degree: c.degree, own: !!c.own, angel: !!c.angel, isTurn, words: n.named(commandWords(c, P(tok, combat))), total: c.total, dc: c.dc, ticked: !!tok.getFlag(ID, "run") }; }).filter(Boolean);
}
/** The handler's result line for its card, in names. */
export function commandResult(combat, requestId, i) {
  const r = request(combat, requestId), step = r?.steps?.[i], rec = r?.log?.[i]; if (step?.do !== "command-animal" || !rec) return "";
  const labels = turns(combat).labels ?? {}, n = namer(labels, Object.fromEntries(sceneOf(combat).tokens.contents.map(x => [x.id, x.name])));
  return n.named(resultWords({ ...rec, words: step.words }, step.target, { forms: P(sceneOf(combat).tokens.get(r.tokenId), combat), animalForms: P(sceneOf(combat).tokens.get(tokenIdOf(combat, r, step.target)), combat) }));
}
/** Her answers on an animal whose handler's command failed (any GM): "own", Play it myself (the module doesn't pass the turn, or stops waiting:
    she plays it), or "angel", Let Angel plan it (only after a critical failure: Angel plans what it does instead, and its Angel tick goes on). */
export async function answerCommand(combat, tokenId, answer) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const tok = sceneOf(combat)?.tokens.get(tokenId), c = tok ? turns(combat).commands?.[tokenId] : null; if (!tok || !c || !commandInForce(c, combat.round)) throw new Error("That command is over.");
  if (c.own || c.angel) throw new Error("Already done.");
  if (answer === "angel") { if (outcomeOf(c.degree) !== "gm") throw new Error("Angel plans it only after a critical failure."); if (!tok.getFlag(ID, "run")) await tok.setFlag(ID, "run", true);
    await saveTurns(combat, { [`commands.${tokenId}.angel`]: true, ...speechLog(combat, { k: "commandAngel", tok: tokenId, degree: c.degree }) }); }
  else { const passed = Object.entries(turns(combat).requests ?? {}).find(([, r]) => r?.passed === "command" && r.tokenId === tokenId && r.round === combat.round);
    await saveTurns(combat, { [`commands.${tokenId}.own`]: true, ...speechLog(combat, { k: "commandOwn", tok: tokenId, degree: c.degree }), ...(passed ? { [`requests.${passed[0]}.note`]: `${tok.name}: {their} handler's command failed, and you took the turn with Play it myself: the turn is yours to play and to end.` } : {}) }); }
  return { name: tok.name };
}

/* ---------- Point Out (0.30.0, tier 3d; docs/features/point-out.md) ---------- */
/* On the turns flag: `pointed.<observer token>.<creature token>` = { square, round, by, wrong? }: where the observer believes the creature is,
   from an ally's gesture. `senser` reads it only while the observer's own senses give it no square. It ends when the creature moves
   (`dropBeliefs`), when the observer's own senses find it (`packetExtras`) or after a blow at a wrong square (`runBlindMiss`). */
/** Which of the creatures this one sees have been lost by at least one of its allies: a Set of token ids. Needs the fight on this page's canvas. */
function lostByAllies(combat, tok, others) {
  const out = new Set(), seen = (others ?? []).filter(o => SEES.includes(o.state)); if (!seen.length || !onFightScene(combat)) return out;
  const memory = turns(combat).memory ?? {};
  for (const a of alliesOf(sceneOf(combat), tok)) { if (!a.object || !runnable(a) || fellWord(a) || a.actor?.hasCondition?.("unconscious")) continue;
    const one = senser(combat, a, memory[a.id] ?? {}); for (const o of seen) if (!out.has(o.id) && o.token.object && hasLost(one(o.token).state)) out.add(o.id); }
  return out;
}
/** For the plan check: for each creature it perceives, by label, whether it can be pointed out and why not. Worked out only when asked for. */
function pointCtx(combat, tok, req, now) {
  let memo = null;
  const all = () => { if (memo) return memo; const others = [...now.values()], lost = lostByAllies(combat, tok, others), act = tok.actor; memo = {};
    for (const [label, id] of Object.entries(req.labels ?? {})) { const o = now.get(id); if (o) memo[label] = canPointOut({ state: o.state, lostBy: lost.has(id) ? 1 : 0, below: isBelow(tok), forms: P(tok, combat) }); }
    return memo; };
  return new Proxy({}, { get: (_, k) => typeof k === "string" ? all()[k] : undefined });
}
/** What each ally would get, or got, from the gesture: [{ id, name, how }] (pointout.mjs `allyGets`), and the pointer's language. */
function pointHearers(combat, tok, target) {
  const scene = sceneOf(combat), memory = turns(combat).memory ?? {}, mine = langsOf(tok.actor), list = [];
  for (const a of alliesOf(scene, tok)) { if (!a.object || !runnable(a) || fellWord(a)) continue;
    const one = senser(combat, a, memory[a.id] ?? {}), act = a.actor, me = one(tok), it = one(target);
    list.push({ id: a.id, name: a.name, pro: P(a, combat), ...(a.hidden ? { hidden: true } : {}), how: allyGets({ asleep: !!act.hasCondition?.("unconscious"), knows: canTarget(it.state), seesPointer: SEES.includes(me.state),
      hears: !act.hasCondition?.("deafened") && !isBelow(a) && !soundBlocked(tok.object.center, a.object.center), sharesLanguage: langsOf(act).some(l => mine.includes(l)) }) }); }
  return { list, lang: mine.length ? langName(speechLanguage(mine)) : null };
}
/** The `point-out` step: the grabbed flat check of a manipulate action, then the gesture. Each ally that had lost the creature gets what it
    could take from it; one that only saw the gesture rolls Perception against the creature's Stealth DC (no card: only the GM is told), and on
    a failure believes a square near the real one. The step's record and every belief are one write. */
async function runPointOut(combat, id, i, step, tok) {
  const record = change => save(combat, id, { log: { [i]: change } }), get = () => request(combat, id).log?.[i] ?? {};
  const tid = request(combat, id).labels?.[step.target], target = tid ? sceneOf(combat).tokens.get(tid) : null;
  for (let guard = 0; guard < 4; guard++) {
    const now = nextPoint(get(), { flat: step.flat ?? 0 });
    if (now === "next" || now === "ask") return now;
    if (!stepGate(now, id)) return "stopped";
    if (!target || !await ensureScene(combat) || !target.object || !tok.object) { await save(combat, id, { log: { [i]: { skipped: target ? "the map couldn't be opened" : "that creature is gone" } } }); return "next"; }
    pending = { tokenId: tok.id, waiters: new Map() };
    try {
      if (now === "flat") {
        await record({ flatStarted: true });
        const roll = await watched(async () => { const r = await new Roll("1d20").evaluate(); await r.toMessage({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), flavor: `Flat check, DC ${step.flat} (grabbed, a manipulate action)` }); return r; });
        await record({ flat: { dc: step.flat, total: roll.total, ok: roll.total >= step.flat } });
        if (roll.total < step.flat) await addNote(combat, id, `{Their} Point Out failed {their} DC ${step.flat} flat check (${roll.total}): {they} {is|are} grabbed. The action is spent.`);
      } else {
        /* as things stand now: it must still see the creature itself */
        const mine = senser(combat, tok, turns(combat).memory?.[tok.id] ?? {})(target);
        if (!SEES.includes(mine.state)) { await save(combat, id, { log: { [i]: { skipped: pro("{they} no longer {sees|see} that creature {themself}", P(tok, combat)) } }, note: joinNote(combat, id, `${tok.name} pointed nothing out: {they} no longer {sees|see} ${target.name} {themself}. The action is spent.`) }); return "next"; }
        await record({ started: true });
        const scene = sceneOf(combat), real = squareOf(target, scene), { list, lang } = pointHearers(combat, tok, target), dc = target.actor.skills?.stealth?.dc?.value ?? 10 + (target.actor.skills?.stealth?.mod ?? 0), out = [], change = {};
        /* a wrong square is never one a creature stands on (the creature's own space, the observer's, anyone's): review 9 */
        const full = new Set(scene.tokens.contents.filter(t => t.actor?.isOfType?.("creature")).flatMap(t => footprintAt(squareOf(t, scene), sizeOf(t)).map(([a, b]) => `${a},${b}`))), taken = (a, b) => full.has(`${a},${b}`);
        for (const x of list) {
          let total = null, die = null; if (x.how === "roll") { const r = await new Roll("1d20").evaluate(); die = r.total; total = r.total + (scene.tokens.get(x.id)?.actor?.perception?.mod ?? 0); }
          const res = allyResult(x.id, x.how, { real, total, die, dc, wrongAt: x.how === "roll" ? wrongSquare(real, mapSquares(scene), () => CONFIG.Dice.randomUniform(), taken) : null }); out.push(res);
          if (res.square) change[`pointed.${x.id}.${target.id}`] = whole({ square: res.square, height: heightUp(target), round: combat.round, by: tok.id, ...(res.wrong ? { wrong: true } : {}) });   /* the height as pointed out, right square or wrong: what it is told must not differ between the two (review 3) */
        }
        /* the action shows like any other: one plain public card, unless the GM has hidden the pointer (the line would give it away) */
        let message = null;
        if (!tok.hidden) message = await watched(() => ChatMessage.implementation.create({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), content: `<p><strong>Point Out</strong> <span class="action-glyph">1</span>: points ${target.hidden ? "at something" : `at ${esc(moverName(target) === "A creature" && !target.actor?.hasPlayerOwner ? "a creature" : target.name)}`} for ${pro("{their}", P(tok, combat))} allies.</p>` })).catch(e => { console.warn(`${ID} | point out card`, e); return null; });
        await saveTurns(combat, { ...change, [`requests.${id}.log.${i}.pointed`]: whole({ list: out, real, ...(lang ? { lang } : {}) }), [`requests.${id}.log.${i}.posted`]: { message: message?.id ?? null }, [`requests.${id}.since`]: clock() });
      }
    } finally { pending = null; }
  }
  return "ask";
}
/** Does this creature know that one only from a pointed-out square that is wrong? (Its own senses give it nothing, and the belief is off.) */
function wrongBelief(combat, tok, target) {
  const b = turns(combat).pointed?.[tok.id]?.[target.id]; if (!b?.wrong || !tok.object || !target.object || !onFightScene(combat)) return false;
  const o = senser(combat, tok, turns(combat).memory?.[tok.id] ?? {})(target); return !!o.pointed && !!o.wrong;
}
/** A Strike at a creature it believes is somewhere it isn't: the blow goes at the empty square. To the thinker it reads as the hidden creature's
    flat check failing, which is all it could tell; the GM's note says what happened. The belief stays, as a hidden creature stays hidden after a
    failed flat check: taking it away would tell the thinker the square was wrong (review 4). The party's reactions aren't asked: no blow reaches anyone. */
async function runBlindMiss(combat, id, i, step, tok, target) {
  const rec = request(combat, id).log?.[i] ?? {}; if (rec.flat) return "next"; if (rec.flatStarted) return "ask";
  if (!stepGate("flat", id)) return "stopped";
  const b = turns(combat).pointed?.[tok.id]?.[target.id], at = b?.square ?? [0, 0];
  await save(combat, id, { log: { [i]: { flatStarted: true } } });
  if (!tok.hidden) await ChatMessage.implementation.create({ speaker: ChatMessage.implementation.getSpeaker({ token: tok }), content: `<p><strong>${esc(step.itemName ?? "Strike")}</strong> <span class="action-glyph">1</span>: strikes at a square where ${pro("{they} {believes|believe}", P(tok, combat))} a creature is hiding. Nothing is there.</p>` }).catch(e => console.warn(`${ID} | blind miss card`, e));
  await saveTurns(combat, { [`requests.${id}.log.${i}.flat`]: { dc: 11, total: 0, ok: false, blind: true }, [`requests.${id}.note`]: joinNote(combat, id, `${tok.name} struck at square ${at[0]}, ${at[1]}, where {they} {believes|believe} ${target.name} is (a pointed-out square {they} misread): nothing was there. {They} can't tell that from a hidden creature's flat check failing, so {they} still {believes|believe} the square until ${target.name} moves or {their} own senses find ${target.name}.`), [`requests.${id}.since`]: clock() });
  return "next";
}
/** A creature moved (the runner's `moveToken`): what others believed of its square from a Point Out no longer holds. */
export function dropBeliefs(doc) {
  if (!isRunner()) return;
  for (const combat of game.combats.filter(c => c.started && sceneOf(c)?.id === doc?.parent?.id)) { const change = {};
    for (const [obs, held] of Object.entries(turns(combat).pointed ?? {})) if (held?.[doc.id]) change[`pointed.${obs}.${doc.id}`] = gone();
    if (Object.keys(change).length) saveTurns(combat, change).catch(e => console.warn(`${ID} | point out`, e)); }
}
/** For the card on any GM's page: the box under a Point Out step. Done: what each ally got (with the GM-only line for a wrong square). To come:
    what each would get, when this page has the fight's map open. Out: { title, lines: [{ name, text, gm? }] } or null. */
export function pointCard(combat, requestId, i) {
  const r = request(combat, requestId), step = r?.steps?.[i]; if (step?.do !== "point-out") return null;
  const scene = sceneOf(combat), tok = scene.tokens.get(r.tokenId), target = scene.tokens.get(r.labels?.[step.target]), rec = r.log?.[i] ?? {}; if (!tok || !target) return null;
  const nameOf = id => scene.tokens.get(id)?.name ?? "a creature";
  if (rec.pointed) return { title: pro("What {their} allies know now", P(tok, combat)), lines: pointLines((rec.pointed.list ?? []).map(x => ({ ...x, name: nameOf(x.id), pro: P(scene.tokens.get(x.id), combat) })), { target: target.name, real: rec.pointed.real, pointer: tok.name, lang: rec.pointed.lang ?? null, forms: P(tok, combat) }) };
  if (rec.skipped || Object.keys(rec).length || !onFightScene(combat) || !tok.object || !target.object) return null;
  const { list, lang } = pointHearers(combat, tok, target); return { title: pro("What {their} allies would learn", P(tok, combat)), lines: previewLines(list, { target: target.name, pointer: tok.name, lang, forms: P(tok, combat) }) };
}

/* ---------- monsters changing sides (0.30.0, tier 3d; docs/features/sides.md) ---------- */
/* The simple rule (Rhea, q-16, R3-15): the side is PF2e's, at once, for everyone. The books on the turns flag: `sides.<token>` = { side, from
   (the side it began the fight on), home (the band it began in), owned, changed? (the round it left its side) }, `leads.<band>` (who led it at
   the last look: a guessed leader leaves no mark when it goes) and `turned.<band>` = { token, round } (its leader changed sides: `settleBandsNow`
   acts on it once). Band membership itself needs no write: a creature that isn't on the monsters' side belongs to no band (bandlib `bandKeyOf`),
   and belongs to its band again when it flips back. Runner only; in the notebooks' queue, as the bands are settled there. */
export function checkSides(combat) { if (!isRunner() || !combat?.started || !sceneOf(combat)) return Promise.resolve(); return booked(() => checkSidesNow(combat).catch(e => console.error(`${ID} | sides`, e))); }
async function checkSidesNow(combat) {
  const scene = sceneOf(combat), t = turns(combat), books = t.sides ?? {}, change = {}, log = []; let flipped = false;
  for (const tok of combat.combatants.contents.map(c => c.token).filter(x => x?.actor?.isOfType?.("npc"))) {
    const was = books[tok.id] ?? null, now = { side: sideWord(tok.actor.alliance), band: bandKeyOf(scene, tok), owned: !!tok.actor.hasPlayerOwner };
    const { entry, events } = sideChange(was, now, combat.round);
    if (events.length || (was && entry.home !== was.home)) change[`sides.${tok.id}`] = whole(entry);
    for (const e of events) {
      if (e.kind === "turned") { flipped = true; log.push({ k: "side", tok: tok.id, from: e.from, to: e.to, band: e.band }); if (e.band && t.leads?.[e.band] === tok.id) change[`turned.${e.band}`] = whole({ token: tok.id, round: combat.round }); }
      else if (e.kind === "back") { flipped = true; log.push({ k: "sideBack", tok: tok.id, from: e.from, to: e.to, band: e.band }); if (e.band && t.turned?.[e.band]?.token === tok.id) change[`turned.${e.band}`] = gone(); }
      else if (e.kind === "owned") { log.push({ k: "owned", tok: tok.id }); Object.assign(change, closeRequests(combat, tok.id, pro(`${tok.name} is a player's now: the module no longer plays {them}.`, P(tok, combat)))); }
      else if (e.kind === "unowned") log.push({ k: "unowned", tok: tok.id });
    }
  }
  /* who leads each band as things stand, for the next look; not in the pass its leader turned in (the band hasn't been settled yet) */
  for (const band of bandsOf(scene)) { if (change[`turned.${band.key}`]) continue; const lead = leaderOf(scene, band, combat).tok?.id ?? null; if (lead && t.leads?.[band.key] !== lead) change[`leads.${band.key}`] = lead; }
  log.forEach((e, k) => { change[`orders.log.${lineKey(Date.now(), k % 36, foundry.utils.randomID(3))}`] = { r: combat.round, at: Date.now(), ...e }; });
  if (Object.keys(change).length) await saveTurns(combat, change);
  if (flipped) await settleBandsNow(combat);   /* already in the queue the bands are settled in: "If the leader falls" at once */
}
/** An actor's side or owners changed (the runner's `updateActor` and `updateToken`): look at the fights it is in. */
export function onSideChange(doc, change) {
  if (!isRunner()) return;
  const hit = c => !!c && (foundry.utils.hasProperty(c, "system.details.alliance") || "ownership" in c || "==ownership" in c);
  if (!(hit(change) || hit(change?.delta))) return;
  for (const combat of game.combats.filter(c => c.started)) checkSides(combat);
}
/** What a turncoat's own packet says of where it came from: that it changed sides, and the orders it last heard from its old band, as data
    (an order's own words, in labels; a label of a creature it can't name itself reads "a creature it hasn't seen"). The band's plan as the GM
    wrote it is left out: her words pass the name gate only as part of a band's packet, and it has none now. labelOf: a token id's label when
    this creature may name it. */
function turnedPacket(combat, tok, labelOf) {
  const e = turns(combat).sides?.[tok.id]; if (e?.changed == null) return null;
  const scene = sceneOf(combat), band = e.home ? bandsOf(scene).find(b => b.key === e.home) ?? null : null, heard = [], labels = turns(combat).labels ?? {};
  const mayName = l => { const id = Object.keys(labels).find(k => labels[k] === l); return !!id && labelOf(id) === l; };
  const st = ordersOf(combat).heard?.[tok.id];
  if (band && st) for (const o of [st.goal, ...Object.values(st.jobs ?? {})]) { if (!o?.o) continue;
    const w = orderWords(o.o, { fallBack: fallBackWords(planOf(scene, band, combat).fallBack) }).replace(/\b[EM]\d{1,3}\b/g, l => mayName(l) ? l : pro("a creature {they} {hasn't|haven't} seen", P(tok, combat))); if (w) heard.push(`${pro("An order {they} heard", P(tok, combat))} in round ${o.r}: ${w}`); }
  return changedForPacket(e, { bandName: band?.name ?? "", heard, forms: P(tok, combat) });
}
/** For any GM's page: each monster's side tag and card. [{ id, name, tag, party (it fights for the party now), owned, lines (the card's words,
    only in the round it changed), leaderLine }]. */
export function sideList(combat) {
  const scene = sceneOf(combat), books = turns(combat).sides ?? {}, bands = new Map(bandsOf(scene).map(b => [b.key, b]));
  return Object.entries(books).map(([id, e]) => { const tok = scene?.tokens.get(id), tag = sideTag(e); if (!tok || !tag) return null;
    return { id, name: tok.name, tag, party: tok.actor?.alliance === "party", owned: !!e.owned, changed: e.changed ?? null, lines: e.changed === combat.round ? sideCardWords(e, { bandName: bands.get(e.home)?.name ?? "", forms: P(tok, combat) }) : null }; }).filter(Boolean);
}

/* ---------- the fight-start look (monster minds release 4, 0.33.0; docs/features/look.md) ----------
   Rhea, 2026-11-10 (decisions 4 and 5): when the fight starts, Angel looks at the situation from what the monsters perceive and suggests updates to
   their minds; everything waits for her OK (Accept / Keep, Accept all / Keep all), the stored profiles in force until she answers, and what she
   accepts lasts this fight only (the fight layer, `minds` on the Combat). 2026-11-12 (R4-1): with nothing listening it waits, but only until
   round 1 ends. One a fight, on `turns.look`, with its own event kind ("look") and request id (`LOOK_ID`). */
const lookStarting = new Set();
/* packets give out labels: two built at once (the first turn and the look) could give one label to two creatures, so a look's packets and a turn's
   wait for each other (review 2 of 0.25.0 is the same trap for notebooks) */
let packetChain = Promise.resolve();
const withPackets = fn => { const p = packetChain.then(fn, fn); packetChain = p.catch(() => {}); return p; };
const lookOf = combat => turns(combat).look ?? null;
/** The runner, at every turn or round change: start the look at the fight's start; drop one still waiting once round 1 is over (R4-1). */
async function lookCheck(combat) {
  if (!isRunner() || !combat?.started) return;
  const l = lookOf(combat);
  if (!l && combat.round <= 1) return startLook(combat);
  if (l?.state === "asked" && combat.round >= 2) await saveTurns(combat, { "look.state": "missed", "look.endedAt": Date.now() });
}
/** Who the look is about: every monster Angel plays in this fight (ticked, the module's to run, on the monsters' side, alive). */
const lookTokens = combat => [...new Map(combat.combatants.map(c => c.token).filter(t => t?.actor && t.getFlag(ID, "run") && runnable(t) && !onParty(t.actor) && !t.actor.isDead).map(t => [t.id, t])).values()];
async function startLook(combat) {
  if (lookStarting.has(combat.id) || !lookTokens(combat).length) return;   /* nobody of Angel's in this fight: no look and no card */
  lookStarting.add(combat.id);
  try {
    /* the first turn's request goes first: the fight doesn't wait on the look (0.33.0 review 3). Up to 15 s for it to be asked for. */
    const t0 = Date.now(), firstAsked = () => { const cur = combat.combatant, tok = cur?.token; return !tok?.getFlag(ID, "run") || !runnable(tok) || Object.values(turns(combat).requests ?? {}).some(r => !r.reaction && r.combatantId === cur.id && r.round === combat.round); };
    await sleep(1500); while (Date.now() - t0 < 15000 && game.combats.has(combat.id) && (!firstAsked() || [...starting].some(k => k.startsWith(`${combat.id}.`)))) await sleep(500);
    if (!game.combats.has(combat.id) || lookOf(combat) || combat.round > 1) return;
    const toks = lookTokens(combat); if (!toks.length) return;
    if (fightRoute(combat) === "off") return void await saveTurns(combat, { look: whole({ state: "off", at: Date.now() }) });
    if (!await ensureScene(combat)) return void await saveTurns(combat, { look: whole({ state: "failed", at: Date.now(), reason: `${game.user.name} couldn't open the fight map` }) });
    const monsters = {}, packets = {};
    for (const tok of toks) {
      if (!tok.object) continue;
      await withPackets(async () => {
        const built = await buildPacket(combat, tok);
        await saveTurns(combat, packetExtras(combat, tok, built));   /* its labels and what it perceives now, as a turn's packet keeps them */
        const label = built.packet?.you?.label; if (!label) return;
        const k = kindFacts(tok.actor); monsters[label] = { tokenId: tok.id, name: tok.name, kind: k.key, kindName: k.kindName }; packets[label] = lookPacket(built.packet);
      });
    }
    if (!Object.keys(monsters).length || !game.combats.has(combat.id) || lookOf(combat)) return;
    const ev = eventChange("look", LOOK_ID, 0), seq = Object.values(ev)[0].seq;
    await saveTurns(combat, { look: whole({ state: "asked", seq, at: Date.now(), since: clock(), monsters, packets, tries: 0 }), ...ev });
  } catch (e) { console.error(`${ID} | look`, e); await saveTurns(combat, { look: whole({ state: "failed", at: Date.now(), reason: text(e.message, 120) }) }).catch(() => {}); }
  finally { lookStarting.delete(combat.id); }
}
/** label → kind key, for telling two suggestions about one kind apart from two about two kinds. */
const lookKinds = l => Object.fromEntries(Object.entries(l?.monsters ?? {}).map(([label, m]) => [label, m.kind ?? m.kindName ?? label]));
/** The model a look goes with: Opus when any of its monsters is thought for by Opus (`modelOf`), else Sonnet. */
function lookModel(combat, l) {
  const ms = Object.values(l.monsters ?? {}).map(m => sceneOf(combat)?.tokens.get(m.tokenId)).filter(Boolean).map(t => modelOf(t, combat));
  const opus = ms.find(m => m.model === "opus"); return opus ? { model: "opus", modelWhy: opus.why || null } : { model: "sonnet", modelWhy: null };
}
/** The look waiting for this thinker, if any (the first event after every live turn event: R4-1 and design review 6, "delivered after any
    waiting turn and again at the first hello"): not by the cursor (a turn handed out first would carry the cursor past it) but once to each
    thinker's generation. */
function lookEvent(thinker, api, chat, now) {
  for (const c of fights()) {
    const l = lookOf(c); if (!lookWaiting(l, c.round)) continue;
    if (l.thinker?.who === thinker && l.thinker.generation === (brainNow(thinker).generation ?? 0) && now - (l.thinker.at ?? 0) < HOLD_MS) continue;   /* already given to this thinker (again after the hold time, if its answer never came: review 6) */
    if (whoGets({ route: fightRoute(c), kind: "look", api, chat, handedOff: !!l.handedOff, held: l.thinker ?? null, now }) !== thinker) continue;
    return { ...lookOut(l, { combatId: c.id, round: c.round }), ...lookModel(c, l) };
  }
  return null;
}
/* why a thinker's look no longer counts, or null (as `offRoute` for a turn) */
function offLook(combat, l, meta) {
  const m = cleanMeta(meta); if (m.generation == null || m.by === "gm") return null;
  const route = fightRoute(combat);
  if (route === "off") return "Angel is off for this fight, so this was ignored.";
  if (m.by === "api" && route !== "api") return "This fight isn't on the API route any more, so this was ignored.";
  if (m.by === "api" && l.handedOff) return "The API handed the look on to the chat, so this was ignored.";
  const mine = m.by === "api" ? "api" : "chat"; if (l.thinker?.who && l.thinker.who !== mine) return `The look went to ${l.thinker.who === "api" ? "the API" : "the chat"}, so this was ignored.`;
  return null;
}
/** A look handed in (by `submitPlan` with `LOOK_ID`): checked, its suggestions kept with the line each changes as it stands now, for her card. */
async function submitLook(combat, raw, meta = {}) {
  const l = lookOf(combat); if (!l) return { state: "none", reason: "This fight has no fight-start look." };
  if (l.state !== "asked") return { state: l.state, ignored: true, reason: l.state === "missed" ? "Round 1 has ended: the look didn't happen, so this was ignored." : "The look has already been answered." };
  if (combat.round > 1) { await saveTurns(combat, { "look.state": "missed", "look.endedAt": Date.now() }); return { state: "missed", ignored: true, reason: "Round 1 has ended: the look didn't happen, so this was ignored." }; }
  if (stale(brainNow(routeOfMeta(meta)), cleanMeta(meta).generation)) return { state: l.state, ignored: true, reason: SUPERSEDED };
  const off = offLook(combat, l, meta); if (off) return { state: l.state, ignored: true, reason: off };
  if (JSON.stringify(raw ?? null).length > PLAN_BYTES) return { state: l.state, reason: "That look is far too long." };
  const c = cleanLook(raw, Object.keys(l.monsters ?? {}), lookKinds(l));
  if (c.ok && c.seq != null && c.seq !== l.seq) return { state: l.state, ignored: true, reason: "That look answers another fight's look." };
  /* refused: once more, as a new event (a fresh number: the API worker answers each number once) with the reason, to the same thinker; a second refusal fails it.
     The answer reads "requested" with the tries left, as a turn's refusal does, so the worker counts it as landed (0.33.0 review 1) */
  if (!c.ok) { const tries = (l.tries ?? 0) + 1, last = tries >= LOOK_TRIES;
    const again = last ? {} : (() => { const ev = eventChange("look", LOOK_ID, tries); return { ...ev, "look.seq": Object.values(ev)[0].seq, "look.thinker": null, "look.refused": text(c.reason, 300) }; })();
    await saveTurns(combat, { "look.tries": tries, ...again, ...(last ? { "look.state": "failed", "look.reason": `Angel's look was refused twice (${c.reason})` } : {}) });
    return last ? { state: "failed", reason: c.reason } : { state: "requested", reason: c.reason, triesLeft: LOOK_TRIES - tries }; }
  const scene = sceneOf(combat), items = {};
  c.items.forEach((x, i) => {
    const m = l.monsters[x.label], tok = scene?.tokens.get(m?.tokenId), same = Object.values(l.monsters).filter(o => o.kind === m.kind);
    const now = tok ? mindOf(scene, tok, combat).assembled.lines[x.line] : null;
    items[i] = { ...x, tokenId: m.tokenId, name: m.name, kind: m.kind, kindName: m.kindName, count: x.to === "kind" ? same.length : 1, now: now ? lineWords(x.line, now) : "", nowBy: now?.by ?? null };
  });
  await saveTurns(combat, { "look.state": "ready", "look.items": whole(items), "look.fits": c.fits, "look.answeredAt": Date.now(), "look.by": whole({ ...cleanMeta(meta), at: Date.now() }) });
  return { state: "looked", suggestions: c.items.length };
}
/** Her answer on the look's card: one suggestion (its number) or "all" of those still open, "accept" or "keep". An accepted line goes on this
    fight's layer: for the kind (every monster of it in this fight) or for the one monster, marked Angel's. Any GM. */
export async function answerLook(combat, which, answer) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  if (answer !== "accept" && answer !== "keep") throw new Error(`An answer is accept or keep, not ${answer}.`);
  const l = lookOf(combat); if (l?.state !== "ready") throw new Error("No fight-start look is waiting for an answer.");
  const ids = which === "all" ? openItems(l) : openItems(l).filter(i => i === String(which)); if (!ids.length) return 0;
  const change = {}, at = Date.now();
  if (answer === "accept") {
    const kinds = [...(combat.getFlag(ID, "minds")?.kinds ?? [])].map(x => ({ ...x, lines: { ...(x.lines ?? {}) } }));
    let kindsChanged = false;
    for (const i of ids) { const x = l.items[i], line = { ...(x.pick ? { pick: x.pick } : {}), text: x.text ?? "", by: "angel", at };
      if (x.to === "one") change[`flags.${ID}.minds.own.${x.tokenId}.${x.line}`] = whole(line);
      else { let k = kinds.find(e => e.kind === x.kind); if (!k) { k = { kind: x.kind, lines: {} }; kinds.push(k); } k.lines[x.line] = line; kindsChanged = true; } }
    if (kindsChanged) change[`flags.${ID}.minds.kinds`] = kinds;   /* a list: replaced whole, so read and written in one step */
  }
  for (const i of ids) { change[`flags.${ID}.turns.look.items.${i}.answer`] = answer; change[`flags.${ID}.turns.look.items.${i}.by`] = game.user.name; }
  await combat.update(change);
  /* the kinds list is written whole: a second GM page accepting another kind's line at the same moment can write over this one (found 0.33.1).
     Read it back and put any accepted kind line that went missing in again, keeping what the other page wrote. */
  if (answer === "accept" && Object.keys(change).some(k => k.endsWith(".minds.kinds"))) for (let tries = 0; tries < 3; tries++) {
    await new Promise(r => setTimeout(r, 300 + Math.random() * 300));   /* time for the other page's write to arrive */
    const want = ids.map(i => l.items[i]).filter(x => x.to !== "one"), now = [...(combat.getFlag(ID, "minds")?.kinds ?? [])].map(x => ({ ...x, lines: { ...(x.lines ?? {}) } }));
    const lost = want.filter(x => !now.find(e => e.kind === x.kind)?.lines?.[x.line]); if (!lost.length) break;
    for (const x of lost) { let k = now.find(e => e.kind === x.kind); if (!k) { k = { kind: x.kind, lines: {} }; now.push(k); } k.lines[x.line] = { ...(x.pick ? { pick: x.pick } : {}), text: x.text ?? "", by: "angel", at }; }
    await combat.update({ [`flags.${ID}.minds.kinds`]: now });
  }
  return ids.length;
}
/** Dismiss on the look's card (any state but asked). */
export async function dismissLook(combat) { if (!game.user.isGM) throw new Error("Only a GM can do this."); if (lookOf(combat)) await saveTurns(combat, { "look.dismissed": true }); }
/** For the card: the look as it stands, or null. */
export const lookNow = combat => lookOf(combat);

/* ---------- an escaped monster's lines at End Encounter (R4-2, R4-4) ---------- */
/** What each monster that got away from this fight (fled off the map; not the dead, down or the prisoners) saw of its enemies, offered for its own
    "Knows about its enemies": [{ tokenId, name, round, lines: [{ id, text }], hers }]. `hers`: her own words are on that line, so Angel adds
    nothing to it. Lines it already knows aren't offered again. GM pages. */
export function escapeOffers(combat) {
  if (!game.user.isGM || !sceneOf(combat)) return [];
  const t = turns(combat), labels = t.labels ?? {}, scene = sceneOf(combat), byLabel = Object.fromEntries(Object.entries(labels).map(([id, l]) => [l, id]));
  const nameOf = l => { const tok = scene.tokens.get(byLabel[l]); return tok && (onParty(tok.actor) || tok.actor?.hasPlayerOwner) ? tok.name : null; };   /* only the party's side: the line is about its enemies */
  return escapedList(combat).map(e => { const tok = scene.tokens.get(e.id); if (!tok) return null;
    /* the line as its own profile will have it: the layers without this fight's (review 5: a fight line made her own words look like Angel's) */
    const nb = notebookOf(combat, e.id), knows = mindOf(scene, tok).assembled.lines.knows ?? null;
    const lines = escapeLines(books(combat)[e.id], { rung: nb?.rung ?? 3, nameOf }).filter(x => !String(knows?.text ?? "").includes(x.text));
    return lines.length ? { tokenId: e.id, name: e.name, round: e.round, lines, hers: knows?.by === "gm" && !!String(knows.text ?? "").trim(), forms: P(tok, combat) } : null; }).filter(Boolean);
}
/** Her answers to the offer, written when the fight ends (saved or discarded alike: R4-4). accepted: { tokenId: [texts] }. Each monster with a line
    accepted is given its own profile (a copy of what it follows now, as Give one monster its own profile does) if it has none, and the lines go
    on its "Knows about its enemies", marked Angel's: never its kind, this encounter or the library. Out: names written. */
export async function acceptEscapeLines(combat, accepted = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can do this.");
  const scene = sceneOf(combat), done = [];
  for (const [tokenId, texts] of Object.entries(accepted)) {
    const tok = scene?.tokens.get(tokenId); if (!tok || !texts?.length) continue;
    try {
      if (!mindLayers(scene, tok).some(l => l.from === "own")) await giveOwn(scene, tok);
      const own = mindLayers(scene, tok).find(l => l.from === "own")?.lines?.knows ?? null, words = knowsAfter(own, texts); if (!words) continue;   /* her own words: never replaced */
      await setLines(scene, { token: tok.id }, { knows: { text: words, by: "angel" } }, { by: "angel" }); done.push(tok.name);
    } catch (e) { console.error(`${ID} | escape lines`, e); ui.notifications?.warn(`I couldn't add what ${tok.name} saw: ${e.message}`); }
  }
  return done;
}
